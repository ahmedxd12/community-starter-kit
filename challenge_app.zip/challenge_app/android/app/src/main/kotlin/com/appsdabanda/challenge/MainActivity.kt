package com.appsdabanda.challenge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
