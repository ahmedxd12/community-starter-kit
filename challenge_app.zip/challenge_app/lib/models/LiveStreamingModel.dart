// ignore_for_file: file_names

import 'package:challenge/models/GiftsModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'GiftSendersModel.dart';

class LiveStreamingModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Streaming";

  LiveStreamingModel() : super(keyTableName);
  LiveStreamingModel.clone() : this();

  @override
  LiveStreamingModel clone(Map<String, dynamic> map) => LiveStreamingModel.clone()..fromJson(map);

  static const String privacyTypeAnyone = "anyone";
  static const String privacyTypeFriends = "friends";
  static const String privacyTypeNoOne = "none";

  static const String liveTypeParty = "party";
  static const String liveTypeGoLive = "live";
  static const String liveTypeBattle = "battle";

  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static String keyAuthor = "Author";
  static String keyAuthorId = "AuthorId";
  static String keyAuthorUid = "AuthorUid";

  static String keyViewsCount = "viewsCount";

  static String keyAuthorInvited = "AuthorInvited";
  static String keyAuthorInvitedUid = "AuthorInvitedUid";

  static const String keyViewersUid = "viewers_uid";
  static const String keyViewersId = "viewers_id";

  static const String keyViewersCountLive = "viewersCountLive";
  static const String keyStreamingPrivate = "private";

  static const String keyLiveImage = "image";
  static const String keyLiveTags = "live_tag";

  static const String keyStreaming = "streaming";
  static const String keyStreamingTime = "streaming_time";
  static const String keyStreamingDiamonds = "streaming_points";
  static const String keyAuthorTotalDiamonds = "author_total_points";

  static const String keyInvitedPartyUid = "invitedPartyUid";
  static const String keyInvitedPartyLive = "invitedPartyLive";
  static const String keyInvitedPartyLiveAuthor = "invitedPartyLive.Author";

  static const String keyStreamingChannel = "streaming_channel";

  static const String keyStreamingCategory = "streaming_category";

  static const String keyCoHostAvailable = "coHostAvailable";
  static const String keyCoHostAuthor = "coHostAuthor";
  static const String keyCoHostAuthorUid = "coHostAuthorUid";

  static const String keyHashTags = "hash_tags";
  static const String keyHashTagsId = "hash_tags_id";

  static const String keyPrivateLiveGift = "privateLivePrice";
  static const String keyPrivateViewers = "privateViewers";

  static const String keyFirstLive = "firstLive";

  static const String keyGiftSenders = "giftSenders";
  static const String keyGiftSendersAuthor = "giftSenders.author";

  static const String keyGiftSendersPicture = "giftSendersPicture";

  static const String keyInvitedBroadCasterId = "invitedBroadCasterId";

  static const String keyInvitationAccepted = "InvitationAccepted";

  static const String keyCoHostUID = "coHostUID";

  static const String keyLiveTitle = "title";
  static const String keyPoints = "points";

  static const String keyLimitCredit = "limitCredits";

  static const String liveAudio = "audio";
  static const String liveVideo = "video";

  static const String keyLiveType = "liveType";
  static const String keyAudioHostsList = "audioHostsList";
  static const String keyMutedUserIds = "muted_users_id";
  static const String keyUnMutedUserIds = "un_muted_users_id";
  static const String keyUserSelfMutedAudioIds = "user_self_muted_audio";

  static const String keyRemovedUserIds = "removed_users_id";
  static const String keyEndByAdmin = "endByAdmin";

  int? get getLimitCredit => get<int>(keyLimitCredit);
  set setLimitCredit(int limit) => set<int>(keyLimitCredit, limit);

  List<dynamic>? get getPoints{

    List<dynamic>? points = get<List<dynamic>>(keyPoints);
    if(points != null && points.isNotEmpty){
      return points;
    } else {
      return [];
    }
  }
  set setPoints(String point) => setAddUnique(keyPoints, point);

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  int? get getAuthorUid => get<int>(keyAuthorUid);
  set setAuthorUid(int authorUid) => set<int>(keyAuthorUid, authorUid);

  UserModel? get getCoHostAuthor => get<UserModel>(keyCoHostAuthor);
  set setCoHostAuthor(UserModel author) => set<UserModel>(keyCoHostAuthor, author);

  int? get getCoHostAuthorUid => get<int>(keyCoHostAuthorUid);
  set setCoHostAuthorUid(int authorUid) => set<int>(keyCoHostAuthorUid, authorUid);

  bool? get getCoHostAuthorAvailable => get<bool>(keyCoHostAvailable);
  set setCoHostAvailable(bool coHostAvailable) => set<bool>(keyCoHostAvailable, coHostAvailable);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  String? get getLiveTitle => get<String>(keyLiveTitle);
  set setLiveTitle(String title) => set<String>(keyLiveTitle, title);

  String? get getInvitedBroadCasterId => get<String>(keyInvitedBroadCasterId);
  set setInvitedBroadCasterId(String authorId) => set<String>(keyInvitedBroadCasterId, authorId);

  UserModel? get getAuthorInvited => get<UserModel>(keyAuthorInvited);
  set setAuthorInvited(UserModel invitedAuthor) => set<UserModel>(keyAuthorInvited, invitedAuthor);

  int? get getAuthorInvitedUid => get<int>(keyAuthorInvitedUid);
  set setAuthorInvitedUid(int invitedAuthorUid) => set<int>(keyAuthorInvitedUid, invitedAuthorUid);

  int? get getViewersCount{

    int? viewersCount = get<int>(keyViewersCountLive);
    if(viewersCount != null){
      return viewersCount;
    } else {
      return 0;
    }
  }
  set addViewersCount(int viewersCount) => setIncrement(keyViewersCountLive, viewersCount);
  set removeViewersCount(int viewersCount) => setDecrement(keyViewersCountLive, viewersCount);


  ParseFileBase? get getImage => get<ParseFileBase>(keyLiveImage);
  set setImage(ParseFileBase imageFile) => set<ParseFileBase>(keyLiveImage, imageFile);


  set setGifSenderImage(ParseFileBase imageFile) => setAddUnique(keyGiftSendersPicture, imageFile);

  List<dynamic>? get getGifSenderImage {

    List<dynamic>? images = get<List<dynamic>>(keyGiftSendersPicture);
    if(images != null && images.isNotEmpty){
      return images;
    }else{
      return [];
    }
  }

  List<dynamic>? get getCoHostUiD{

    List<dynamic>? coHostUiD = get<List<dynamic>>(keyCoHostUID);
    if(coHostUiD != null && coHostUiD.isNotEmpty){
      return coHostUiD;
    } else {
      return [];
    }
  }
  set setCoHostUID(int coHostUiD) => setAddUnique(keyCoHostUID, coHostUiD);


  List<dynamic>? get getViewers{

    List<dynamic>? viewers = get<List<dynamic>>(keyViewersUid);
    if(viewers != null && viewers.isNotEmpty){
      return viewers;
    } else {
      return [];
    }
  }
  set setViewers(int viewerUid) => setAddUnique(keyViewersUid, viewerUid);

  List<dynamic>? get getViewersId{

    List<dynamic>? viewersId = get<List<dynamic>>(keyViewersId);
    if(viewersId != null && viewersId.isNotEmpty){
      return viewersId;
    } else {
      return [];
    }
  }
  set setViewersId(String viewerAuthorId) => setAddUnique(keyViewersId, viewerAuthorId);

  int? get getDiamonds => get<int>(keyStreamingDiamonds);
  set addDiamonds(int diamonds) => setIncrement(keyStreamingDiamonds, diamonds);

  int? get getAuthorTotalDiamonds => get<int>(keyAuthorTotalDiamonds);
  set addAuthorTotalDiamonds(int diamonds) => setIncrement(keyAuthorTotalDiamonds, diamonds);

  bool? get getStreaming => get<bool>(keyStreaming);
  set setStreaming(bool isStreaming) => set<bool>(keyStreaming, isStreaming);

  bool? get getFirstLive {
    var isFirstTime = get<bool>(keyFirstLive);

    if(isFirstTime != null){
      return isFirstTime;
    }else{
      return false;
    }
  }

  set setFirstLive(bool isFirstLive) => set<bool>(keyFirstLive, isFirstLive);



  String? get getStreamingTime => get<String>(keyStreamingTime);
  set setStreamingTime(String streamingTime) => set<String>(keyStreamingTime, streamingTime);

  String? get getStreamingCategory => get<String>(keyStreamingCategory);
  set setStreamingCategory(String streamingCategory) => set<String>(keyStreamingCategory, streamingCategory);

  String? get getStreamingTags {
    String? text = get<String>(keyLiveTags);
    if(text != null){
      return text;
    } else {
      return "";
    }
  }

  set setStreamingTags(String text) => set<String>(keyLiveTags, text);

  String? get getStreamingChannel => get<String>(keyStreamingChannel);
  set setStreamingChannel(String streamingChannel) => set<String>(keyStreamingChannel, streamingChannel);

  bool? get getPrivate{
    bool? private = get<bool>(keyStreamingPrivate);
    if(private != null){
      return private;
    } else {
      return false;
    }
  }
  set setPrivate(bool private) => set<bool>(keyStreamingPrivate, private);

  bool? get getInvitationAccepted{
    bool? accepted = get<bool>(keyInvitationAccepted);
    if(accepted != null){
      return accepted;
    } else {
      return false;
    }
  }
  set setInvitationAccepted(bool accepted) => set<bool>(keyInvitationAccepted, accepted);




  List<String>? get getHashtags{

    var arrayString =  get<List<dynamic>>(keyHashTagsId);

    if(arrayString != null){
      List<String> users = List<String>.from(arrayString);
      return users;
    } else {
      return [];
    }

  }

  GiftsModel? get getPrivateGift => get<GiftsModel>(keyPrivateLiveGift);
  set setPrivateLivePrice(GiftsModel privateLivePrice) => set<GiftsModel>(keyPrivateLiveGift, privateLivePrice);
  set removePrice(GiftsModel privateLivePrice) => setRemove(keyPrivateLiveGift, privateLivePrice);

  List<dynamic>? get getPrivateViewersId{

    List<dynamic>? viewersId = get<List<dynamic>>(keyPrivateViewers);
    if(viewersId != null && viewersId.isNotEmpty){
      return viewersId;
    } else {
      return [];
    }
  }
  set setPrivateViewersId(String viewerAuthorId) => setAddUnique(keyPrivateViewers, viewerAuthorId);

  set setPrivateListViewersId(List viewersId) {

    List<String> listViewersId = [];

    for(String privateViewer in viewersId){
      listViewersId.add(privateViewer);
    }
    setAddAllUnique(keyPrivateViewers, listViewersId);
  }

  List<dynamic>? get getGiftsSenders{

    List<dynamic>? giftSenders = get<List<dynamic>>(keyGiftSenders);
    if(giftSenders != null && giftSenders.isNotEmpty){
      return giftSenders;
    } else {
      return [];
    }
  }
  set addGiftsSenders(GiftsSenderModel giftsSenderModel) => setAddUnique(keyGiftSenders, giftsSenderModel);

  List<dynamic>? get getInvitedPartyUid{

    List<dynamic>? invitedUid = get<List<dynamic>>(keyInvitedPartyUid);
    if(invitedUid != null && invitedUid.isNotEmpty){
      return invitedUid;
    } else {
      return [];
    }
  }
  set addInvitedPartyUid(List<dynamic> uidList) => setAddAllUnique(keyInvitedPartyUid, uidList);

  set removeInvitedPartyUid(int uid) => setRemove(keyInvitedPartyUid, uid);

  LiveStreamingModel? get getInvitationLivePending => get<LiveStreamingModel>(keyInvitedPartyLive);

  set setInvitationLivePending(LiveStreamingModel live) => set<LiveStreamingModel>(keyInvitedPartyLive, live);

  removeInvitationLivePending() => unset(keyInvitedPartyLive);

  set removeViewersId(String viewerAuthorId) => setRemove(keyViewersId, viewerAuthorId);

  List<dynamic>? get getMutedUserIds{

    List<dynamic>? users = get<List<dynamic>>(keyMutedUserIds);
    List<dynamic> emptyUsers = [];

    if(users != null && users.isNotEmpty){
      return users;
    } else {
      return emptyUsers;
    }
  }
  set addMutedUserIds(String userId) => setAddUnique(keyMutedUserIds, userId);
  set removeMutedUserIds(String userId) => setRemove(keyMutedUserIds, userId);

  List<dynamic>? get getRemovedUserIds{
    List<dynamic>? users = get<List<dynamic>>(keyRemovedUserIds);
    if(users != null && users.isNotEmpty){
      return users;
    } else {
      return [];
    }
  }
  set addRemovedUserIds(String userId) => setAddUnique(keyRemovedUserIds, userId);
  set removeRemovedUserIds(String userId) => setRemove(keyRemovedUserIds, userId);

  List<dynamic>? get getUnMutedUserIds{
    List<dynamic>? users = get<List<dynamic>>(keyUnMutedUserIds);
    if(users != null && users.isNotEmpty){
      return users;
    } else {
      return [];
    }
  }
  set addUnMutedUserIds(String userId) => setAddUnique(keyUnMutedUserIds, userId);
  set removeUnMutedUserIds(String userId) => setRemove(keyUnMutedUserIds, userId);

  bool? get isLiveCancelledByAdmin{
    bool? cancelled = get<bool>(keyEndByAdmin);
    if(cancelled != null){
      return cancelled;
    } else {
      return false;
    }
  }

  String? get getLiveType => get<String>(keyLiveType);
  set setLiveType(String liveType) => set<String>(keyLiveType, liveType);

}