// ignore_for_file: file_names

import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'UserModel.dart';

class ReportModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Report";

  ReportModel() : super(keyTableName);
  ReportModel.clone() : this();

  @override
  ReportModel clone(Map<String, dynamic> map) => ReportModel.clone()..fromJson(map);

  static String reportTypeProfile = "PROFILE";
  static String reportTypePost = "POST";
  static String reportTypeLiveStreaming = "LIVE";

  static String keyCreatedAt = "createdAt";
  static String keyUpdatedAt = "updatedAt";
  static String keyObjectId = "objectId";

  static String stateResolved = "resolved";
  static String stateFiled = "filed";
  static String statePending = "pending";
  static String stateProgress = "in progress";

  static const thisPosHasSexualContents = "SC";
  static const fakeProfileSpan = "FPS";
  static const inappropriateMessage = "IM";
  static const underAgeUser = "UA";
  static const someoneIsInDanger = "SID";

  static String keyVideo = "video";
  static String keyVideoId = "videoId";

  static String keyLiveStreaming = "liveStreaming";
  static String keyLiveStreamingId = "liveStreamingId";

  static String keyAccuser = "accuser";
  static String keyAccuserId = "accuserId";

  static String keyAccused = "accused";
  static String keyAccusedId = "accusedId";

  static String keyMessage = "message";

  static String keyDescription = "description";

  static String keyState = "state";
  static String keyReportType = "reportType";

  String? get getReportType => get<String>(keyReportType);
  set setReportType(String reportType) => set<String>(keyReportType, reportType);

  UserModel? get getAccuser => get<UserModel>(keyAccuser);
  set setAccuser(UserModel author) => set<UserModel>(keyAccuser, author);

  VideoModel? get getVideo => get<VideoModel>(keyVideo);
  set setVideo(VideoModel video) => set<VideoModel>(keyVideo, video);

  String? get getVideoId => get<String>(keyVideoId);
  set setVideoId(String videoId) => set<String>(keyVideoId, videoId);

  LiveStreamingModel? get getLiveStreaming => get<LiveStreamingModel>(keyLiveStreaming);
  set setLiveStreaming (LiveStreamingModel liveStreaming) => set<LiveStreamingModel>(keyLiveStreaming, liveStreaming);

  String? get getLiveStreamingId => get<String>(keyLiveStreamingId);
  set setLiveStreamingId(String liveStreamingId) => set<String>(keyLiveStreamingId, liveStreamingId);

  String? get getAccuserId => get<String>(keyAccuserId);
  set setAccuserId(String authorId) => set<String>(keyAccuserId, authorId);

  UserModel? get getAccused => get<UserModel>(keyAccused);
  set setAccused(UserModel user) => set<UserModel>(keyAccused, user);

  String? get getAccusedId => get<String>(keyAccusedId);
  set setAccusedId(String userId) => set<String>(keyAccusedId, userId);

  String? get getMessage => get<String>(keyMessage);
  set setMessage(String message) => set<String>(keyMessage, message);

  String? get getDescription => get<String>(keyDescription);
  set setDescription(String description) => set<String>(keyDescription, description);

  String? get getState => get<String>(keyState);
  set setState(String state) => set<String>(keyState, state);

}