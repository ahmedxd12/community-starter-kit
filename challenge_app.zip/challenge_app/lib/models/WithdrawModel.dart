// ignore_for_file: file_names

import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class WithdrawModel extends ParseObject implements ParseCloneable {

  static const  String keyTableName = "Withdrawal";

  WithdrawModel() : super(keyTableName);
  WithdrawModel.clone() : this();

  @override
  WithdrawModel clone(Map<String, dynamic> map) => WithdrawModel.clone()..fromJson(map);

  static const pending = "pending";
  static const processing = "processing";
  static const complete = "completed";


  static const payoneer = "payoneer";
  static const paypal = "paypal";
  static const iban = "IBAN";
  static const currency = "USD";


  static const String keyAuthor = "author";
  static const String keyTokens = "points";
  static const String keyAmount = "amount";
  static const String keyAmountString = "amount_string";
  static const String keyCompleted = "completed"; //false,true
  static const String keyStatus = "status"; // pending, processing, completed
  static const String keyEmail = "email";
  static const String keyMethod = "method";
  static const String keyCurrency = "currency";
  static const String keyIBAN = "IBAN";
  static const String keyAccountName = "account_name";
  static const String keyBankName = "bank_name";

  static const String keyCreatedAt = "createdAt";

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  set setPoints(int points) => setIncrement(keyTokens, points);
  int? get getPoints {
    int? point = get<int>(keyTokens);
    if(point != null){
      return point;
    } else {
      return 0;
    }
  }

  double? get getAmount => get<double>(keyAmount);
  set setAmount(double amount) => setIncrement(keyAmount, amount);
  /*double? get getAmount {
    double? amount = get<double>(keyAmount);
    if(amount != null){
      return amount;
    } else {
      return 0.0;
    }
  }*/

  String? get getAmountString => get<String>(keyAmountString);
  set setAmountString(String amount) => set(keyAmountString, amount);

  set setCompleted(bool completed) => set<bool>(keyCompleted, completed);
  bool? get getCompleted{
    bool? completed = get<bool>(keyCompleted);
    if(completed != null){
      return completed;
    }else{
      return true;
    }
  }

  String? get getStatus => get<String>(keyStatus);
  set setStatus(String status) => set<String>(keyStatus, status);

  String? get getAccountName => get<String>(keyAccountName);
  set setAccountName(String name) => set<String>(keyAccountName, name);

  String? get getBankName => get<String>(keyBankName);
  set setBankName(String bank) => set<String>(keyBankName, bank);

  String? get getEmail => get<String>(keyEmail);
  set setEmail(String email) => set<String>(keyEmail, email);

  String? get getIBAN => get<String>(keyIBAN);
  set setIBAN(String iban) => set<String>(keyIBAN, iban);

  String? get getMethod => get<String>(keyMethod);
  set setMethod(String method) => set<String>(keyMethod, method);

  String? get getCurrency => get<String>(keyCurrency);
  set setCurrency(String currency) => set<String>(keyCurrency, currency);

}