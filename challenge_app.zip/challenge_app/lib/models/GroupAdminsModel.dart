// ignore_for_file: file_names

import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/models/UserModel.dart';

class AdminsGroupModel extends ParseObject implements ParseCloneable {

  static const  String keyTableName = "GroupAdmins";

  AdminsGroupModel() : super(keyTableName);
  AdminsGroupModel.clone() : this();

  @override
  AdminsGroupModel clone(Map<String, dynamic> map) => AdminsGroupModel.clone()..fromJson(map);

  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static String keyUpdatedAt = "updatedAt";

  static String keyCreator = "Creator";
  static String keyCreatorID = "CreatorID";

  static String keyAdmins = "Admins";

  static String keyGroup = "group";
  static String keyGroupID = "groupID";

  static String keyRemovedMembers = "removedMembers";
  static String keyRemovedMembersID = "removedMembers";
  static String keyAddedMembers = "addedMembers";

  static String keyMember = "members";
  static String keyMembersIDs = "membersIDs";

  UserModel? get getAuthor => get<UserModel>(keyCreator);
  set setAuthor(UserModel author) => set<UserModel>(keyCreator, author);

  String? get getAuthorId => get<String>(keyCreatorID);
  set setAuthorId(String authorId) => set<String>(keyCreatorID, authorId);

  List<dynamic>? get getMembersIDs{

    List<dynamic> members = [];

    List<dynamic>? membersIDs = get<List<dynamic>>(keyMembersIDs);
    if(membersIDs != null && membersIDs.isNotEmpty){
      return membersIDs;
    } else {
      return members;
    }
  }
  set setMemberID(String memberId) => setAddUnique(keyMembersIDs, memberId);
  set setMemberIDs(List<dynamic> memberIDs) => setAddAll(keyMembersIDs, memberIDs);
  set removeMemberID(String memberId) => setRemove(keyMembersIDs, memberId);


  List<UserModel>? get getMembers{

    List<UserModel> members = [];

    List<UserModel>? member = get<List<UserModel>>(keyMember);
    if(member != null && member.isNotEmpty){
      return member;
    } else {
      return members;
    }
  }
  set setMember(UserModel member) => setAddUnique(keyMember, member);
  set setMembers(List<UserModel> member) => setAddAll(keyMember, member);
  set removeMember(UserModel member) => setRemove(keyMember, member);

  List<dynamic>? get getAdmins{

    List<dynamic> admins = [];

    List<dynamic>? adminIDs = get<List<dynamic>>(keyAdmins);
    if(adminIDs != null && adminIDs.isNotEmpty){
      return adminIDs;
    } else {
      return admins;
    }
  }
  set setAdmin(String adminID) => setAddUnique(keyAdmins, adminID);
  set removeAdmin(String adminID) => setRemove(keyAdmins, adminID);

}