// ignore_for_file: file_names
import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../configurations/global_config.dart';


class VideoModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Video";

  VideoModel() : super(keyTableName);
  VideoModel.clone() : this();

  @override
  VideoModel clone(Map<String, dynamic> map) => VideoModel.clone()..fromJson(map);

  // Video states
  static const videoCurrentStateScheduled = "SLD";
  static const videoCurrentStatePublished = "PSD";
  static const videoCurrentStatePending = "PDG";
  static const videoCurrentStateDeleted = "DTD";

  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static String keyAuthor = "author";
  static String keyAuthorId = "authorId";

  static String keyTitle = "title";
  static String keyDuration = "duration";
  static String keyVideo = "video";
  static String keyViews = "views";

  static String keyUpdatedAt = "updatedAt";

  static String keyVideoFile = "video";
  static String keyUrl = "url";

  static String keyComments = "comments";
  static String keyThumbnail = "thumbnail";
  static String keyViewsCount = "viewsCount";
  static String keyLikes = "likes";
  static String keySelections = "selections";
  static String keyCurrentState = "current_state";

  String? get getObjectId => get<String>(keyObjectId);
  DateTime? get getCreatedAt => get<DateTime>(keyCreatedAt);
  DateTime? get getUpdatedAt => get<DateTime>(keyUpdatedAt);

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  String? get getUrl => get<String>(keyUrl);
  set setUrl(String url) => set<String>(keyUrl, url);

  List<dynamic>? get getComments{
    List<dynamic>? comments = get<List<dynamic>>(keyComments);
    if(comments != null && comments.isNotEmpty){
      return comments;
    } else {
      return [];
    }
  }
  set setComments(String commentId) => setAddUnique(keyComments, commentId);

  ParseFileBase? get getThumbnail => get<ParseFileBase>(keyThumbnail);
  set setThumbnail(ParseFileBase imageFile) => set<ParseFileBase>(keyThumbnail, imageFile);

  ParseFileBase? get getVideo => get<ParseFileBase>(keyVideoFile);
  set setVideo(ParseFileBase videoFile) => set<ParseFileBase>(keyVideoFile, videoFile);

  List<dynamic>? get getLikes{
    List<dynamic> like = [];

    List<dynamic>? likes = get<List<dynamic>>(keyLikes);
    if(likes != null && likes.isNotEmpty){
      return likes;
    } else {
      return like;
    }
  }
  set setLikes(String likeAuthorId) => setAddUnique(keyLikes, likeAuthorId);
  set removeLike(String likeAuthorId) => setRemove(keyLikes, likeAuthorId);

  int? get getViewsCount => get<int>(keyViewsCount);
  set setViewsCount(int viewsCount) => set<int>(keyViewsCount, viewsCount);

  List<dynamic>? get getViews{
    List<dynamic>? views = get<List<dynamic>>(keyViews);
    if(views != null && views.isNotEmpty){
      return views;
    } else {
      return [];
    }
  }
  set setViews(String viewAuthorId) => setAddUnique(keyViews, viewAuthorId);

  List<dynamic>? get getSelections{
    List<dynamic>? selections = get<List<dynamic>>(keySelections);
    if(selections != null && selections.isNotEmpty){
      return selections;
    } else {
      return [];
    }
  }
  set setSelections(String selectionAuthorId) => setAddUnique(keySelections, selectionAuthorId);

  String? get getCurrentState => get<String>(keyCurrentState);
  set setCurrentState(String currentState) => set<String>(keyCurrentState, currentState);

  String? get getDuration {
    String? duration = get<String>(keyDuration);
    if (duration != null) {
      return duration;
    } else {
      return Config.videoDefaultTimeDuration;
    }
  }
  set setDuration(String duration) => set<String>(keyDuration, duration);

}