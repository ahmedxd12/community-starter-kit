// ignore_for_file: file_names

import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/models/UserModel.dart';

class CallsModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Calls";

  CallsModel() : super(keyTableName);
  CallsModel.clone() : this();

  @override
  CallsModel clone(Map<String, dynamic> map) => CallsModel.clone()..fromJson(map);

  static const callEndReasonEnd = "TERMINATED";
  static const callEndReasonBusy = "BUSY";
  static const callEndReasonGiveUp = "GIVE_UP";
  static const callEndReasonRefused = "REFUSED";
  static const callEndReasonNoAnswer = "NO_ANSWER";
  static const callEndReasonOffLine = "OFFLINE";
  static const callEndReasonCredit = "COINS";


  static String keyAuthor= "fromUser";
  static String keyAuthorId = "fromUserId";
  //toUser
  static String keyReceiver = "toUser";
  static String keyReceiverId = "toUserId";

  static String keyDuration = "duration";
  static String keyAccepted = "accepted";
  static String keyCallEndReason = "reason";
  static String keyCallTypeVoice = "isVoiceCall";
  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";
  static String keyCoins = "coins";

  int? get getCoins => get<int>(keyCoins);
  set setCoins(int count) => set<int>(keyCoins, count);

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  UserModel? get getReceiver => get<UserModel>(keyReceiver);
  set setReceiver(UserModel receiver) => set<UserModel>(keyReceiver, receiver);

  String? get getReceiverId => get<String>(keyReceiverId);
  set setReceiverId(String receiverId) => set<String>(keyReceiverId, receiverId);


  String? get getDuration{
    String? duration = get<String>(keyDuration);
    if(duration != null){
      return duration;
    }else{
      return "00:00";
    }
  }

  set setDuration(String duration) => set<String>(keyDuration, duration);

  set setAccepted(bool accepted) => set<bool>(keyAccepted, accepted);

  bool? get getAccepted{
    bool? accepted = get<bool>(keyAccepted);
    if(accepted != null){
      return accepted;
    }else{
      return true;
    }
  }

  set setIsVoiceCall(bool accepted) => set<bool>(keyCallTypeVoice, accepted);

  bool? get getIsVoiceCall{
    bool? accepted = get<bool>(keyCallTypeVoice);
    if(accepted != null){
      return accepted;
    }else{
      return true;
    }
  }

  String? get getCallEndReason => get<String>(keyCallEndReason);
  set setCallEndReason(String callEndReason) => set<String>(keyCallEndReason, callEndReason);


}