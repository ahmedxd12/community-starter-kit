// ignore_for_file: file_names
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import 'LiveStreamingModel.dart';
import 'UserModel.dart';

class AudioChatUsersModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "AudioChatUsers";

  AudioChatUsersModel() : super(keyTableName);
  AudioChatUsersModel.clone() : this();

  @override
  AudioChatUsersModel clone(Map<String, dynamic> map) => AudioChatUsersModel.clone()..fromJson(map);


  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static const String keyLiveStreaming = "liveStream";
  static const String keyLiveStreamingId = "liveStreamId";

  static const String keyJoinedUser = "joined_user";
  static const String keyJoinedUserId = "joined_user_id";
  static const String keyJoinedUserUID = "joined_user_uid";

  static const String keyCanTalk = "can_talk";

  static const String keyLeftRoom = "left_room";
  static const String keyUserSelfMutedAudioIds = "user_self_muted_audio";

  static const String keyUserMutedByHostIds = "users_muted_by_host_audio";

  static const String keySeatIndex = "co_host_seat_index";

  int? get getSeatIndex => get<int>(keySeatIndex);
  set setSeatIndex(int seatIndex) => set<int>(keySeatIndex, seatIndex);

  List<dynamic>? get getUserMutedByHostIds{
    List<dynamic>? users = get<List<dynamic>>(keyUserMutedByHostIds);
    if(users != null && users.isNotEmpty){
      return users;
    } else {
      return [];
    }
  }
  set addUserMutedByHostIds(String userId) => setAddUnique(keyUserMutedByHostIds, userId);
  set removeUserMutedByHostIds(String userId) => setRemove(keyUserMutedByHostIds, userId);

  List<dynamic>? get getUserSelfMutedAudioIds{
    List<dynamic>? users = get<List<dynamic>>(keyUserSelfMutedAudioIds);
    if(users != null && users.isNotEmpty){
      return users;
    } else {
      return [];
    }
  }
  set addUserSelfMutedAudioIds(String userId) => setAddUnique(keyUserSelfMutedAudioIds, userId);
  set removeUserSelfMutedAudioIds(String userId) => setRemove(keyUserSelfMutedAudioIds, userId);

  UserModel? get getJoinedUser => get<UserModel>(keyJoinedUser);
  set setJoinedUser(UserModel author) => set<UserModel>(keyJoinedUser, author);
  removeJoinedUser() => set(keyJoinedUser, null);

  String? get getJoinedUserId => get<String>(keyJoinedUserId);
  set setJoinedUserId(String authorId) => set<String>(keyJoinedUserId, authorId);
  removeJoinedUserId() => set(keyJoinedUserId, null);

  int? get getJoinedUserUid => get<int>(keyJoinedUserUID);
  set setJoinedUserUid(int authorUid) => set<int>(keyJoinedUserUID, authorUid);
  removeJoinedUserUid() => set(keyJoinedUserUID, null);

  LiveStreamingModel? get getLiveStreaming => get<LiveStreamingModel>(keyLiveStreaming);
  set setLiveStreaming(LiveStreamingModel liveStreaming) => set<LiveStreamingModel>(keyLiveStreaming, liveStreaming);

  String? get getLiveStreamingId => get<String>(keyLiveStreamingId);
  set setLiveStreamingId(String liveStreamingId) => set<String>(keyLiveStreamingId, liveStreamingId);

  bool? get getCanUserTalk {
    bool? canTalk = get<bool>(keyCanTalk);
    if(canTalk != null) {
      return canTalk;
    }else{
      return false;
    }
  }
  set setCanUserTalk(bool canTalk) => set<bool>(keyCanTalk, canTalk);

  bool? get getLetTheRoom {
    bool? leftRoom = get<bool>(keyLeftRoom);
    if(leftRoom != null) {
      return leftRoom;
    }else{
      return false;
    }
  }
  set setLetTheRoom(bool leftRoom) => set<bool>(keyLeftRoom, leftRoom);

}