// ignore_for_file: file_names

import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class PictureModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Picture";

  PictureModel() : super(keyTableName);
  PictureModel.clone() : this();

  @override
  PictureModel clone(Map<String, dynamic> map) => PictureModel.clone()..fromJson(map);

  @override
  PictureModel fromJson(Map<String, dynamic> objectData) {
    super.fromJson(objectData);
    if (objectData.containsKey(keyAuthor)) {
      setAuthor = UserModel.clone().fromJson(objectData[keyAuthor]);
    }
    return this;
  }

  static const String keyFileStatusPending = "pending";
  static const String keyFileStatusApproved = "approved";
  static const String keyFileStatusRejected = "rejected";

  static const String keyFileTypeImage = "image";
  static const String keyFileTypeVideo = "video";
  static const String keyFileTypeGif = "gif";
  static const String keyFileTypeJson = "json";

  static const String keyCreatedAt = "createdAt";

  static const String keyAuthor = "author";
  static const String keyAuthorId = "authorId";

  static const String keyFile = "file";
  static const String keyFileType = "fileType";
  static const String keyFileStatus = "fileStatus";

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  ParseFileBase? get getFile => get<ParseFileBase>(keyFile);
  set setFile(ParseFileBase file) => set<ParseFileBase>(keyFile, file);

  String? get getFileType => get<String>(keyFileType);
  set setFileType(String fileType) => set<String>(keyFileType, fileType);

  String? get getFileStatus => get<String>(keyFileStatus);
  set setFileStatus(String fileStatus) => set<String>(keyFileStatus, fileStatus);
}