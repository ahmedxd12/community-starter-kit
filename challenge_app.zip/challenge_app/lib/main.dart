// ignore_for_file: equal_keys_in_map, use_build_context_synchronously
import 'dart:async';
import 'package:challenge/pages/authentication/signin_page.dart';
import 'package:challenge/services/admob_service.dart';
import 'package:challenge/services/analytics_service.dart';
import 'package:challenge/services/navigation_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:challenge/pages/global/global_loading_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:devicelocale/devicelocale.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/services/dynamic_link_service.dart';
import 'package:challenge/services/push_notification_service.dart';
import 'package:challenge/utilities/main_utilities/theme.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_strategy/url_strategy.dart';
import 'configurations/global_config.dart';
import 'configurations/global_setup.dart';
import 'configurations/models_config.dart';
import 'configurations/router_config.dart';
import 'firebase_options.dart';
import 'package:hive_flutter/hive_flutter.dart';

Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();

  await Hive.initFlutter();
  await EasyLocalization.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

  //Show both overlays:
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
      overlays: [SystemUiOverlay.bottom, SystemUiOverlay.top]);

  if (MainHelper.isWebPlatform()) {
    // Remove # in urls
    setPathUrlStrategy();
  }

  await Parse().initialize(
    Config.appId,
    Config.serverUrl,
    clientKey: Config.clientKey,
    liveQueryUrl: Config.liveQueryUrl,
    autoSendSessionId: true,
    coreStore: MainHelper.isWebPlatform()
        ? await CoreStoreSharedPrefsImp.getInstance()
        : await CoreStoreSembastImp.getInstance(password: Config.appId),
    debug: Setup.isDebug,
    appName: Setup.appName,
    appPackageName: Setup.appPackageName,
    appVersion: Setup.appVersion,
    locale: await Devicelocale.currentLocale,
    parseUserConstructor: (username, password, email,
            {client, debug, sessionToken}) =>
        UserModel(username, password, email),
    registeredSubClassMap: AppModels.subClassMap,
  );
  runApp(
    EasyLocalization(
      supportedLocales: Config.languages,
      path: 'assets/translations',
      fallbackLocale: Locale(Config.defaultLanguage),
      child: const ChallengeApp(),
    ),
  );
}

class ChallengeApp extends StatefulWidget {
  const ChallengeApp({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _ChallengeAppState createState() => _ChallengeAppState();
}

class _ChallengeAppState extends State<ChallengeApp>
    with WidgetsBindingObserver {
  late FirebaseMessaging messaging;
  FlutterLocalNotificationsPlugin? flutterLocalNotificationsPlugin;
  final DynamicLinkService _dynamicLinkService = DynamicLinkService();
  UserModel? currentUser;
  late AppLifecycleReactor appLifecycleReactor;

  _checkAndroidNotificationsPermission() async {
    if (MainHelper.isAndroidPlatform()) {
      PermissionStatus status = await Permission.notification.status;

      if (status.isDenied) {
        Map<Permission, PermissionStatus> statuses =
            await [Permission.notification].request();

        if (statuses[Permission.notification]!.isGranted) {
        } else {
          MainHelper.showDialogPermission(
              context: context,
              title: "permissions.notification_access_denied".tr(),
              confirmButtonText: "permissions.okay_settings".tr().toUpperCase(),
              message: "permissions.notification_access_denied_explain"
                  .tr(namedArgs: {"app_name": Setup.appName}),
              onPressed: () {
                MainHelper.hideLoadingDialog(context);
                openAppSettings();
              });
        }
      } else if (status.isPermanentlyDenied) {
        openAppSettings();
      }
    }
  }

  @override
  void initState() {
    messaging = FirebaseMessaging.instance;
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    if (!MainHelper.isWebPlatform()) {
      // context.read<CallsProvider>().connectAgoraRtm();

      PushNotificationService(
        messaging,
        currentUser,
        flutterLocalNotificationsPlugin!,
      ).initialise();
    }
    WidgetsBinding.instance.addObserver(this);

    Future.delayed(const Duration(seconds: 1), () {
      _dynamicLinkService.listenDynamicLink(context);
    });
    super.initState();

    AppOpenAdManager appOpenAdManager = AppOpenAdManager()..loadAd();
    appLifecycleReactor =
        AppLifecycleReactor(appOpenAdManager: appOpenAdManager)
          ..listenToAppStateChanges();

    Analytics analytics = Analytics();
    analytics.setView();

    _checkAndroidNotificationsPermission();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.resumed) {
      Future.delayed(const Duration(milliseconds: 1000), () {
        _dynamicLinkService.retrieveDynamicLink(context);
      });
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: AppRouter.routes,
      title: Setup.appName,
      debugShowCheckedModeBanner: false,
      theme: lightThemeData(context),
      darkTheme: darkThemeData(context),
      themeMode: ThemeMode.system,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      navigatorKey: NavigationService.navigatorKey,
      locale: context.locale,
      navigatorObservers: [AppRouter.routeObserver],
      // initialRoute: '/',
      home: FutureBuilder<UserModel?>(
        future: MainHelper.getUser(currentUser),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.none:
            case ConnectionState.waiting:
              return Scaffold(
                body: MainHelper.appLoadingLogo(),
              );
            default:
              if (snapshot.hasData) {
                return GlobalLoadingPage(
                  currentUser: snapshot.data,
                );
              } else {
                return const SignInPage();
              }
          }
        },
      ),
    );
  }
}
