import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:challenge/utilities/main_utilities/shared_manager.dart';

import '../configurations/constants_config.dart';
import '../configurations/global_config.dart';


class DynamicLinkService {

  Future<Uri?> createDynamicLink(String? id,{String? type}) async {
    try {
      String suffix = type == 'invite'
          ? Config.inviteSuffix : Config.videoSuffix;

      final DynamicLinkParameters parameters = DynamicLinkParameters(
        // The Dynamic Link URI domain. You can view created URIs on your Firebase console
        uriPrefix: Config.uriPrefix,
        // The deep Link passed to your application which you can use to affect change
        //link: Uri.parse("${Config.link.replaceAll("/", "")}/?${Config.inviteSuffix}=$id"),
        link: Uri.parse("${Config.link}/$suffix=$id"),
        // Android application details needed for opening correct app on device/Play Store
        androidParameters: AndroidParameters(
          packageName: Constants.appPackageName(),
          minimumVersion: 1,
        ),
        // iOS application details needed for opening correct app on device/App Store
        iosParameters: IOSParameters(
          bundleId: Constants.appPackageName(),
          appStoreId: Config.iosAppStoreId,
          minimumVersion: '1',
        ),
      );

      final ShortDynamicLink shortDynamicLink = await FirebaseDynamicLinks.instance.buildShortLink(parameters);
      final Uri uri = shortDynamicLink.shortUrl;
      return uri;

    } catch (e) {

      return null;
    }
  }

  Future<void> retrieveDynamicLink(BuildContext context) async {

    try {
      final PendingDynamicLinkData? data = await FirebaseDynamicLinks.instance.getInitialLink();
      Uri? deepLink = data?.link;

      if (deepLink != null) {
        if (deepLink.queryParameters.containsKey(Config.inviteSuffix)) {
          //String? preLink = deepLink.queryParameters[Config.inviteSuffix];
          //String id = preLink!.replaceAll("/${Config.inviteSuffix}", "");
        }else if(deepLink.queryParameters.containsKey(Config.videoSuffix)){
          // I don't know what to do!
        }
      }

    } catch (e) {
      e.toString();
    }
  }

  listenDynamicLink(BuildContext context) async{

    SharedPreferences preferences = await SharedPreferences.getInstance();

    FirebaseDynamicLinks.instance.onLink.listen((dynamicLinkData) async {

      String id = dynamicLinkData.link.path.replaceAll("/${Config.inviteSuffix}=", "");

      SharedManager().setInvitee(preferences, id);

    }).onError((error) {
      // Handle errors
    });
  }

}