// ignore_for_file: must_be_immutable, use_build_context_synchronously

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/pages/home/settings_pages/get_money_page.dart';
import 'package:challenge/pages/home/settings_pages/settings_page.dart';
import 'package:challenge/pages/home/message_pages/message_list_page.dart';
import 'package:challenge/models/UserModel.dart';

import '../pages/authentication/signin_page.dart';
import '../pages/home/settings_pages/earn_credit.dart';
import '../utilities/helper_classes/main_helper.dart';
import 'custom_widgets/container_with_corner.dart';
import '../utilities/main_utilities/colors.dart';
import 'custom_widgets/text_with_tap.dart';

class CustomDrawer extends StatefulWidget {
  CustomDrawer({this.currentUser,this.isVideoPage, Key? key}) : super(key: key);
  UserModel? currentUser;
  bool? isVideoPage = false;

  @override
  State<CustomDrawer> createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  get size => MediaQuery.of(context).size;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Align(
        alignment: Alignment.topRight,
        child: ContainerCorner(
            height: size.height * 0.85,
            width: size.width * 0.86,
            marginTop: 0,
            imageDecoration: "assets/images/app_drawer_bg.png",
            child:  Align(
              alignment: Alignment.topRight,
              child: Drawer(
                backgroundColor: kTransparentColor,
                elevation: 0,
                child: ListView(
                  padding: EdgeInsets.only(left: size.width/30, top: size.width/70),
                  children: [
                    Align(
                      alignment: Alignment.topLeft,
                      child: GestureDetector(
                        onTap: () => MainHelper.hideLoadingDialog(context),
                        child: Image(
                          image: const AssetImage('assets/images/app_drawer_icon.png'),
                          width: size.width/19,
                          height: size.height/19,
                        ),
                      ),
                    ),
                    getMenuOptions(),
                  ],
                ),
              ),
            ),
        ),
      ),
    );
  }

  Widget getMenuOptions(){
    bool isVideoScreen = widget.isVideoPage ?? false;

    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(left: size.width/10, top: size.width/30),
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // To complete the menu just replace the second parameter by the
              // right screen's route
              menuOption(tr('drawer_options.settings'),page: SettingsPage(currentUser: widget.currentUser!)),
              // menuOption(tr('drawer_options.general')),
              menuOption(tr('drawer_options.chat'), page: MessagesListPage(currentUser: widget.currentUser!)),
              menuOption(tr('drawer_options.statistics'), page: GetMoneyPage(currentUser: widget.currentUser!)),
              menuOption(tr('drawer_options.earn'), page: EarnCreditPage(currentUser: widget.currentUser!)),
              // menuOption(tr('drawer_options.qr'), page: MyAppCodeScreen(currentUser: widget.currentUser,)),
              /*menuOption(tr('drawer_options.privacy'), page: const WebViewScreen(pageType: MainHelper.pageTypeBigNftGame)),
              menuOption(tr('drawer_options.promote'), page: const WebViewScreen(pageType: MainHelper.pageTypeBigNftGame)),
              menuOption(tr('drawer_options.rules'), page: const WebViewScreen(pageType: MainHelper.pageTypeBigNftGame)),*/
              // menuOption(tr('drawer_options.language'), '/'),
              !isVideoScreen
                ? menuOption(tr('drawer_options.exit'),route:'exit')
                : const SizedBox(),
            ]
        ),
      ),
    );
  }

  Widget menuOption(String label,{String? route, Widget? page}){
    return TextWithTap(
      label, onTap: () {
        if(route != null){

          if(route == 'exit'){
            logout();
          }else{
            MainHelper.goToNavigator(context, route);
          }

        }else if(page != null){

          MainHelper.goToNavigatorScreen(context,page);

        }else {
          MainHelper.hideLoadingDialog(context);
          MainHelper.showAppNotificationAdvanced(
            title:'not_stated'.tr(),
            context: context,
            isError: false,
          );
        }
      },
      textAlign: TextAlign.left,
      color:kContentColorDarkTheme,
      fontSize: size.width/20,
      marginBottom: size.width / 20,
    );
  }
  
  logout() async {
    // In this function is call when the last menu option is clicked
    // Include here all the code needed to logout the user
      MainHelper.showLoadingDialog(context);

      ParseResponse response = await widget.currentUser!.logout();

      if (response.success) {
        // updates current installation's user
        // MainHelper.updateCurrentInstallation(user: null);
        MainHelper.initInstallation(null, null);

        MainHelper.hideLoadingDialog(context);
        MainHelper.goToNavigatorScreen(
          context,
          const SignInPage(),
          finish: true,
          back: false,
        );
      } else {
        MainHelper.hideLoadingDialog(context);
        MainHelper.showAppNotification(
            context: context, title: response.error!.message);
      }
  }
}

