// ignore_for_file: use_build_context_synchronously

import 'dart:ui';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/cloud_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/widgets/components_widgets/coins_payment_widget.dart';
import 'package:challenge/pages/home/settings_pages/blocked_users_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/models/GiftsSentModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/PostModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:expandable_text/expandable_text.dart';

import '../custom_widgets/button_with_icon.dart';
import '../custom_widgets/text_with_tap.dart';

class PostWidgets {
  static Widget postCard(
      {required BuildContext context,
      required PostsModel post,
      required UserModel currentUser,
      required bool clickable,
      required bool seeProfile,
      required bool seePrivateContent,
      Function()? openBottomSheet}) {
    return ContainerCorner(
      color: MainHelper.isDarkMode(context)
          ? kContentColorLightTheme
          : Colors.white,
      marginTop: 7,
      marginBottom: 0,
      borderWidth: 0,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: ContainerCorner(
                    marginTop: 10,
                    color: MainHelper.isDarkMode(context)
                        ? kContentColorLightTheme
                        : Colors.white,
                    marginLeft: 15,
                    onTap: () {
                      if (seeProfile) {
                        if (post.getAuthorId == currentUser.objectId!) {
                          MainHelper.goToNavigatorScreen(
                              context,
                              ProfilePage(
                                currentUser: currentUser,
                              ));
                        } else {
                          ActionsHelper.showUserProfile(
                              context, currentUser, post.getAuthor!);
                        }
                      }
                    },
                    child: Row(
                      children: [
                        ActionsHelper.avatarWidget(post.getAuthor!,
                            width: 50, height: 50),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWithTap(
                              post.getAuthor!.getFullName!,
                              marginLeft: 10,
                              fontWeight: FontWeight.bold,
                            ),
                            TextWithTap(
                              MainHelper.getTimeAgoForFeed(post.createdAt!),
                              marginLeft: 10,
                              marginTop: 8,
                              color: kGrayColor,
                              fontWeight: FontWeight.w500,
                              fontSize: 12,
                            ),
                          ],
                        ),
                      ],
                    )),
              ),
              ButtonWithIcon(
                text: "",
                iconURL: "assets/svg/ic_post_config.svg",
                iconColor: kGrayColor,
                backgroundColor: MainHelper.isDarkMode(context)
                    ? kContentColorLightTheme
                    : Colors.white,
                onTap: () {
                  openSheet(
                    currentUser: currentUser,
                    context: context,
                    post: post,
                    author: post.getAuthor!,
                  );
                },
                borderRadius: 50,
                width: 50,
                height: 50,
                urlIconColor: kGrayColor,
              ),
            ],
          ),
          if (post.getImage != null)
            Visibility(
              visible: post.getText!.isNotEmpty,
              child: Padding(
                padding: const EdgeInsets.only(top: 10, bottom: 5, left: 10),
                child: ExpandableText(
                  post.getExclusive! && seePrivateContent
                      ? "feed.private_post".tr()
                      : post.getText!,
                  expandText: 'auth.show_more'.tr(),
                  collapseText: 'auth.show_less'.tr(),
                  maxLines: 3,
                  linkColor: Colors.blue,
                  style: GoogleFonts.nunito(),
                ),
              ),
            ),
          GestureDetector(
            onTap: () {
              if (clickable) {
                _payForExclusivePost(
                    context: context, currentUser: currentUser, post: post);
              }
            },
            child: _postContent(
                post: post,
                context: context,
                seePrivateContent: seePrivateContent),
          ),
          Visibility(
            visible: post.getAngryList!.isNotEmpty ||
                post.getSadList!.isNotEmpty ||
                post.getLoves!.isNotEmpty ||
                post.getLikes!.isNotEmpty,
            child: Padding(
              padding: const EdgeInsets.only(top: 10, left: 20),
              child: GestureDetector(
                /*onTap: () => MainHelper.goToNavigatorScreen(
                    context,
                    ReactionAuthorsPage(
                      currentUser: currentUser,
                      post: post,
                    )),*/
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _reactionAccount(
                      lottieFile: 'assets/loties/facebook_like.json',
                      numberOfReaction: post.getLikes!.length,
                    ),
                    _reactionAccount(
                      lottieFile: 'assets/loties/ic_love_grand.json',
                      numberOfReaction: post.getLoves!.length,
                    ),
                    _reactionAccount(
                      lottieFile: 'assets/loties/sad.json',
                      numberOfReaction: post.getSadList!.length,
                    ),
                    _reactionAccount(
                      lottieFile: 'assets/loties/angry.json',
                      numberOfReaction: post.getAngryList!.length,
                    ),
                  ],
                ),
              ),
            ),
          ),
          ContainerCorner(
            marginTop: 5,
            height: 1,
            marginLeft: 15,
            marginRight: 15,
            color: MainHelper.isDarkMode(context)
                ? kTabIconDefaultColor.withOpacity(0.4)
                : kTabIconDefaultColor.withOpacity(0.4),
          ),
          ContainerCorner(
            color: MainHelper.isDarkMode(context)
                ? kContentColorLightTheme
                : Colors.white,
            child: Row(
              children: [
                const SizedBox(
                  width: 20,
                ),
                /*ReactionButton<String>(
                  onReactionChanged: (String? value) {
                    PostFunctions.postReact(
                        value: value!, post: post, currentUser: currentUser);
                  },
                  reactions: [
                    Reaction<String>(
                      value: 'like',
                      icon: Lottie.asset(
                        "assets/loties/like_grand.json",
                        height: 40,
                        width: 40,
                      ),
                    ),
                    Reaction<String>(
                      value: 'angry',
                      icon: Lottie.asset("assets/loties/angry.json",
                          height: 40, width: 40),
                    ),
                    Reaction<String>(
                      value: 'love',
                      icon: Lottie.asset("assets/loties/heart.json",
                          height: 40, width: 40),
                    ),
                    Reaction<String>(
                      value: 'sad',
                      icon: Lottie.asset("assets/loties/sad.json",
                          height: 40, width: 40),
                    ),
                  ],
                  initialReaction: Reaction<String>(
                    value: PostFunctions.getFirstValue(
                        post: post, currentUser: currentUser),
                    icon: PostFunctions.getFirstValue(
                                post: post, currentUser: currentUser) ==
                            "react"
                        ? TextWithTap(
                      "feed.react_".tr(),
                      fontWeight: FontWeight.w900,
                      color: kGrayColor,
                      fontSize: 15,
                    )
                        : Lottie.asset(
                            PostFunctions.getFirstIcon(
                                post: post, currentUser: currentUser),
                            height: 25,
                            width: 25,
                            repeat: false,
                            reverse: true,
                          ),
                  ),
                  boxColor: Colors.black.withOpacity(0.5),
                  boxRadius: 10,
                  boxDuration: const Duration(milliseconds: 100),
                  itemScaleDuration: const Duration(milliseconds: 100),
                ),*/
                ButtonWithIcon(
                  text: post.getComments!.length.toString(),
                  textColor: kTabIconDefaultColor,
                  urlIconColor: kTabIconDefaultColor,
                  iconURL: "assets/svg/ic_post_comment.svg",
                  onTap: () {
                    if (clickable) {
                      _payForExclusivePost(
                          context: context,
                          currentUser: currentUser,
                          post: post);
                    }
                  },
                  backgroundColor: MainHelper.isDarkMode(context)
                      ? kContentColorLightTheme
                      : Colors.white,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  static _payForExclusivePost(
      {required PostsModel post,
      required UserModel currentUser,
      required BuildContext context}) {
    if (!post.getExclusive!) {
      /*MainHelper.goToNavigatorScreen(
        context,
        CommentPostPage(
          currentUser: currentUser,
          post: post,
        ),
      );*/
    } else if (post.getExclusive! &&
            post.getAllowedToSee!.contains(currentUser.objectId) ||
        post.getAuthorId == currentUser.objectId) {
      /*MainHelper.goToNavigatorScreen(
        context,
        CommentPostPage(
          currentUser: currentUser,
          post: post,
        ),
      );*/
    } else {
      openPayPrivateLiveSheet(post, context, currentUser);
    }
  }

  static openPayPrivateLiveSheet(
      PostsModel post, BuildContext context, UserModel currentUser) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showPayPrivateLiveBottomSheet(post, context, currentUser);
        });
  }

  static Widget _showPayPrivateLiveBottomSheet(
      PostsModel post, BuildContext context, UserModel currentUser) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            minChildSize: 0.1,
            maxChildSize: 1.0,
            initialChildSize: 0.7,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Scaffold(
                    appBar: AppBar(
                      toolbarHeight: 35.0,
                      backgroundColor: kTransparentColor,
                      automaticallyImplyLeading: false,
                      elevation: 0,
                      actions: [
                        IconButton(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(Icons.close)),
                      ],
                    ),
                    backgroundColor: kTransparentColor,
                    body: Column(
                      children: [
                        Center(
                            child: TextWithTap(
                          "feed.private".tr(),
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 25,
                          marginBottom: 15,
                        )),
                        Center(
                          child: TextWithTap(
                            "feed.private_post_access_explain".tr(),
                            color: Colors.white,
                            fontSize: 16,
                            marginLeft: 20,
                            marginRight: 20,
                            marginTop: 20,
                          ),
                        ),
                        Expanded(
                            child: Lottie.network(
                                post.getPostPrivatePrice!.getFile!.url!,
                                width: 150,
                                height: 150,
                                animate: true,
                                repeat: true)),
                        ContainerCorner(
                          color: kTransparentColor,
                          marginTop: 1,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                "assets/svg/ic_coin_with_star.svg",
                                width: 24,
                                height: 24,
                              ),
                              TextWithTap(
                                post.getPostPrivatePrice!.getCoins.toString(),
                                color: Colors.white,
                                fontSize: 18,
                                marginLeft: 5,
                              )
                            ],
                          ),
                        ),
                        ContainerCorner(
                          borderRadius: 10,
                          height: 50,
                          width: 150,
                          color: kPrimaryColor,
                          onTap: () {
                            if (currentUser.getCredits! >=
                                post.getPostPrivatePrice!.getCoins!) {
                              _payForPrivatePost(
                                post: post,
                                context: context,
                                currentUser: currentUser,
                              );
                              //sendGift(live);

                            } else {
                              CoinsFlowPayment(
                                context: context,
                                currentUser: currentUser,
                                showOnlyCoinsPurchase: true,
                                onCoinsPurchased: (coins) {
                                  if (currentUser.getCredits! >=
                                      post.getPostPrivatePrice!.getCoins!) {
                                    _payForPrivatePost(
                                      post: post,
                                      context: context,
                                      currentUser: currentUser,
                                    );
                                  }
                                },
                              );
                            }
                          },
                          marginTop: 15,
                          marginBottom: 40,
                          child: Center(
                            child: TextWithTap(
                              "live_streaming.pay_for_live".tr(),
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  static _payForPrivatePost({
    required PostsModel post,
    required UserModel currentUser,
    required BuildContext context,
  }) async {
    MainHelper.showLoadingDialog(context);

    post.setAllowedToSee = currentUser.objectId!;
    post.save();

    GiftsSentModel giftsSentModel = GiftsSentModel();
    giftsSentModel.setAuthor = currentUser;
    giftsSentModel.setAuthorId = currentUser.objectId!;

    giftsSentModel.setReceiver = post.getAuthor!;
    giftsSentModel.setReceiverId = post.getAuthor!.objectId!;

    giftsSentModel.setGift = post.getPostPrivatePrice!;
    giftsSentModel.setGiftId = post.getPostPrivatePrice!.objectId!;
    giftsSentModel.setCounterDiamondsQuantity =
        post.getPostPrivatePrice!.getCoins!;

    await giftsSentModel.save();

    ParseResponse response = await CloudCodeHelper.sendGift(
        author: post.getAuthor!, credits: post.getPostPrivatePrice!.getCoins!);

    if (response.success) {
      updateCurrentUserCredit(post.getPostPrivatePrice!.getCoins!, post,
          giftsSentModel, currentUser, context);
      MainHelper.hideLoadingDialog(context);
      MainHelper.goBackToPreviousPage(context);
      /*MainHelper.goToNavigatorScreen(
        context,
        CommentPostPage(
          currentUser: currentUser,
          post: post,
        ),
      );*/
    } else {
      MainHelper.hideLoadingDialog(context);
    }
  }

  static updateCurrentUserCredit(
      int coins,
      PostsModel post,
      GiftsSentModel sentModel,
      UserModel currentUser,
      BuildContext context) async {
    currentUser.removeCredit = coins;
    ParseResponse userResponse = await currentUser.save();
    if (userResponse.success) {
      currentUser = userResponse.results!.first as UserModel;
    } else {
      MainHelper.hideLoadingDialog(context);
    }
  }

  static Widget _postContent(
      {required PostsModel post,
      required BuildContext context,
      required bool seePrivateContent}) {
    var size = MediaQuery.of(context).size;

    if (post.getImage != null) {
      return post.getExclusive! && seePrivateContent
          ? Stack(
              children: [
                ContainerCorner(
                  width: size.width,
                  marginTop: 10,
                  marginLeft: 20,
                  marginRight: 20,
                  height: 350,
                  imageDecoration: "assets/images/nacure.png",
                  borderRadius: 10,
                ),
                ClipRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(
                      sigmaX: 25,
                      sigmaY: 25,
                      tileMode: TileMode.repeated,
                    ),
                    child: ContainerCorner(
                      width: size.width,
                      marginTop: 10,
                      marginLeft: 20,
                      marginRight: 20,
                      height: 350,
                    ),
                  ),
                ),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Lottie.asset("assets/loties/private_post_creation.json",
                          height: size.width / 2, width: size.width / 2),
                      TextWithTap(
                        "feed.private_post".tr(),
                        color: Colors.white,
                      ),
                    ],
                  ),
                )
              ],
            )
          : Stack(
              alignment: AlignmentDirectional.center,
              children: [
                Container(
                  height: 300,
                  margin: const EdgeInsets.only(top: 5),
                  child: ActionsHelper.photosWidget(post.getImage!.url!,
                      borderRadius: 0, fit: BoxFit.cover),
                ),
                ClipRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(
                      sigmaX: 25,
                      sigmaY: 25,
                      tileMode: TileMode.repeated,
                    ),
                    child: ContainerCorner(
                      marginTop: 100,
                      height: 300,
                      width: MediaQuery.of(context).size.width,
                    ),
                  ),
                ),
                Opacity(
                    opacity: 0.01,
                    child: Image.asset(
                      "assets/images/noise.png",
                      fit: BoxFit.cover,
                      height: 300,
                      width: MediaQuery.of(context).size.width,
                    )),
                Container(
                  height: 350,
                  //width: 250,
                  margin: const EdgeInsets.only(top: 5),
                  child: ActionsHelper.photosWidget(post.getImage!.url!,
                      borderRadius: 10, fit: BoxFit.contain),
                ),
              ],
            );
    } else {
      return post.getExclusive! && seePrivateContent
          ? Stack(
              children: [
                ContainerCorner(
                  width: size.width,
                  marginTop: 10,
                  marginLeft: 20,
                  marginRight: 20,
                  height: 350,
                  imageDecoration: "assets/images/nacure.png",
                  borderRadius: 10,
                ),
                ClipRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(
                      sigmaX: 25,
                      sigmaY: 25,
                      tileMode: TileMode.repeated,
                    ),
                    child: ContainerCorner(
                      width: size.width,
                      marginTop: 10,
                      marginLeft: 20,
                      marginRight: 20,
                      height: 350,
                    ),
                  ),
                ),
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Lottie.asset("assets/loties/private_post_creation.json",
                          height: size.width / 2, width: size.width / 2),
                      TextWithTap(
                        "feed.private_post".tr(),
                        color: Colors.white,
                      ),
                    ],
                  ),
                )
              ],
            )
          : ContainerCorner(
              width: size.width,
              marginLeft: 20,
              marginTop: 10,
              borderRadius: 10,
              marginRight: 20,
              color: MainHelper.stringToColor(post.getBackgroundColor!),
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 10, right: 10, top: 20, bottom: 20),
                child: AutoSizeText(
                  post.getText!,
                  style: GoogleFonts.nunito(
                    fontSize: 30,
                    color: MainHelper.stringToColor(post.getTextColors!),
                  ),
                  minFontSize: 15,
                  stepGranularity: 5,
                  maxLines: 10,
                ),
              ),
            );
    }
  }

  static Widget _reactionAccount(
      {required int numberOfReaction, required String lottieFile}) {
    return Visibility(
      visible: numberOfReaction > 0,
      child: ContainerCorner(
        marginLeft: 7,
        child: Row(
          children: [
            TextWithTap(
              numberOfReaction.toString(),
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
            Lottie.asset(
              lottieFile,
              height: 20,
              width: 20,
              repeat: false,
              reverse: true,
            ),
          ],
        ),
      ),
    );
  }

  static openSheet(
      {required UserModel author,
      required PostsModel post,
      required BuildContext context,
      required UserModel currentUser}) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showPostOptionsAndReportAuthor(
            author: author,
            post: post,
            context: context,
            currentUser: currentUser,
          );
        });
  }

  static Widget _showPostOptionsAndReportAuthor(
      {required UserModel author,
      required PostsModel post,
      required BuildContext context,
      required UserModel currentUser}) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.4,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: ContainerCorner(
                    radiusTopRight: 20.0,
                    radiusTopLeft: 20.0,
                    color: MainHelper.isDarkMode(context)
                        ? kContentColorLightTheme
                        : Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Visibility(
                          visible: currentUser.objectId != author.objectId,
                          child: ButtonWithIcon(
                            text: "feed.report_post".tr(),
                            iconURL: "assets/svg/ic_blocked_menu.svg",
                            height: 60,
                            radiusTopLeft: 25.0,
                            radiusTopRight: 25.0,
                            backgroundColor: Colors.white,
                            mainAxisAlignment: MainAxisAlignment.start,
                            textColor: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            onTap: () {
                              openReportMessage(
                                  author, post, context, currentUser);
                            },
                          ),
                        ),
                        Visibility(
                            visible: currentUser.objectId != author.objectId,
                            child: const Divider()),
                        Visibility(
                          visible: currentUser.objectId != author.objectId,
                          child: ButtonWithIcon(
                            text: "feed.block_user".tr(),
                            textColor: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            iconURL: "assets/svg/star.svg",
                            onTap: () {
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                top: 15.0),
                                            child: ActionsHelper.avatarWidget(
                                                author,
                                                width: 130,
                                                height: 130),
                                          ),
                                          TextWithTap(
                                            author.getFullName!,
                                            textAlign: TextAlign.center,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          TextWithTap(
                                            "feed.block_user_confirm".tr(),
                                            textAlign: TextAlign.center,
                                          ),
                                          const SizedBox(
                                            height: 35,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              ContainerCorner(
                                                color: kRedColor1,
                                                borderRadius: 10,
                                                marginLeft: 5,
                                                width: 125,
                                                child: TextButton(
                                                  child: TextWithTap(
                                                    "cancel".tr().toUpperCase(),
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14,
                                                  ),
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                    Navigator.of(context).pop();
                                                  },
                                                ),
                                              ),
                                              ContainerCorner(
                                                color: kGreenColor,
                                                borderRadius: 10,
                                                marginRight: 5,
                                                width: 125,
                                                child: TextButton(
                                                  child: TextWithTap(
                                                    "confirm_"
                                                        .tr()
                                                        .toUpperCase(),
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14,
                                                  ),
                                                  onPressed: () => _blockUser(
                                                      author,
                                                      context,
                                                      currentUser),
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 20),
                                        ],
                                      ),
                                    );
                                  });
                            },
                            height: 60,
                            backgroundColor: Colors.white,
                            mainAxisAlignment: MainAxisAlignment.start,
                          ),
                        ),
                        Visibility(
                            visible: currentUser.objectId != author.objectId,
                            child: const Divider()),
                        Visibility(
                          visible: currentUser.objectId == author.objectId,
                          child: ButtonWithIcon(
                            text: "feed.delete_post".tr(),
                            iconURL: "assets/svg/config.svg",
                            height: 60,
                            radiusTopLeft: 25.0,
                            radiusTopRight: 25.0,
                            backgroundColor: Colors.white,
                            mainAxisAlignment: MainAxisAlignment.start,
                            textColor: Colors.black,
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            onTap: () {
                              _deletePost(post, context, currentUser);
                            },
                          ),
                        ),
                        Visibility(
                            visible: currentUser.objectId == author.objectId,
                            child: const Divider()),
                      ],
                    ),
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  static _blockUser(
      UserModel author, BuildContext context, UserModel currentUser) async {
    MainHelper.showLoadingDialog(context);

    currentUser.setBlockedUser = author;
    currentUser.setBlockedUserIds = author.objectId!;

    ParseResponse response = await currentUser.save();
    if (response.success) {
      Navigator.of(context).pop();
      Navigator.of(context).pop();
      MainHelper.hideLoadingDialog(context);
      MainHelper.goToNavigator(context, BlockedUsersPage.route);
    }
  }

  static openReportMessage(UserModel author, PostsModel post,
      BuildContext context, UserModel currentUser) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showReportMessageBottomSheet(
              author, post, context, currentUser);
        });
  }

  static Widget _showReportMessageBottomSheet(UserModel author, PostsModel post,
      BuildContext context, UserModel currentUser) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.7,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: ContainerCorner(
                    radiusTopRight: 20.0,
                    radiusTopLeft: 20.0,
                    color: MainHelper.isDarkMode(context)
                        ? kContentColorLightTheme
                        : Colors.white,
                    child: Column(
                      children: [
                        const ContainerCorner(
                          color: kGreyColor1,
                          width: 50,
                          marginTop: 5,
                          borderRadius: 50,
                          marginBottom: 10,
                        ),
                        TextWithTap(
                          "feed.report_".tr(),
                          fontWeight: FontWeight.w900,
                          fontSize: 20,
                          marginBottom: 50,
                        ),
                        Column(
                          children: List.generate(
                              MainHelper.getReportCodeMessageList().length,
                              (index) {
                            String code =
                                MainHelper.getReportCodeMessageList()[index];

                            return TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                                Navigator.of(context).pop();
                                _saveReport(MainHelper.getReportMessage(code),
                                    post.objectId!, context, currentUser);
                              },
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      TextWithTap(
                                        MainHelper.getReportMessage(code),
                                        color: kGrayColor,
                                        fontSize: 15,
                                        marginBottom: 5,
                                      ),
                                      const Icon(
                                        Icons.arrow_forward_ios,
                                        size: 18,
                                        color: kGrayColor,
                                      ),
                                    ],
                                  ),
                                  const Divider(
                                    height: 1.0,
                                  )
                                ],
                              ),
                            );
                          }),
                        ),
                        ContainerCorner(
                          marginTop: 30,
                          child: TextButton(
                            onPressed: () => Navigator.of(context).pop(),
                            child: TextWithTap(
                              "cancel".tr().toUpperCase(),
                              color: kGrayColor,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  static _saveReport(String reason, String postID, BuildContext context,
      UserModel currentUser) async {
    MainHelper.showLoadingDialog(context);

    currentUser.setReportedPostIDs = postID;
    currentUser.setReportedPostReason = reason;

    ParseResponse response = await currentUser.save();
    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      //setState(() {});
    }
  }

  static _deletePost(
      PostsModel post, BuildContext context, UserModel currentUser) {
    MainHelper.goBackToPreviousPage(context);

    MainHelper.showDialogWithButtonCustom(
      context: context,
      title: "feed.delete_post_alert".tr(),
      message: "feed.delete_post_message".tr(),
      cancelButtonText: "no".tr(),
      confirmButtonText: "feed.yes_delete".tr(),
      onPressed: () => _confirmDeletePost(post, context, currentUser),
    );
  }

  static _confirmDeletePost(PostsModel postsModel, BuildContext context,
      UserModel currentUser) async {
    MainHelper.goBackToPreviousPage(context);

    MainHelper.showLoadingDialog(context);

    ParseResponse parseResponse = await postsModel.delete();
    if (parseResponse.success) {
      MainHelper.goBackToPreviousPage(context);

      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "deleted".tr(),
        message: "feed.post_deleted".tr(),
        user: currentUser,
        isError: null,
      );
    } else {
      MainHelper.goBackToPreviousPage(context);

      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "feed.post_not_deleted".tr(),
        user: currentUser,
        isError: true,
      );
    }
  }
}
