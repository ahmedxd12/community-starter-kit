// ignore_for_file: must_be_immutable, iterable_contains_unrelated_type, avoid_function_literals_in_foreach_calls, depend_on_referenced_packages, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:lottie/lottie.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/coins_pages/coins_page.dart';
import 'package:challenge/models/GiftsModel.dart';
import 'package:challenge/models/PaymentsModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/others/in_app_model.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';

import '../../configurations/global_config.dart';
import '../../configurations/global_setup.dart';
import '../custom_widgets/text_with_tap.dart';

class CoinsFlowPayment {
  CoinsFlowPayment(
      {required BuildContext context,
      required UserModel currentUser,
      Function(GiftsModel giftsModel)? onGiftSelected,
      Function(int coins)? onCoinsPurchased,
      bool isDismissible = true,
      bool enableDrag = true,
      bool isScrollControlled = true,
      bool showOnlyCoinsPurchase = false,
      Color backgroundColor = Colors.transparent}) {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: isScrollControlled,
        backgroundColor: backgroundColor,
        enableDrag: enableDrag,
        isDismissible: isDismissible,
        builder: (context) {
          return _CoinsFlowWidget(
            currentUser: currentUser,
            onCoinsPurchased: onCoinsPurchased,
            onGiftSelected: onGiftSelected,
            showOnlyCoinsPurchase: showOnlyCoinsPurchase,
          );
        });
  }
}

class _CoinsFlowWidget extends StatefulWidget {
  final Function? onCoinsPurchased;
  final Function? onGiftSelected;
  final bool? showOnlyCoinsPurchase;
  UserModel currentUser;

  _CoinsFlowWidget({
    required this.currentUser,
    this.onCoinsPurchased,
    this.onGiftSelected,
    this.showOnlyCoinsPurchase = false,
  });

  @override
  State<_CoinsFlowWidget> createState() => _CoinsFlowWidgetState();
}

class _CoinsFlowWidgetState extends State<_CoinsFlowWidget>
    with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;
  AnimationController? _animationController;
  int bottomSheetCurrentIndex = 0;
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
  late StreamSubscription<List<PurchaseDetails>> _subscription;
  bool _isAvailable = false;
  bool _purchasePending = false;
  bool _loading = true;
  String? _queryProductError;
  List<ProductDetails> _products = [];
  InAppPurchaseModel? _inAppPurchaseModel;

  final String testID = Setup.appName;

  final List<String> _kProductIds = <String>[
    Config.credit200,
    Config.credit1000,
    Config.credit100,
    Config.credit500,
    Config.credit2200,
    Config.credit5260,
    Config.credit10600,
  ];

  List bgImages = [
    "assets/images/img_credit_7.png",
    "assets/images/img_credit_2.png",
    "assets/images/img_credit_6.png",
    "assets/images/img_credit_4.png",
    "assets/images/img_credit_5.png",
    "assets/images/img_credit_3.png",
    "assets/images/img_credit_1.png"
  ];

  List<InAppPurchaseModel> getInAppList() {
    List<InAppPurchaseModel> inAppPurchaseList = [];

    for (ProductDetails productDetails in _products) {

      if (productDetails.id == Config.credit200) {
        InAppPurchaseModel credits200 = InAppPurchaseModel(
            id: Config.credit200,
            coins: 200,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typePopular,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit200)) {
          inAppPurchaseList.add(credits200);
        }
      }

      if (productDetails.id == Config.credit1000) {
        InAppPurchaseModel credits1000 = InAppPurchaseModel(
            id: Config.credit1000,
            coins: 1000,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeHot,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit1000)) {
          inAppPurchaseList.add(credits1000);
        }
      }

      if (productDetails.id == Config.credit100) {
        InAppPurchaseModel credits100 = InAppPurchaseModel(
            id: Config.credit100,
            coins: 100,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit100)) {
          inAppPurchaseList.add(credits100);
        }
      }

      if (productDetails.id == Config.credit500) {
        InAppPurchaseModel credits500 = InAppPurchaseModel(
            id: Config.credit500,
            coins: 500,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit500)) {
          inAppPurchaseList.add(credits500);
        }
      }

      if (productDetails.id == Config.credit2200) {
        InAppPurchaseModel credits2100 = InAppPurchaseModel(
            id: Config.credit2200,
            coins: 2200,
            price: productDetails.price,
            discount: "22,09",
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit2200)) {
          inAppPurchaseList.add(credits2100);
        }
      }

      if (productDetails.id == Config.credit5260) {
        InAppPurchaseModel credits5250 = InAppPurchaseModel(
            id: Config.credit5260,
            coins: 5260,
            price: productDetails.price,
            discount: "57,79",
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit5260)) {
          inAppPurchaseList.add(credits5250);
        }
      }

      if (productDetails.id == Config.credit10600) {
        InAppPurchaseModel credits10500 = InAppPurchaseModel(
            id: Config.credit10600,
            coins: 10600,
            price: productDetails.price,
            discount: "110,29",
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit10600)) {
          inAppPurchaseList.add(credits10500);
        }
      }
    }

    return inAppPurchaseList;
  }

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController.unbounded(vsync: this);

    final Stream<List<PurchaseDetails>> purchaseUpdated =
        _inAppPurchase.purchaseStream;

    _subscription = purchaseUpdated.listen(
      (purchaseDetailsList) {
        _listenToPurchaseUpdated(purchaseDetailsList);
      },
      onDone: () {
        _subscription.cancel();
      },
      onError: (error) {
        // handle error here.
      },
    );
    //getUser();
    initStoreInfo();
  }

  @override
  void dispose() {
    if (MainHelper.isIOSPlatform()) {
      var iosPlatformAddition = _inAppPurchase
          .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      iosPlatformAddition.setDelegate(null);
    }
    _subscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _showGiftAndGetCoinsBottomSheet();
    //return getBody();
  }

  Future<void> initStoreInfo() async {
    final bool isAvailable = await _inAppPurchase.isAvailable();

    if (!isAvailable) {
      setState(() {
        _isAvailable = isAvailable;
        _products = [];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (MainHelper.isIOSPlatform()) {
      var iosPlatformAddition = _inAppPurchase
          .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iosPlatformAddition.setDelegate(IOSPaymentQueueDelegate());
    }

    ProductDetailsResponse productDetailResponse =
        await _inAppPurchase.queryProductDetails(_kProductIds.toSet());

    if (productDetailResponse.error != null) {
      setState(() {
        _queryProductError = productDetailResponse.error!.message;
        _isAvailable = isAvailable;
        _products = productDetailResponse.productDetails;
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (productDetailResponse.productDetails.isEmpty) {
      setState(() {
        _queryProductError = null;
        _isAvailable = isAvailable;
        _products = productDetailResponse.productDetails;
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    setState(() {
      _isAvailable = isAvailable;
      _products = productDetailResponse.productDetails;
      _purchasePending = false;
      _loading = false;
    });
  }

  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        showPendingUI();
      } else {
        if (purchaseDetails.status == PurchaseStatus.canceled) {
          MainHelper.hideLoadingDialog(context);

          MainHelper.showAppNotificationAdvanced(
            context: context,
            user: widget.currentUser,
            title: "in_app_purchases.purchase_cancelled_title".tr(),
            message: "in_app_purchases.purchase_cancelled".tr(),
          );
        } else if (purchaseDetails.status == PurchaseStatus.error) {
          handleError(purchaseDetails.error!);
        } else if (purchaseDetails.status == PurchaseStatus.purchased ||
            purchaseDetails.status == PurchaseStatus.restored) {
          bool valid = await _verifyPurchase(purchaseDetails);
          if (valid) {
            _addPurchaseToUserAccount(purchaseDetails);
          } else {
            _handleInvalidPurchase(purchaseDetails);
          }
        }

        if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
        }
      }
    });
  }

  _purchaseProduct(ProductDetails productDetails) async {
    if (MainHelper.isAndroidPlatform()) {
      MainHelper.showLoadingDialog(context);
    }

    _inAppPurchase
        .buyConsumable(
            purchaseParam: PurchaseParam(productDetails: productDetails),
            autoConsume: true)
        .onError((error, stackTrace) {
      if (error is PlatformException &&
          error.code == "storekit_duplicate_product_object") {
        MainHelper.showAppNotification(
          context: context,
          title: "in_app_purchases.purchase_pending_error".tr(),
        );
      }
      return false;
    });
  }

  Future<bool> _verifyPurchase(PurchaseDetails purchaseDetails) async {
    // IMPORTANT!! Always verify a purchase before delivering the product.
    // For the purpose of an example, we directly return true.
      QueryBuilder<PaymentsModel> query = QueryBuilder(PaymentsModel());
      query.whereEqualTo(PaymentsModel.keyItemTransactionId,
          purchaseDetails.productID);

      ParseResponse response = await query.query();

      if(response.success){
        if(response.results != null){
          return Future<bool>.value(false);
        }else{
          return Future<bool>.value(true);
        }
      }else{
        return Future<bool>.value(true);
      }
  }

  void _handleInvalidPurchase(PurchaseDetails purchaseDetails) {
    // handle invalid purchase here if  _verifyPurchase` failed.
    MainHelper.showAppNotification(
        context: context, title: "in_app_purchases.invalid_purchase".tr());
    MainHelper.hideLoadingDialog(context);
  }

  _addPurchaseToUserAccount(PurchaseDetails purchaseDetails) async {
    _inAppPurchase.completePurchase(purchaseDetails);

    if (MainHelper.isAndroidPlatform()) {
      final InAppPurchaseAndroidPlatformAddition androidAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseAndroidPlatformAddition>();

      await androidAddition.consumePurchase(purchaseDetails);
    }

    // This line may be replaced by:
    // widget.currentUser.addCredit = _inAppPurchaseModel!.getCoins!;
    widget.currentUser.addCredit = _inAppPurchaseModel!.coins!;
    ParseResponse parseResponse = await widget.currentUser.save();

    if (parseResponse.success) {
      UserModel user = parseResponse.results!.first as UserModel;
      widget.currentUser = user;

      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        context: context,
        user: widget.currentUser,
        title: "in_app_purchases.coins_purchased"
            .tr(namedArgs: {"coins": _inAppPurchaseModel!.coins!.toString()}),
        message: "in_app_purchases.coins_added_to_account".tr(),
        isError: false,
      );

      if (widget.onCoinsPurchased != null) {
        if (widget.showOnlyCoinsPurchase!) {
          Navigator.of(context).pop();
        } else {
          setState(() {
            bottomSheetCurrentIndex = 0;
          });
        }
        widget.onCoinsPurchased!(_inAppPurchaseModel!.coins) as void
            Function()?;
      }

      registerPayment(purchaseDetails, _inAppPurchaseModel!.productDetails!);
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotification(
          context: context, title: "in_app_purchases.error_found".tr());
    }
  }

  void registerPayment(
      PurchaseDetails purchaseDetails, ProductDetails productDetails) async {
    // Save all payment information
    PaymentsModel paymentsModel = PaymentsModel();
    paymentsModel.setAuthor = widget.currentUser;
    paymentsModel.setAuthorId = widget.currentUser.objectId!;
    paymentsModel.setPaymentType = PaymentsModel.paymentTypeConsumible;

    paymentsModel.setId = productDetails.id;
    paymentsModel.setTitle = productDetails.title;
    paymentsModel.setTransactionId = purchaseDetails.purchaseID!;
    paymentsModel.setCurrency = productDetails.currencyCode.toUpperCase();
    paymentsModel.setPrice = productDetails.price;
    paymentsModel.setMethod = MainHelper.isAndroidPlatform()
        ? "Google Play"
        : MainHelper.isIOSPlatform()
            ? "App Store"
            : "";
    paymentsModel.setStatus = PaymentsModel.paymentStatusCompleted;

    await paymentsModel.save();
  }

  void handleError(IAPError error) {
    MainHelper.hideLoadingDialog(context);
    MainHelper.showAppNotification(context: context, title: error.message);

    setState(() {
      _purchasePending = false;
    });
  }

  showPendingUI() {
    MainHelper.showLoadingDialog(context);
  }

  Widget _showGiftAndGetCoinsBottomSheet() {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.67,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Stack(
                  children: [
                    ContainerCorner(
                      borderWidth: 0,
                      color: Colors.black.withOpacity(0.4),
                      width: size.width,
                      height: size.height,
                      radiusTopRight: 25,
                      radiusTopLeft: 25,
                      imageDecoration: "assets/images/app_bg.png",
                    ),
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(25),
                        topLeft: Radius.circular(25),
                      ),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                        child: ContainerCorner(
                            color: kTransparentColor,
                            height: size.height,
                            width: size.width),
                      ),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        color: kTransparentColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25.0),
                          topRight: Radius.circular(25.0),
                        ),
                      ),
                      child: ContainerCorner(
                        color: kTransparentColor,
                        child: IndexedStack(
                          index: widget.showOnlyCoinsPurchase!
                              ? 1
                              : bottomSheetCurrentIndex,
                          children: [
                            showGiftsList(),
                            showProductsList(),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              });
            },
          ),
        ),
      ),
    );
  }

  Widget showGiftsList() {
    return Scaffold(
      backgroundColor: kTransparentColor,
      appBar: AppBar(
        actions: [
          ContainerCorner(
            height: 30,
            borderRadius: 50,
            marginRight: 10,
            marginTop: 10,
            marginBottom: 10,
            color: kPrimaryColor,
            onTap: () {
              setState(() {
                bottomSheetCurrentIndex = 1;
              });
            },
            child: Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: SvgPicture.asset(
                    "assets/svg/coin.svg",
                    width: 20,
                    height: 20,
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.only(right: 10,left: 2),
                  child: Icon(
                    Icons.add,
                    size: 25,
                  ),
                ),
              ],
            ),
          )
        ],
        backgroundColor: kTransparentColor,
        // centerTitle: true,
        title: Row(
          children: [
            SvgPicture.asset(
              "assets/svg/ic_coin_with_star.svg",
              width: 20,
              height: 20,
            ),
            TextWithTap(
              widget.currentUser.getCredits.toString(),
              color: Colors.white,
              fontSize: 16,
              marginLeft: 5,
            )
          ],
        ),
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: const Icon(Icons.close),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(8.0,0,8.0,8.0),
        child: getAllGifts(setState),
      ),
    );
  }

  Widget showProductsList() {
    return Scaffold(
      backgroundColor: kTransparentColor,
      appBar: AppBar(
        actions: [
          Row(
            children: [
              SvgPicture.asset(
                "assets/svg/ic_coin_with_star.svg",
                width: 20,
                height: 20,
              ),
              TextWithTap(
                widget.currentUser.getCredits.toString(),
                color: Colors.white,
                marginLeft: 5,
                marginRight: 15,
              )
            ],
          ),
        ],
        backgroundColor: kTransparentColor,
        title: TextWithTap(
          "message_screen.get_coins".tr(),
          marginRight: 10,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leading: IconButton(
          onPressed: () {
            if (widget.showOnlyCoinsPurchase!) {
              Navigator.of(context).pop();
            } else {
              setState(() {
                bottomSheetCurrentIndex = 0;
              });
            }
          },
          icon: const Icon(Icons.arrow_back),
        ),
      ),
      body: getBody(),//getBody(),
    );
  }

  Widget noViewersGifts() {
    return TextWithTap(
      'live_streaming.no_gifts'.tr(),
      fontSize: size.width / 22,
      textAlign: TextAlign.center,
      color: kContentColorDarkTheme,
      marginTop: size.height * 0.25,
    );
  }

  Widget getGifts(String category, StateSetter setState) {
    QueryBuilder<GiftsModel> giftQuery = QueryBuilder<GiftsModel>(GiftsModel());
    giftQuery.whereValueExists(GiftsModel.keyGiftCategories, true);
    giftQuery.whereEqualTo(GiftsModel.keyGiftCategories, category);

    return ContainerCorner(
      color: kTransparentColor,
      child: ParseLiveGridWidget<GiftsModel>(
        query: giftQuery,
        crossAxisCount: 4,
        reverse: false,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
        lazyLoading: false,
        //childAspectRatio: 1.0,
        shrinkWrap: true,
        listenOnAllSubItems: true,
        duration: const Duration(seconds: 0),
        animationController: _animationController,
        childBuilder: (BuildContext context,
            ParseLiveListElementSnapshot<GiftsModel> snapshot) {
          GiftsModel gift = snapshot.loadedData!;
          return GestureDetector(
            onTap: () => _checkCredits(gift, setState),
            child: Column(
              children: [
                Lottie.network(gift.getFile!.url!,
                    width: 80, height: 80, animate: true, repeat: true),
                ContainerCorner(
                  color: kTransparentColor,
                  marginTop: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        "assets/svg/ic_coin_with_star.svg",
                        width: 18,
                        height: 18,
                      ),
                      TextWithTap(
                        gift.getCoins.toString(),
                        color: Colors.white,
                        fontSize: 14,
                        marginLeft: 5,
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        },
        queryEmptyElement: Padding(
          padding: const EdgeInsets.all(8.0),
          child: noViewersGifts(),
        ),
        gridLoadingElement: Container(
          margin: const EdgeInsets.only(top: 50),
          alignment: Alignment.topCenter,
          child: const CircularProgressIndicator(),
        ),
      ),
    );
  }

  Tab gefTab(String name, String image) {
    return Tab(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            image,
            color: Colors.white.withOpacity(0.7),
            width: 20,
            height: 20,
          ),
          TextWithTap(
            name,
            fontSize: 12,
            marginTop: 5,
          ),
        ],
      ),
    );
  }

  Widget getAllGifts(StateSetter setState) {
    QueryBuilder<GiftsModel> giftQuery = QueryBuilder<GiftsModel>(GiftsModel());

    return ContainerCorner(
      color: kTransparentColor,
      child: ParseLiveGridWidget<GiftsModel>(
        query: giftQuery,
        crossAxisCount: 3,
        reverse: false,
        crossAxisSpacing: 8,
        mainAxisSpacing: 7,
        lazyLoading: false,
        shrinkWrap: true,
        listenOnAllSubItems: true,
        duration: const Duration(seconds: 0),
        animationController: _animationController,
        childBuilder: (BuildContext context,
            ParseLiveListElementSnapshot<GiftsModel> snapshot) {
          GiftsModel gift = snapshot.loadedData!;

          return GestureDetector(
            onTap: () => _checkCredits(gift, setState),
            child: ContainerCorner(
              color: kButtonTextColor.withOpacity(0.4),
              borderRadius: 10.0,
              child: Column(
                children: [
                  Expanded(
                    child: Lottie.network(gift.getFile!.url!,
                        width: 100, height: 100, animate: true, repeat: true),
                  ),
                  ContainerCorner(
                    color: kTransparentColor,
                    marginTop: 1,
                    marginBottom: 10,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          "assets/svg/ic_coin_with_star.svg",
                          width: 19,
                          height: 19,
                        ),
                        TextWithTap(
                          gift.getCoins.toString(),
                          color: Colors.white,
                          fontSize: 16,
                          marginLeft: 5,
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
        queryEmptyElement: Padding(
          padding: const EdgeInsets.all(8.0),
          child: noViewersGifts(),
        ),
        gridLoadingElement: Container(
          margin: const EdgeInsets.only(top: 50),
          alignment: Alignment.topCenter,
          child: const CircularProgressIndicator(),
        ),
      ),
    );
  }

  Widget getProductList() {
    var size = MediaQuery.of(context).size;

    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(bottom: 100),
      children: [
        const SizedBox(
          height: 3,
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5),
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: List.generate(getInAppList().length, (index) {
                InAppPurchaseModel inApp = getInAppList()[index];

                return GestureDetector(
                  onTap: () {
                    _inAppPurchaseModel = inApp;
                    _purchaseProduct(inApp.getProductDetails()!);
                  },
                  child: ContainerCorner(
                    width: size.width * 0.30,
                    height: size.width * 0.2,
                    // imageDecoration: bgImages[index],
                    color: kButtonTextColor,
                    borderWidth: 0,
                    borderRadius: 10,
                    child: Stack(
                      children: [
                        ContainerCorner(
                            width: size.width * 0.30,
                            height: size.width * 0.2,
                            borderWidth: 0,
                            borderRadius: 10,
                            color: kTransparentColor,
                            child: Stack(
                                alignment: AlignmentDirectional.center,
                                children: [
                                  Positioned(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: [
                                            SvgPicture.asset(
                                              "assets/svg/ic_coin_with_star.svg",
                                              height: size.width / 27,
                                              width: size.width / 27,
                                            ),
                                            TextWithTap(
                                              "${inApp.coins}",
                                              fontSize: 18,
                                              marginLeft: 10,
                                              color:
                                              Colors.white.withOpacity(0.8),
                                            ),
                                          ],
                                        ),
                                        TextWithTap(
                                          inApp.price!,
                                          fontWeight: FontWeight.bold,
                                          fontSize: size.width / 25,
                                          marginTop: 12,
                                          color: Colors.white.withOpacity(0.8),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ]))
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        )
      ],
    );
  }

  Widget getBody() {
    if (_purchasePending) {}

    if (_loading) {
      return MainHelper.appLoading();
    } else if (_isAvailable && _products.isNotEmpty) {
      if (_queryProductError == null) {
        return getProductList();
      } else {
        return noProducts(_queryProductError.toString());
      }
    } else {
      return noProducts("in_app_purchases.no_product_found_title".tr());
    }
  }

  _checkCredits(GiftsModel gift, StateSetter setState) {
    if (widget.currentUser.getCredits! >= gift.getCoins!) {
      if (widget.onGiftSelected != null) {
        widget.onGiftSelected!(gift) as void Function()?;
        // Navigator.of(context).pop();
      }
    } else {
      setState(() {
        bottomSheetCurrentIndex = 1;
      });
    }
  }

  Widget noProducts(String message) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextWithTap(
          message,
          fontSize: size.width / 22,
          textAlign: TextAlign.center,
          color: kContentColorDarkTheme,
          marginTop: size.height * 0.25,
        ),
      ],
    );
  }
}
