import 'package:challenge/pages/authentication/forgot_password_page.dart';
import 'package:challenge/pages/home/home_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:flutter/material.dart';

import '../pages/authentication/signin_page.dart';
import '../pages/authentication/signup_page.dart';
import '../pages/home/challenge_pages/start_challenge_page.dart';
import '../pages/home/coins_pages/refill_coins_page.dart';
import '../pages/home/livestreaming_pages/live_creation_page.dart';
import '../pages/home/message_pages/group_creation_page.dart';
import '../pages/home/message_pages/message_goup_page.dart';
import '../pages/home/message_pages/message_list_page.dart';
import '../pages/home/message_pages/message_page.dart';
import '../pages/home/message_pages/send_picture_page.dart';
import '../pages/home/notifications_pages/notifications_page.dart';
import '../pages/home/profile_pages/followers_page.dart';
import '../pages/home/profile_pages/followings_page.dart';
import '../pages/home/profile_pages/profile_edit_page.dart';
import '../pages/home/profile_pages/profile_page.dart';
import '../pages/home/profile_pages/user_profile_page.dart';
import '../pages/home/search_pages/search_user_challenge_page.dart';
import '../pages/home/settings_pages/account_settings_page.dart';
import '../pages/home/settings_pages/app_settings_page.dart';
import '../pages/home/settings_pages/blocked_users_page.dart';
import '../pages/home/settings_pages/delete_account_page.dart';
import '../pages/home/settings_pages/earn_credit.dart';
import '../pages/home/settings_pages/get_money_page.dart';
import '../pages/home/settings_pages/referral_program_page.dart';
import '../pages/home/settings_pages/settings_page.dart';
import '../pages/home/settings_pages/widrawal_history_page.dart';
import '../pages/home/stories_page/create_text_story_page.dart';
import '../pages/home/stories_page/see_one_story_page.dart';
import '../pages/home/stories_page/see_stories_page.dart';
import '../pages/home/stories_page/stories_page.dart';
import '../pages/home/stories_page/story_type_chooser_page.dart';
import '../pages/home/video_pages/accept_challenge_page.dart';
import '../pages/home/video_pages/all_video_page.dart';
import '../pages/home/video_pages/approve_upload.dart';
import '../pages/home/video_pages/elimination_videos_page.dart';
import '../pages/home/video_pages/friends_videos_page.dart';
import '../pages/home/video_pages/upload_video_page.dart';
import '../pages/home/video_pages/watch_video_page.dart';
import '../pages/home/web_view_pages/web_url_page.dart';

class AppRouter {
  static final RouteObserver<PageRoute> routeObserver = RouteObserver();

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {

      case SignInPage.route:
        return MaterialPageRoute(builder: (_) => const SignInPage());
      case ForgotPasswordPage.route:
        return MaterialPageRoute(builder: (_) => const ForgotPasswordPage());
      case MainHelper.pageTypeTerms:
        return MaterialPageRoute(builder: (_) => const WebViewPage(pageType: MainHelper.pageTypeTerms));
      case MainHelper.pageTypePrivacy:
        return MaterialPageRoute(builder: (_) => const WebViewPage(pageType: MainHelper.pageTypePrivacy));
      case MainHelper.pageTypeWhatsapp:
        return MaterialPageRoute(builder: (_) => const WebViewPage(pageType: MainHelper.pageTypeWhatsapp));
      case MainHelper.pageTypeInstructions:
        return MaterialPageRoute(builder: (_) => const WebViewPage(pageType: MainHelper.pageTypeInstructions));
      case MainHelper.pageTypeSupport:
        return MaterialPageRoute(builder: (_) => const WebViewPage(pageType: MainHelper.pageTypeSupport));
      case MainHelper.pageTypeCashOut:
        return MaterialPageRoute(builder: (_) => const WebViewPage(pageType: MainHelper.pageTypeCashOut));

      case HomePage.route:
        return MaterialPageRoute(builder: (_) => HomePage());


      default:
        return MaterialPageRoute(
            builder: (_) => Scaffold(
              body: Center(
                  child: Text('No route defined for ${settings.name}')),
            ));
    }
  }

  static Map<String, Widget Function(BuildContext)> routes = {
    //Before Login
    SignInPage.route: (_) => const SignInPage(),
    ForgotPasswordPage.route: (_) => const ForgotPasswordPage(),
    SignUpPage.route: (_) => const SignUpPage(),

    // Home and tabs
    HomePage.route: (_) => HomePage(),

    // Notifications
    NotificationsPage.route: (_) => NotificationsPage(),

    //Challenges
    StartChallengePage.route: (_) => StartChallengePage(),

    //Profile
    ProfilePage.route: (_) => ProfilePage(),
    ProfileEditPage.route: (_) => ProfileEditPage(),
    UserProfilePage.route: (_) => UserProfilePage(),
    FollowingsPage.route: (_) => FollowingsPage(),
    FollowersPage.route: (_) => FollowersPage(),

    //Chat
    MessagesListPage.route: (_) => const MessagesListPage(),
    MessagePage.route: (_) => MessagePage(),
    SendPicturePage.route: (_) => SendPicturePage(),
    GroupCreationPage.route: (_) => GroupCreationPage(),
    GroupMessagePage.route: (_) => GroupMessagePage(),

    //Stories
    SeeStoriesPage.route: (_) => const SeeStoriesPage(),
    SeeOneStory.route: (_) => const SeeOneStory(),
    StoriesPage.route: (_) => const StoriesPage(),
    StoryTypeChooserPage.route: (_) => const StoryTypeChooserPage(),
    CreateTextStoryPage.route: (_) => const CreateTextStoryPage(),

    //LiveStreaming
    LiveCreationPage.route: (_) => const LiveCreationPage(),

    //Video
    AllVideosPage.route: (_) => const AllVideosPage(),
    UploadVideoPage.route: (_) => UploadVideoPage(),
    WatchVideoPage.route: (_) => WatchVideoPage(),
    VideoEliminationPage.route: (_) => const VideoEliminationPage(),
    FriendsVideoPage.route: (_) => const FriendsVideoPage(),
    ApproveVideoPage.route: (_) => ApproveVideoPage(),
    AcceptChallengePage.route: (_) => AcceptChallengePage(),

    //Settings
    AccountSettingsPage.route: (_) => const AccountSettingsPage(),
    AppSettingsPage.route: (_) => const AppSettingsPage(),
    DeleteAccountPage.route: (_) => const DeleteAccountPage(),

    // Profile Menu
    ReferralPage.route: (_) => ReferralPage(),
    BlockedUsersPage.route: (_) => BlockedUsersPage(),
    RefillCoinsPage.route: (_) => RefillCoinsPage(),
    GetMoneyPage.route: (_) => GetMoneyPage(),
    SettingsPage.route: (_) => SettingsPage(),
    WithdrawHistoryPage.route: (_) => WithdrawHistoryPage(),
    EarnCreditPage.route: (_) => EarnCreditPage(),

    // Search
    SearchPage.route: (_) => SearchPage(),

    // Logged user or not
    MainHelper.pageTypeTerms: (_) =>
    const WebViewPage(pageType: MainHelper.pageTypeTerms),
    MainHelper.pageTypePrivacy: (_) =>
    const WebViewPage(pageType: MainHelper.pageTypePrivacy),
  };
}