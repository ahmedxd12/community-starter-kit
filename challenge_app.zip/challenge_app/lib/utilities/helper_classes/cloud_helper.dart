import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/InvitedUsersModel.dart';
import 'package:challenge/models/UserModel.dart';

import '../../configurations/cloud_code_config.dart';

class CloudCodeHelper {
  static Future<ParseResponse> rewardChallenger(
      {required UserModel challenger, required int points}) async {
    ParseCloudFunction function =
        ParseCloudFunction(CloudParams.rewardChallenger);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.challenger: challenger.objectId,
      CloudParams.points: points,
    };

    return await function.execute(parameters: params);
  }

  static Future<ParseResponse> followUser(
      {required UserModel author,
      required UserModel receiver,
      required bool isFollowing}) async {
    ParseCloudFunction function =
        ParseCloudFunction(CloudParams.followUserParam);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.author: author.objectId,
      CloudParams.receiver: receiver.objectId,
      CloudParams.isFollowing: isFollowing,
    };

    return await function.execute(parameters: params);
  }

  static Future<ParseResponse> sendGift(
      {required UserModel author, required int credits}) async {
    ParseCloudFunction function = ParseCloudFunction(CloudParams.sendGiftParam);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.objectId: author.objectId,
      CloudParams.credits: MainHelper.getDiamondsForReceiver(credits),
    };

    if (author.getInvitedByUser != null &&
        author.getInvitedByUser!.isNotEmpty) {
      sendAgencyDiamonds(
          invitedById: author.getInvitedByUser!,
          credits: MainHelper.getDiamondsForAgency(
              MainHelper.getDiamondsForReceiver(credits)));
    }

    return await function.execute(parameters: params);
  }

  static sendAgencyDiamonds(
      {required String invitedById, required int credits}) async {
    ParseCloudFunction function =
        ParseCloudFunction(CloudParams.sendAgencyParam);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.objectId: invitedById,
      CloudParams.credits: credits,
    };

    QueryBuilder<InvitedUsersModel> queryBuilder =
        QueryBuilder<InvitedUsersModel>(InvitedUsersModel());
    queryBuilder.whereEqualTo(InvitedUsersModel.keyInvitedById, invitedById);
    ParseResponse parseResponse = await queryBuilder.query();

    if (parseResponse.success && parseResponse.results != null) {
      InvitedUsersModel invitedUser =
          parseResponse.results!.first! as InvitedUsersModel;
      invitedUser.addDiamonds = credits;
      await invitedUser.save();
    }

    await function.execute(parameters: params);
  }

  static resetUserPassword({
    required UserModel user,
    required String password,
  }) async {
    ParseCloudFunction function = ParseCloudFunction(CloudParams.resetUserPassword);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.objectId: user.objectId,
      CloudParams.password: password,
    };

    return await function.execute(parameters: params);
  }

  static sendCodeToEmail({
    required UserModel user,
    required String from,
    required String to,
    required String appName,
    required String apiKey,
  }) async {

    ParseCloudFunction function = ParseCloudFunction(CloudParams.sendCodeToEmail);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.objectId: user.objectId,
      CloudParams.from: from,
      CloudParams.to: to,
      CloudParams.appName: appName,
      CloudParams.apiKey: apiKey,
    };

    return await function.execute(parameters: params);
  }

  static verifyCodeFromEmail({
    required UserModel user,
    required String code,
  }) async {

    ParseCloudFunction function = ParseCloudFunction(CloudParams.verifyCodeFromEmail);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.objectId: user.objectId,
      CloudParams.code: code,
    };

    return await function.execute(parameters: params);
  }
}
