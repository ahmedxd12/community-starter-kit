// ignore_for_file: deprecated_member_use, depend_on_referenced_packages, unnecessary_null_comparison

import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:math' as math;
import 'dart:ui';
import 'package:another_flushbar/flushbar.dart';
import 'package:image_compression_flutter/image_compression_flutter.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/pages/home/video_pages/progress_upload_video.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/ReportModel.dart';
import 'package:challenge/models/StoriesModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/widgets/need_resume.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/avd.dart';
import 'package:flutter_svg/svg.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:challenge/widgets/snackbar_pro/snack_bar_pro.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_compress/video_compress.dart';

import '../../configurations/cloud_code_config.dart';
import '../../configurations/global_config.dart';
import '../../configurations/global_setup.dart';
import '../../models/VideoModel.dart';
import '../../services/navigation_service.dart';
import '../../widgets/custom_widgets/container_with_corner.dart';
import '../../widgets/custom_widgets/rounded_gradient_button.dart';
import '../../widgets/custom_widgets/text_with_tap.dart';
import '../main_utilities/challenge_exeption.dart';
import '../main_utilities/loading_dialog.dart';
import 'dart:convert';

import 'package:flutter/foundation.dart'
    show consolidateHttpClientResponseBytes, kIsWeb;

import '../../widgets/snackbar_pro/top_snack_bar.dart';
import '../main_utilities/shared_manager.dart';

typedef EmailSendingCallback = void Function(bool sent, ParseError? error);

class MainHelper {
  ParseConfig config = ParseConfig();

  static const String pageTypeTerms = "/terms";
  static const String pageTypePrivacy = "/privacy";
  static const String pageTypeOpenSource = "/opensource";
  static const String pageTypeHelpCenter = "/help";
  static const String pageTypeSafety = "/safety";
  static const String pageTypeCommunity = "/community";
  static const String pageTypeWhatsapp = "/whatsapp";
  static const String pageTypeInstructions = "/instructions";
  static const String pageTypeSupport = "/support";
  static const String pageTypeCashOut = "/cashOut";
  static const String pageTypeBigNftGame = "/bigNftGame";

  static String dateFormatDmy = "dd/MM/yyyy";
  static String dateFormatFacebook = "MM/dd/yyyy";
  static String dateFormatForFeed = "dd MMM, yyyy - HH:mm";

  static String dateFormatTimeOnly = "HH:mm";
  static String dateFormatListMessageFull = "dd MM, HH:mm";
  static String dateFormatDateOnly = "dd/MM/yy";
  static String dateFormatDayAndDateOnly = "EE., dd MMM";

  static String emailTypeWelcome = "welcome_email";
  static String emailTypeVerificationCode = "verification_code_email";

  static double earthMeanRadiusKm = 6371.0;
  static double earthMeanRadiusMile = 3958.8;

  // Online/offline track
  static int timeToSoon = 300 * 1000;
  static int timeToOffline = 2 * 60 * 1000;

  //static String emailTypePasswordReset = "password_reset_password";

  static const String admobOpenAdTest =
      "/6499/example/app-open";
  static const String admobRewardedVideoAdTestAndroid =
      "ca-app-pub-3940256099942544/5224354917";
  static const String admobRewardedVideoAdTestIos =
      "ca-app-pub-3940256099942544/1712485313";
  static const String admobBannerAdTest =
      "/6499/example/banner";
  static const String admobNativeAdTest = "/6499/example/native";

  static Color getColorStandard({bool? inverse}) {
    if (isDarkModeNoContext()) {
      if (inverse != null && inverse) {
        return kContentColorLightTheme;
      } else {
        return kContentColorDarkTheme;
      }
    } else {
      if (inverse != null && inverse) {
        return kContentColorDarkTheme;
      } else {
        return kContentColorLightTheme;
      }
    }
  }

  static List<String> getReportCodeMessageList() {
    List<String> list = [
      ReportModel.thisPosHasSexualContents,
      ReportModel.fakeProfileSpan,
      ReportModel.inappropriateMessage,
      ReportModel.someoneIsInDanger,
    ];

    return list;
  }

  static String getReportMessage(String code) {
    switch (code) {
      case ReportModel.thisPosHasSexualContents:
        return "message_report.report_without_interest".tr();

      case ReportModel.fakeProfileSpan:
        return "message_report.report_fake_profile".tr();

      case ReportModel.inappropriateMessage:
        return "message_report.report_inappropriate_message".tr();

      case ReportModel.someoneIsInDanger:
        return "message_report.report_some_in_danger".tr();

      default:
        return "";
    }
  }

  static List<String> getCategoriesCodeList() {
    List<String> list = [
      UserModel.categoryDance,
      UserModel.categoryART,
      UserModel.categoryJOKES,
      UserModel.categorySPORT,
      UserModel.categoryLOGIC,
      UserModel.categoryFUN,
      UserModel.categoryCOOK,
      UserModel.categorySING,
      UserModel.categoryINVENTIVE,
      UserModel.categoryFAMILY,
      UserModel.categorySNERVATING,
      UserModel.categoryPENANCE,
    ];

    return list;
  }

  static String getCategoriesList(String code) {
    switch (code) {
      case UserModel.categoryDance:
        return "categories.dance_".tr();
      case UserModel.categoryART:
        return "categories.art_".tr();
      case UserModel.categoryJOKES:
        return "categories.jokes_".tr();
      case UserModel.categorySPORT:
        return "categories.sport_".tr();
      case UserModel.categoryLOGIC:
        return "categories.logic_".tr();
      case UserModel.categoryFUN:
        return "categories.fun_".tr();
      case UserModel.categoryCOOK:
        return "categories.cook_".tr();
      case UserModel.categorySING:
        return "categories.sing_".tr();
      case UserModel.categoryINVENTIVE:
        return "categories.inventive_".tr();
      case UserModel.categoryFAMILY:
        return "categories.family_".tr();
      case UserModel.categorySNERVATING:
        return "categories.snervating_".tr();
      case UserModel.categoryPENANCE:
        return "categories.penance_".tr();
      default:
        return "";
    }
  }

  static List<String> getChallengeModeCodeList() {
    List<String> list = [
      //ChallengeModel.modePOLL,
      ChallengeModel.mode1VS1,
      ChallengeModel.modeLIVESTREAMING,
      ChallengeModel.modeAUDIOROOM,
      /*ChallengeModel.modeSINGLE,
      ChallengeModel.modeGROUP,
      ChallengeModel.modeTORNEO,*/
    ];
    return list;
  }

  static String getChallengeModeList(String code) {
    switch (code) {
      /*case ChallengeModel.modePOLL:
        return "challenge_modes.poll_".tr();*/
      case ChallengeModel.mode1VS1:
        return "challenge_modes.1v1_".tr();
      case ChallengeModel.modeLIVESTREAMING:
        return "challenge_modes.live_streaming".tr();
      case ChallengeModel.modeAUDIOROOM:
        return "challenge_modes.audio_room".tr();
      /*case ChallengeModel.modeSINGLE:
        return "challenge_modes.single".tr();
      case ChallengeModel.modeGROUP:
        return "challenge_modes.group_".tr();
      case ChallengeModel.modeTORNEO:
        return "challenge_modes.torneo_".tr();*/
      default:
        return "";
    }
  }

  static List<String> getChallengeRewardCodeList() {
    List<String> list = [
      ChallengeModel.rewardCHALLENGECOIN,
      ChallengeModel.rewardGOLDENCOIN,
      ChallengeModel.rewardSKIN,
      ChallengeModel.rewardBOOSTER,
      ChallengeModel.rewardACCESSORIES,
      ChallengeModel.rewardCRYPTO,
    ];
    return list;
  }

  static String getChallengeRewardList(String code) {
    switch (code) {
      case ChallengeModel.rewardCHALLENGECOIN:
        return "challenge_rewards.challenge_coin".tr();
      case ChallengeModel.rewardGOLDENCOIN:
        return "challenge_rewards.golden_coin".tr();
      case ChallengeModel.rewardSKIN:
        return "challenge_rewards.skin".tr();
      case ChallengeModel.rewardBOOSTER:
        return "challenge_rewards.booster".tr();
      case ChallengeModel.rewardACCESSORIES:
        return "challenge_rewards.accessories".tr();
      case ChallengeModel.rewardCRYPTO:
        return "challenge_rewards.crypto".tr();
      default:
        return "";
    }
  }

  static List<String> getGenderCodeList() {
    List<String> list = [
      UserModel.genderMALE,
      UserModel.genderFEMALE,
      UserModel.genderOTHER,
    ];
    return list;
  }

  static String getGenderList(String code) {
    switch (code) {
      case UserModel.genderMALE:
        return "auth.male_".tr();
      case UserModel.genderFEMALE:
        return "auth.female_".tr();
      case UserModel.genderOTHER:
        return "auth.other_".tr();
      default:
        return "";
    }
  }

  static List<String> getVideoCurrentStateCodeList() {
    List<String> list = [
      VideoModel.videoCurrentStatePublished,
      VideoModel.videoCurrentStateDeleted,
      VideoModel.videoCurrentStatePending,
      VideoModel.videoCurrentStateScheduled,
    ];

    return list;
  }

  static String getVideoCurrentStateList(String code) {
    switch (code) {
      case VideoModel.videoCurrentStatePublished:
        return "video_states.published".tr();
      case VideoModel.videoCurrentStateDeleted:
        return "video_states.deleted".tr();
      case VideoModel.videoCurrentStatePending:
        return "video_states.pending".tr();
      case VideoModel.videoCurrentStateScheduled:
        return "video_states.scheduled".tr();
      default:
        return "";
    }
  }

  static List<String> getSchoolCodeList() {
    List<String> list = [
      UserModel.schoolHIGHSCHOOL,
      UserModel.schoolUNIVERSITY,
    ];
    return list;
  }

  static String getSchoolList(String code) {
    switch (code) {
      case UserModel.schoolHIGHSCHOOL:
        return "auth.high_school_".tr();
      case UserModel.schoolUNIVERSITY:
        return "auth.university_".tr();
      default:
        return "";
    }
  }

  static List<String> getSFilmCodeList() {
    List<String> list = [
      UserModel.filmHORROR,
      UserModel.filmCOMEDY,
      UserModel.filmDRAMATIC,
    ];
    return list;
  }

  static String getFilmList(String code) {
    switch (code) {
      case UserModel.filmHORROR:
        return "auth.horror_".tr();
      case UserModel.filmCOMEDY:
        return "auth.comedy_".tr();
      case UserModel.filmDRAMATIC:
        return "auth.dramatic_".tr();
      default:
        return "";
    }
  }

  static List<String> getHobbyCodeList() {
    List<String> list = [
      UserModel.hobbyDANCE,
      UserModel.hobbyCOOK,
      UserModel.hobbySPORT,
    ];
    return list;
  }

  static String getHobbyList(String code) {
    switch (code) {
      case UserModel.hobbyDANCE:
        return "categories.dance_".tr();
      case UserModel.hobbyCOOK:
        return "categories.cook_".tr();
      case UserModel.hobbySPORT:
        return "categories.sport_".tr();
      default:
        return "";
    }
  }

  static List<String> getStatusCodeList() {
    List<String> list = [
      UserModel.statusSINGLE,
      UserModel.statusRELATIONSHP,
    ];
    return list;
  }

  static String getStatusList(String code) {
    switch (code) {
      case UserModel.statusSINGLE:
        return "auth.single_".tr();
      case UserModel.statusRELATIONSHP:
        return "auth.relationship_".tr();
      default:
        return "";
    }
  }

  static Color getColorSettingsBg() {
    if (isDarkModeNoContext()) {
      return kContentColorLightTheme;
    } else {
      return kSettingsBg;
    }
  }

  static String getDurationInMinutes({Duration? duration}) {
    if (duration != null) {
      String twoDigits(int n) => n.toString().padLeft(2, "0");
      String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
      String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));

      if (duration.inHours > 0) {
        return "${twoDigits(duration.inHours)}:$twoDigitMinutes:$twoDigitSeconds";
      } else {
        return "$twoDigitMinutes:$twoDigitSeconds";
      }
    } else {
      return "00:00";
    }
  }

  static String formatTime(int second) {
    var hour = (second / 3600).floor();
    var minutes = ((second - hour * 3600) / 60).floor();
    var seconds = (second - hour * 3600 - minutes * 60).floor();

    var secondExtraZero = (seconds < 10) ? "0" : "";
    var minuteExtraZero = (minutes < 10) ? "0" : "";
    var hourExtraZero = (hour < 10) ? "0" : "";

    if (hour > 0) {
      return "$hourExtraZero$hour:$minuteExtraZero$minutes:$secondExtraZero$seconds";
    } else {
      return "$minuteExtraZero$minutes:$secondExtraZero$seconds";
    }
  }

  static Color getColorTextCustom1({bool? inverse}) {
    if (isDarkModeNoContext()) {
      if (inverse != null && inverse) {
        return kContentColorLightTheme;
      } else {
        return kContentColorDarkTheme;
      }
    } else {
      if (inverse != null && inverse) {
        return kContentColorDarkTheme;
      } else {
        return kContentColorLightTheme;
      }
    }
  }

  static Color getColorToolbarIcons() {
    if (isDarkModeNoContext()) {
      return kContentColorDarkTheme;
    } else {
      return kColorsGrey600;
    }
  }

  static bool isDarkMode(BuildContext context) {
   var brightness = MediaQuery.of(context).platformBrightness;
    return brightness == Brightness.dark;
  }

  static bool isDarkModeNoContext() {
    var brightness = SchedulerBinding.instance.window.platformBrightness;
    return brightness == Brightness.dark;
  }

  static bool isWebPlatform() {
    return UniversalPlatform.isWeb;
  }

  static bool isAndroidPlatform() {
    return UniversalPlatform.isAndroid;
  }

  static bool isFuchsiaPlatform() {
    return UniversalPlatform.isFuchsia;
  }

  static bool isIOSPlatform() {
    return UniversalPlatform.isIOS;
  }

  static bool isMacOsPlatform() {
    return UniversalPlatform.isMacOS;
  }

  static bool isLinuxPlatform() {
    return UniversalPlatform.isLinux;
  }

  static bool isWindowsPlatform() {
    return UniversalPlatform.isWindows;
  }

  // Get country code
  static String? getCountryIso() {
    final List<Locale> systemLocales = WidgetsBinding.instance.window.locales;
    return systemLocales.first.countryCode;
  }

  static String? getCountryCodeFromLocal(BuildContext context) {
    Locale myLocale = Localizations.localeOf(context);

    return myLocale.countryCode;
  }

  // Save Installation
  static Future<void> initInstallation(UserModel? user, String? token) async {
    DateTime dateTime = DateTime.now();

    final ParseInstallation installation =
        await ParseInstallation.currentInstallation();

    if (token != null) {
      installation.set('deviceToken', token);
    } else {
      installation.unset('deviceToken');
    }

    installation.set('GCMSenderId', Config.pushGcm);
    installation.set('timeZone', dateTime.timeZoneName);
    installation.set('installationId', installation.installationId);

    if (kIsWeb) {
      installation.set('deviceType', 'web');
      installation.set('pushType', 'FCM');
    } else if (Platform.isAndroid) {
      installation.set('deviceType', 'android');
      installation.set('pushType', 'FCM');
    } else if (Platform.isIOS) {
      installation.set('deviceType', 'ios');
      installation.set('pushType', 'APN');
    }

    if (user != null) {
      user.set("installation", installation);
      installation.set('user', user);
      installation.subscribeToChannel('global');
    } else {
      installation.unset('user');
      installation.unsubscribeFromChannel('global');
    }
  }

  // Update Installation
  // Add a user to the installation when a user logs in
  // Remove the user to the installation when the user logs out
  static Future<void> updateInstallation(UserModel? user,String? token)async {
    final ParseInstallation installation =
      await ParseInstallation.currentInstallation();

    if (token != null) {
      installation.set('deviceToken', token);
    } else {
      installation.unset('deviceToken');
    }

    if (user != null) {
      user.set("installation", installation);
      installation.set('user', user);
      installation.subscribeToChannel('global');
    } else {
      installation.unset('user');
      installation.unsubscribeFromChannel('global');
    }

    // installation.save();
  }

  static updateCurrentInstallation({UserModel? user}) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    MainHelper.initInstallation(
        user!,
        SharedManager.getDeviceToken(sharedPreferences)
    );
  }

  static setCurrentUser(UserModel? userModel, {StateSetter? setState}) async {
    UserModel userModel = await ParseUser.currentUser();

    if (setState != null) {
      setState(() {
        userModel = userModel;
      });
    } else {
      userModel = userModel;
    }
  }

  static Future<UserModel?>? getCurrentUser() async {
    UserModel? currentUser = await ParseUser.currentUser();
    return currentUser;
  }

  static Future<UserModel?> getCurrentUserModel(UserModel? userModel) async {
    UserModel currentUser = await ParseUser.currentUser();
    return currentUser;
  }

  static Future<UserModel> getUserModelResult(dynamic d) async {
    UserModel? user = await ParseUser.currentUser();
    user = UserModel.clone()..fromJson(d as Map<String, dynamic>);

    return user;
  }

  static Future<UserModel?> getUser(UserModel? currentUser) async {
    currentUser = await ParseUser.currentUser();

    if (currentUser != null) {
      ParseResponse response = await currentUser.getUpdatedUser();
      if (response.success) {
        currentUser = response.result;
        return currentUser;
      } else if (response.error!.code == 100) {
        // Return stored user

        return currentUser;
      } else if (response.error!.code == 101) {
        // User deleted or doesn't exist.

        currentUser.logout(deleteLocalUserData: true);
        return null;
      } else if (response.error!.code == 209) {
        // Invalid session token

        currentUser.logout(deleteLocalUserData: true);
        return null;
      } else {
        // General error

        return currentUser;
      }
    } else {
      return null;
    }
  }

  // Check if email is valid
  static bool isValidEmail(String email) {
    return RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(email);
  }

  // Check if string has only number(s)
  static bool isNumeric(String string) {
    return double.tryParse(string) != null;
  }

  static bool isPasswordCompliant(String password, [int minLength = 6]) {
    bool hasUppercase = password.contains(RegExp(r'[A-Z]'));
    bool hasDigits = password.contains(RegExp(r'[0-9]'));
    bool hasLowercase = password.contains(RegExp(r'[a-z]'));
    bool hasSpecialCharacters =
        password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'));
    bool hasMinLength = password.length > minLength;

    return hasDigits &
        hasUppercase &
        hasLowercase &
        hasSpecialCharacters &
        hasMinLength;
  }

  static bool isInLive(StoriesModel story) {
    DateTime now = DateTime.now();

    if (story.getExpireDate != null) {
      DateTime to = story.getExpireDate!;

      if (to.isAfter(now)) {
        return true;
      }
    }

    return false;
  }

  static DateTime getDateFromString(String date, String format) {
    return DateFormat(format).parse(date);
  }

  static Object getDateDynamic(String date) {
    DateFormat dateFormat = DateFormat(dateFormatDmy);
    DateTime dateTime = dateFormat.parse(date);

    return json.encode(dateTime, toEncodable: myEncode);
  }

  static dynamic myEncode(dynamic item) {
    if (item is DateTime) {
      return item.toIso8601String();
    }
    return item;
  }

  static DateTime getDate(String date) {
    DateFormat dateFormat = DateFormat(dateFormatDmy);
    DateTime dateTime = dateFormat.parse(date);

    return dateTime;
  }

  static bool isValidDateBirth(String date, String format) {
    try {
      int day = 1, month = 1, year = 2000;

      //Get separator data  10/10/2020, 2020-10-10, 10.10.2020
      String separator = RegExp("([-/.])").firstMatch(date)!.group(0)![0];

      //Split by separator [mm, dd, yyyy]
      var frSplit = format.split(separator);
      //Split by separtor [10, 10, 2020]
      var dtSplit = date.split(separator);

      for (int i = 0; i < frSplit.length; i++) {
        var frm = frSplit[i].toLowerCase();
        var vl = dtSplit[i];

        if (frm == "dd") {
          day = int.parse(vl);
        } else if (frm == "mm") {
          month = int.parse(vl);
        } else if (frm == "yyyy") {
          year = int.parse(vl);
        }
      }

      //First date check
      //The dart does not throw an exception for invalid date.
      var now = DateTime.now();
      if (month > 12 ||
          month < 1 ||
          day < 1 ||
          day > daysInMonth(month, year) ||
          year < 1810 ||
          (year > now.year && day > now.day && month > now.month)) {
        throw Exception("Date birth invalid.");
      }

      return true;
    } catch (e) {
      return false;
    }
  }

  static bool minimumAgeAllowed(String birthDateString, String datePattern) {
    // Current time - at this moment
    DateTime today = DateTime.now();

    // Parsed date to check
    DateTime birthDate = DateFormat(datePattern).parse(birthDateString);

    // Date to check but moved 18 years ahead
    DateTime adultDate = DateTime(
      birthDate.year + Setup.minimumAgeToRegister,
      birthDate.month,
      birthDate.day,
    );

    return adultDate.isBefore(today);
  }

  static int daysInMonth(int month, int year) {
    int days = 28 +
        (month + (month / 8).floor()) % 2 +
        2 % month +
        2 * (1 / month).floor();
    return (isLeapYear(year) && month == 2) ? 29 : days;
  }

  static bool isLeapYear(int year) =>
      ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0);

  static void showLoadingDialog(BuildContext context, {bool? isDismissible}) {
    showDialog(
        context: context,
        barrierDismissible: isDismissible ?? false,
        builder: (BuildContext context) {
          return const LoadingDialog();
        });
  }

  static void showConnectingDialog(BuildContext context,
      {bool? isDismissible}) {
    showDialog(
        context: context,
        barrierDismissible: isDismissible ?? false,
        builder: (BuildContext context) {
          return Center(
              child: TextWithTap(
            "connecting_".tr(),
            color: Colors.white,
          ));
        });
  }

  static void hideLoadingDialog(BuildContext context, {dynamic result}) {
    Navigator.pop(context, result);
  }

  static goToNavigator(BuildContext context, String route,
      {Object? arguments, ResumableState? resumeState}) {
    Future.delayed(Duration.zero, () {
      if (resumeState != null) {
        resumeState.pushNamed(context, route, arguments: arguments);
      } else {
        //Navigator.of(context).pushNamed(route, arguments: arguments);
        NavigationService.navigatorKey.currentState
            ?.pushNamed(route, arguments: arguments);
      }
    });
  }

  static goToNavigatorScreen(BuildContext context, Widget widget,
      {bool? finish = false, bool? back = true}) {
    if (finish == false) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => widget,
        ),
      );
    } else {
      Navigator.pushAndRemoveUntil<dynamic>(
        context,
        MaterialPageRoute<dynamic>(
          builder: (BuildContext context) => widget,
        ),
        (route) => back!, //if you want to disable back feature set to false
      );
    }
  }

  static String convertToK(int number) {
    if (number > 999) {
      return "${number ~/ 1000}k+";
    } else {
      return number.toString();
    }
  }

  static Color stringToColor(String colorString) {
    String valueString =
        colorString.split('(0x')[1].split(')')[0]; // kind of hacky..
    int value = int.parse(valueString, radix: 16);
    Color reverseColor = Color(value);
    return reverseColor;
  }

  static Future<dynamic> goToNavigatorScreenForResult(
      BuildContext context, Widget widget,
      {required String route}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
          settings: RouteSettings(name: route), builder: (context) => widget),
    );

    return result;
  }

  static void goBack(BuildContext context, {Object? arguments}) {
    Navigator.pop(context, arguments);
  }

  /*static goToNavigatorAndClear(BuildContext context, String route,
      {Object? arguments}) {
    Future.delayed(Duration.zero, () {
      Navigator.of(context).pushNamedAndRemoveUntil(route, (route) => false,
          arguments: arguments);
    });
  }*/

  static goToPageWithClear(BuildContext context, Widget widget) {
    Navigator.pushAndRemoveUntil<dynamic>(
      context,
      MaterialPageRoute<dynamic>(
        builder: (BuildContext context) => widget,
      ),
      (route) => false, //if you want to disable back feature set to false
    );
  }

  static void goBackToPreviousPage(BuildContext context,
      {bool? useCustomAnimation,
      PageTransitionsBuilder? pageTransitionsBuilder,
      dynamic result}) {
    Navigator.of(context).pop(result);
  }

  static checkRoute(BuildContext context, bool authNeeded, Widget widget) {
    if (authNeeded && MainHelper.getCurrentUser() != null) {
      return widget;
    } else {
      return MainHelper.goBackToPreviousPage(context);
    }
  }

  static removeFocusOnTextField(BuildContext context) {
    FocusScopeNode focusScopeNode = FocusScope.of(context);
    if (!focusScopeNode.hasPrimaryFocus &&
        focusScopeNode.focusedChild != null) {
      FocusManager.instance.primaryFocus?.unfocus();
    }
  }

  static void showDialogWithButton(
      {required BuildContext context,
      String? message,
      String? title,
      String? buttonText,
      VoidCallback? onPressed}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title!),
          content: Text(message!),
          actions: [
            ElevatedButton(
              child: Text(buttonText!),
              onPressed: () {
                Navigator.of(context).pop();
                if (onPressed != null) {
                  onPressed();
                }
              },
            ),
          ],
        );
      },
    );
  }

  static void showDialogWithButtonCustom(
      {required BuildContext context,
      String? message,
      String? title,
      required String? cancelButtonText,
      required String? confirmButtonText,
      VoidCallback? onPressed}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: MainHelper.isDarkMode(context)
              ? kContentColorLightTheme
              : kContentColorDarkTheme,
          title: TextWithTap(
            title!,
            fontWeight: FontWeight.bold,
          ),
          content: Text(message!),
          actions: [
            TextWithTap(
              cancelButtonText!,
              fontWeight: FontWeight.bold,
              marginRight: 10,
              marginLeft: 10,
              marginBottom: 10,
              onTap: () => Navigator.of(context).pop(),
            ),
            TextWithTap(
              confirmButtonText!,
              fontWeight: FontWeight.bold,
              marginRight: 10,
              marginLeft: 10,
              marginBottom: 10,
              onTap: () {
                if (onPressed != null) {
                  onPressed();
                }
              },
            ),
          ],
        );
      },
    );
  }

  static void showDialogHeyto(
      {required BuildContext context,
      String? message,
      String? title,
      required String? cancelButtonText,
      required String? confirmButtonText,
      VoidCallback? onPressed}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: MainHelper.isDarkMode(context)
              ? kContentColorLightTheme
              : kContentColorDarkTheme,
          elevation: 2,
          clipBehavior: Clip.hardEdge,
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          title: Column(
            children: [
              Center(
                child: SizedBox(
                  width: 28,
                  height: 28,
                  child: SvgPicture.asset(
                    'assets/svg/ic_icon.svg',
                    width: 28,
                    height: 28,
                  ),
                ),
              ),
              TextWithTap(
                title!,
                marginTop: 28,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                textAlign: TextAlign.center,
              ),
            ],
          ),
          content: TextWithTap(
            message!,
            textAlign: TextAlign.center,
          ),
          actions: [
            Column(
              children: [
                RoundedGradientButton(
                  text: confirmButtonText!,
                  //width: 150,
                  height: 48,
                  marginLeft: 30,
                  marginRight: 30,
                  marginBottom: 30,
                  borderRadius: 60,
                  textColor: Colors.white,
                  borderRadiusBottomLeft: 15,
                  colors: const [kPrimaryColor, kSecondaryColor],
                  marginTop: 0,
                  fontSize: 16,
                  onTap: () {
                    if (onPressed != null) {
                      onPressed();
                    }
                  },
                ),
                TextWithTap(
                  cancelButtonText!.toUpperCase(),
                  fontWeight: FontWeight.bold,
                  color: kPrimacyGrayColor,
                  marginRight: 10,
                  marginLeft: 10,
                  fontSize: 15,
                  marginBottom: 10,
                  textAlign: TextAlign.center,
                  onTap: () => Navigator.of(context).pop(),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  static void showDialogPermission(
      {required BuildContext context,
      String? message,
      String? title,
      required String? confirmButtonText,
      VoidCallback? onPressed}) {

    var size = MediaQuery.of(context).size;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: MainHelper.isDarkMode(context)
              ? kContentColorLightTheme
              : kContentColorDarkTheme,
          elevation: 2,
          clipBehavior: Clip.hardEdge,
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          title: TextWithTap(
            title ?? '',
            marginTop: 5,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            textAlign: TextAlign.center,
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          content: TextWithTap(
            message ?? '',
            textAlign: TextAlign.center,
            color: kSecondaryGrayColor,
          ),
          actions: [
            Column(
              children: [
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/btn_design.png",
                  marginLeft: 30,
                  marginRight: 30,
                  marginBottom: 20,
                  radiusTopLeft: 20,
                  // marginTop: size.width / 15,
                  // marginBottom: size.height * 0.07,
                  height: 48,//size.width / 6,
                  /*marginLeft: size.width / 7,
                  marginRight: size.width / 7,*/
                  width: size.width * 0.6,
                  onTap: () {
                    if (onPressed != null) {
                      onPressed();
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextWithTap(
                          confirmButtonText!,
                          color: Colors.white,
                          marginLeft: 10,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  static void showDialogLivEend(
      {required BuildContext context,
      String? message,
      String? title,
      required String? confirmButtonText,
      VoidCallback? onPressed,
      bool? dismiss = true})
  {
    var size = MediaQuery.of(context).size;

    showDialog(
      barrierDismissible: dismiss!,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: MainHelper.isDarkMode(context)
              ? kContentColorLightTheme
              : kContentColorDarkTheme,
          elevation: 2,
          clipBehavior: Clip.hardEdge,
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(10.0))),
          title: TextWithTap(
            title!,
            marginTop: 5,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            textAlign: TextAlign.center,
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          content: TextWithTap(
            message!,
            textAlign: TextAlign.center,
            color: kSecondaryGrayColor,
          ),
          actions: [
            Column(
              children: [
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/btn_design.png",
                  marginLeft: 30,
                  marginRight: 30,
                  marginBottom: 20,
                  radiusTopLeft: 20,
                  // marginTop: size.width / 15,
                  // marginBottom: size.height * 0.07,
                  height: 48,//size.width / 6,
                  /*marginLeft: size.width / 7,
                  marginRight: size.width / 7,*/
                  width: size.width * 0.6,
                  onTap: () {
                    if (onPressed != null) {
                      onPressed();
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextWithTap(
                          confirmButtonText!,
                          color: Colors.white,
                          marginLeft: 10,
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  static void showError(
      {required BuildContext context,
      String? message,
      VoidCallback? onPressed}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Error!"),
          content: Text(message!),
          actions: <Widget>[
            ElevatedButton(
              child: const Text("OK"),
              onPressed: () {
                Navigator.of(context).pop();
                if (onPressed != null) {
                  onPressed();
                }
              },
            ),
          ],
        );
      },
    );
  }

  static bool isAccountDisabled(UserModel? user) {
    return user!.getActivationStatus == true;
  }

  static updateUserServer(
      {required String column,
      required dynamic value,
      required UserModel user}) async {
    ParseCloudFunction function =
        ParseCloudFunction(CloudParams.updateUserGlobalParam);
    Map<String, dynamic> params = <String, dynamic>{
      CloudParams.columnGlobal: column,
      CloudParams.valueGlobal: value,
      CloudParams.userGlobal: user.getUsername!,
    };

    ParseResponse parseResponse = await function.execute(parameters: params);
    if (parseResponse.success) {
      UserModel.getUserResult(parseResponse.result);
    }
  }

  static updateUserServerList({required Map<String, dynamic> map}) async {
    ParseCloudFunction function =
        ParseCloudFunction(CloudParams.updateUserGlobalListParam);
    Map<String, dynamic> params = map;

    ParseResponse parseResponse = await function.execute(parameters: params);
    if (parseResponse.success) {
      UserModel.getUserResult(parseResponse.result);
    }
  }

  //final emailSendingCallback? _sendingCallback;

  static sendEmail(String accountNumber, String emailType,
      {EmailSendingCallback? sendingCallback}) async {
    ParseCloudFunction function =
        ParseCloudFunction(CloudParams.sendEmailParam);
    Map<String, String> params = <String, String>{
      CloudParams.userGlobal: accountNumber,
      CloudParams.emailType: emailType
    };
    ParseResponse result = await function.execute(parameters: params);

    if (result.success) {
      sendingCallback!(true, null);
    } else {
      sendingCallback!(false, result.error);
    }
  }

  static bool isMobile() {
    if (isWebPlatform()) {
      return false;
    } else if (isAndroidPlatform()) {
      return true;
    } else if (isIOSPlatform()) {
      return true;
    } else {
      return false;
    }
  }

  static goToWebPage(BuildContext context, {required String pageType}) {
    goToNavigator(context, pageType);
  }

  static void showErrorResult(BuildContext context, int error) {
    MainHelper.hideLoadingDialog(context);

    if (error == ChallengeException.connectionFailed) {
      // Internet problem
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "not_connected".tr(),
        isError: true,
      );
    } else if (error == ChallengeException.otherCause) {
      // Internet problem
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "not_connected".tr(),
        isError: true,
      );
    } else if (error == ChallengeException.emailTaken) {
      // Internet problem
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "auth.email_taken".tr(),
        isError: true,
      );
    }

    /*else if(error == ChallengeException.accountBlocked){
      // Internet problem
      MainHelper.showAlertError(context: context, title: "error".tr(), message: "auth.account_blocked".tr());
    }*/
    else {
      // Invalid credentials
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "auth.invalid_credentials".tr(),
        isError: true,
      );
    }
  }

  static bool isAndroidLogin() {
    if (MainHelper.isIOSPlatform()) {
      return false;
    } else if (!MainHelper.isIOSPlatform() && Setup.isAppleLoginEnabled) {
      return true;
    } else {
      return false;
    }
  }

  static String formatNumber(int? number){
    if(number != null){
      int m = number~/1000000;
      int k = number~/1000;

      if(m > 0){
        return '${m}M';
      }else if(k > 0){
        return '${k}K';
      }else {
        return number.toString();
      }

    }else{
      return '0';
    }
  }

  static final bool areSocialLoginsDisabled = !Setup.isPhoneLoginEnabled &&
      !Setup.isGoogleLoginEnabled &&
      !isAndroidLogin();

  static int generateUId() {
    Random rnd = Random();
    return 1000000000 + rnd.nextInt(999999999);
  }

  static Future<String> downloadFilePath(
      String url, String fileName, String dir) async {
    HttpClient httpClient = HttpClient();
    File file;
    String filePath = '';
    String myUrl = '';

    try {
      myUrl = '$url/$fileName';
      var request = await httpClient.getUrl(Uri.parse(myUrl));
      var response = await request.close();
      if (response.statusCode == 200) {
        var bytes = await consolidateHttpClientResponseBytes(response);
        filePath = '$dir/$fileName';
        file = File(filePath);
        await file.writeAsBytes(bytes);
      } else {
        filePath = 'Error code: ${response.statusCode}';
      }
    } catch (ex) {
      filePath = 'Can not fetch url';
    }

    return filePath;
  }

  static Map<String, dynamic>? getInfoFromToken(String token) {
    // validate token

    final List<String> parts = token.split('.');
    if (parts.length != 3) {
      return null;
    }
    // retrieve token payload
    final String payload = parts[1];
    final String normalized = base64Url.normalize(payload);
    final String resp = utf8.decode(base64Url.decode(normalized));
    // convert to Map
    final payloadMap = json.decode(resp);
    if (payloadMap is! Map<String, dynamic>) {
      return null;
    }
    return payloadMap;
  }

  static Future<dynamic> downloadFile(String url, String filename) async {
    HttpClient httpClient = HttpClient();

    var request = await httpClient.getUrl(Uri.parse(url));
    var response = await request.close();
    var bytes = await consolidateHttpClientResponseBytes(response);
    String dir = (await getApplicationDocumentsDirectory()).path;
    File file = File('$dir/$filename');
    await file.writeAsBytes(bytes);
    return file;
  }

  static setWebPageTitle(BuildContext context, String title) {
    SystemChrome.setApplicationSwitcherDescription(
        ApplicationSwitcherDescription(
      label: '${Setup.appName} - $title',
      primaryColor: Theme.of(context).primaryColor.value,
    ));
  }

  static AvdPicture xmlVector(String assetName) {
    return AvdPicture.asset(assetName);
  }

  static String getMoodNameByCode(String modeCode) {
    switch (modeCode) {
      case "RC":
        return "profile_tab.mood_rc".tr();

      case "LMU":
        return "profile_tab.mood_lmu".tr();

      case "HLE":
        return "profile_tab.mood_hle".tr();

      case "BMM":
        return "profile_tab.mood_bmm".tr();

      case "CC":
        return "profile_tab.mood_cc".tr();

      case "RFD":
        return "profile_tab.mood_rfd".tr();

      case "ICUD":
        return "profile_tab.mood_icud".tr();

      case "JPT":
        return "profile_tab.mood_jpt".tr();

      case "MML":
        return "profile_tab.mood_mml".tr();

      case "SM":
        return "profile_tab.mood_sm".tr();

      default:
        return "profile_tab.mood_none".tr();
    }
  }

  static void setRandomArray(List arrayList) {
    arrayList.shuffle();
  }

  static int getAgeFromDate(DateTime birthday) {
    DateTime currentDate = DateTime.now();

    int age = currentDate.year - birthday.year;

    int month1 = currentDate.month;
    int month2 = birthday.month;

    if (month2 > month1) {
      age--;
    } else if (month1 == month2) {
      int day1 = currentDate.day;
      int day2 = birthday.day;

      if (day2 > day1) {
        age--;
      }
    }
    return age;
  }

  static int getAgeFromDateString(String birthDateString, String datePattern) {
    // Parsed date to check
    DateTime birthday = DateFormat(datePattern).parse(birthDateString);

    DateTime currentDate = DateTime.now();

    int age = currentDate.year - birthday.year;

    int month1 = currentDate.month;
    int month2 = birthday.month;

    if (month2 > month1) {
      age--;
    } else if (month1 == month2) {
      int day1 = currentDate.day;
      int day2 = birthday.day;

      if (day2 > day1) {
        age--;
      }
    }
    return age;
  }

  static DateTime incrementDate(int days) {
    DateTime limitDate = DateTime.now();
    limitDate.add(Duration(days: days));

    return limitDate;
  }

  static String getStringFromDate(DateTime date) {
    return DateFormat(dateFormatDmy).format(date);
  }

  static String getTimeAgoForFeed(DateTime dateTime) {
    //return DateFormat(dateFormatForFeed).format(date);
    //Duration diff = DateTime.now().difference(dateTime);

    DateTime now = DateTime.now();
    int dateDiff = DateTime(dateTime.year, dateTime.month, dateTime.day)
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;

    if (dateDiff == -1) {
      // Yesterday
      return "date_time.yesterday_".tr();
    } else if (dateDiff == 0) {
      // today
      return DateFormat().add_Hm().format(dateTime);
    } else {
      return DateFormat().add_MMMEd().add_Hm().format(dateTime);
    }
  }

  static String getBirthdayFromDate(DateTime date) {
    return DateFormat(dateFormatDmy).format(date.add(const Duration(days: 1)));
  }

  static String getDeviceOsName() {
    if (MainHelper.isAndroidPlatform()) {
      return "Android";
    } else if (MainHelper.isIOSPlatform()) {
      return "iOS";
    } else if (MainHelper.isWebPlatform()) {
      return "Web";
    } else if (MainHelper.isWindowsPlatform()) {
      return "Windows";
    } else if (MainHelper.isLinuxPlatform()) {
      return "Linux";
    } else if (MainHelper.isFuchsiaPlatform()) {
      return "Fuchsia";
    } else if (MainHelper.isMacOsPlatform()) {
      return "MacOS";
    }

    return "";
  }

  static String getDeviceOsType() {
    if (MainHelper.isAndroidPlatform()) {
      return "android";
    } else if (MainHelper.isIOSPlatform()) {
      return "ios";
    } else if (MainHelper.isWebPlatform()) {
      return "web";
    } else if (MainHelper.isWindowsPlatform()) {
      return "windows";
    } else if (MainHelper.isLinuxPlatform()) {
      return "linux";
    } else if (MainHelper.isFuchsiaPlatform()) {
      return "fuchsia";
    } else if (MainHelper.isMacOsPlatform()) {
      return "macos";
    }

    return "";
  }

  static getGender(UserModel user) {
    if (user.getGender == UserModel.keyGenderMale) {
      return "male_".tr();
    } else {
      return "female_".tr();
    }
  }

  static String getHeight(int height) {
    if (height > 91) {
      return "$height cm";
    } else {
      return "edit_profile.profile_no_answer".tr();
    }
  }

  static List<String> getShowMyPostToList() {
    List<String> list = [UserModel.anyUser, UserModel.onlyMyFriends, ""];

    return list;
  }

  static String getShowMyPostToMessage(String code) {
    switch (code) {
      case UserModel.anyUser:
        return "privacy_settings.explain_see_my_posts"
            .tr(namedArgs: {"app_name": Config.appName});

      case UserModel.onlyMyFriends:
        return "privacy_settings.explain_see_my_post".tr();

      default:
        return "edit_profile.profile_no_answer".tr();
    }
  }

  static List<String> getPrivacyList() {
    List<String> list = [
      StoriesModel.privacyPublic,
      StoriesModel.privacyFollowers,
      StoriesModel.privacyOnlyMe,
      ""
    ];

    return list;
  }

  static String getPrivacy(String code) {
    switch (code) {
      case StoriesModel.privacyPublic:
        return "stories.privacy_public".tr();

      case StoriesModel.privacyFollowers:
        return "stories.privacy_followers".tr();

      case StoriesModel.privacyOnlyMe:
        return "stories.privacy_private".tr();

      default:
        return "";
    }
  }

  static Future<void> launchInWebViewWithJavaScript(String url) async {
    if (await canLaunch(url)) {
      await launch(
        url,
        forceSafariVC: false,
        forceWebView: false,
        enableJavaScript: true,
      );
    } else {
      throw 'Could not launch $url';
    }
  }

  static Widget appLoading({bool adaptive = true}) {
    return Center(
      child: SizedBox(
        width: 30,
        height: 30,
        child: MainHelper.isIOSPlatform()
            ? const CircularProgressIndicator.adaptive()
            : const CircularProgressIndicator(), //SvgPicture.asset('assets/svg/ic_icon.svg', width: 50, height: 50,),
      ),
    );
  }

  static Widget appLoadingLogo() {
    return Center(
      child: SizedBox(
        width: 120,
        height: 120,
        child: Image.asset(
          'assets/images/ic_logo.png',
          width: 120,
          height: 120,
        ),
      ),
    );
  }

  static double distanceInKilometersTo(
      ParseGeoPoint point1, ParseGeoPoint point2) {
    return _distanceInRadiansTo(point1, point2) * earthMeanRadiusKm;
  }

  static double distanceInMilesTo(ParseGeoPoint point1, ParseGeoPoint point2) {
    return _distanceInRadiansTo(point1, point2) * earthMeanRadiusMile;
  }

  static double _distanceInRadiansTo(
      ParseGeoPoint point1, ParseGeoPoint point2) {
    double d2r = math.pi / 180.0; // radian conversion factor
    double lat1rad = point1.latitude * d2r;
    double long1rad = point1.longitude * d2r;
    double lat2rad = point2.latitude * d2r;
    double long2rad = point2.longitude * d2r;
    double deltaLat = lat1rad - lat2rad;
    double deltaLong = long1rad - long2rad;
    double sinDeltaLatDiv2 = math.sin(deltaLat / 2);
    double sinDeltaLongDiv2 = math.sin(deltaLong / 2);
    // Square of half the straight line chord distance between both points.
    // [0.0, 1.0]
    double a = sinDeltaLatDiv2 * sinDeltaLatDiv2 +
        math.cos(lat1rad) *
            math.cos(lat2rad) *
            sinDeltaLongDiv2 *
            sinDeltaLongDiv2;
    a = math.min(1.0, a);
    return 2 * math.asin(math.sqrt(a));
  }

  static String isUserOnlineChat(UserModel user) {
    DateTime? dateTime;

    if (user.getLastOnline != null) {
      dateTime = user.getLastOnline;
    } else {
      dateTime = user.updatedAt;
    }

    if (DateTime.now().millisecondsSinceEpoch -
            dateTime!.millisecondsSinceEpoch >
        timeToOffline) {
      // offline
      return "offline_".tr();
    } else if (DateTime.now().millisecondsSinceEpoch -
            dateTime.millisecondsSinceEpoch >
        timeToSoon) {
      // offline / recently online
      return MainHelper.timeAgoSinceDate(dateTime);
    } else {
      // online
      return "online_".tr();
    }
  }

  static bool isUserOnline(UserModel user) {
    DateTime? dateTime;

    if (user.getLastOnline != null) {
      dateTime = user.getLastOnline;
    } else {
      dateTime = user.updatedAt;
    }

    if (DateTime.now().millisecondsSinceEpoch -
            dateTime!.millisecondsSinceEpoch >
        timeToOffline) {
      // offline
      return false;
    } else if (DateTime.now().millisecondsSinceEpoch -
            dateTime.millisecondsSinceEpoch >
        timeToSoon) {
      // offline / recently online
      return true;
    } else {
      // online
      return true;
    }
  }

  static DateTime getDateFromAge(int age) {
    var birthday = DateTime.now();

    int currentYear = birthday.year;
    int birthYear = currentYear - age;

    return DateTime(birthYear, birthday.month, birthday.day);
  }

  static String getDiamondsLeftToRedeem(int diamonds) {
    if (diamonds >= Setup.diamondsNeededToRedeem) {
      return 0.toString();
    } else {
      return (Setup.diamondsNeededToRedeem - diamonds).toString();
    }
  }

  static int getTwoLastDigit() {
    final DateTime now = DateTime.now();
    final DateFormat formatter = DateFormat('yy');
    final String formatted = formatter.format(now);
    var some = int.parse(formatted) + 3;

    return some;
  }

  static bool hasSameDate(DateTime first, DateTime second) {
    int dateDiff = DateTime(second.year, second.month, second.day)
        .difference(DateTime(first.year, first.month, first.day))
        .inDays;
    return dateDiff == 0;
  }

  static String getMessageListTime(DateTime dateTime) {
    Duration diff = DateTime.now().difference(dateTime);
    DateTime now = DateTime.now();
    int dateDiff = DateTime(dateTime.year, dateTime.month, dateTime.day)
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;

    if (dateDiff == -1) {
      // Yesterday
      return "date_time.yesterday_".tr();
    } else if (dateDiff == 0) {
      // today
      return DateFormat(dateFormatTimeOnly).format(dateTime);
    } else if (diff.inDays > 0 && diff.inDays < 6) {
      // Day name
      return getDaysOfWeek(dateTime);
    } else {
      return DateFormat(dateFormatDateOnly).format(dateTime);
    }
  }

  static String getMessageTime(DateTime dateTime, {bool? time}) {
    if (time != null && time == true) {
      return DateFormat(dateFormatTimeOnly).format(dateTime);
    } else {
      Duration diff = DateTime.now().difference(dateTime);
      DateTime now = DateTime.now();
      int dateDiff = DateTime(dateTime.year, dateTime.month, dateTime.day)
          .difference(DateTime(now.year, now.month, now.day))
          .inDays;

      if (dateDiff == -1) {
        // Yesterday
        return "date_time.yesterday_".tr();
      } else if (dateDiff == 0) {
        // today
        return "date_time.today_".tr();
      } else if (diff.inDays > 0 && diff.inDays < 6) {
        // Day name
        return getDaysOfWeek(dateTime);
      } else {
        return DateFormat().add_MMMEd().format(dateTime);
      }
    }
  }

  static String getTimeAndDate(DateTime dateTime, {bool? time}) {
    DateTime date1 = DateTime.now();
    return dateTime.difference(date1).toYearsMonthsDaysString();
  }

  static String getDaysOfWeek(DateTime dateTime) {
    int day = dateTime.weekday;

    if (day == 1) {
      return "date_time.monday_".tr();
    } else if (day == 2) {
      return "date_time.tuesday_".tr();
    } else if (day == 3) {
      return "date_time.wednesday_".tr();
    } else if (day == 4) {
      return "date_time.thursday_".tr();
    } else if (day == 5) {
      return "date_time.friday_".tr();
    } else if (day == 6) {
      return "date_time.saturday_".tr();
    } else if (day == 7) {
      return "date_time.sunday_".tr();
    }

    return "";
  }

  static String timeAgoSinceDate(DateTime dateTime,
      {bool numericDates = true}) {
    final date2 = DateTime.now();
    final difference = date2.difference(dateTime);

    if (difference.inDays > 8) {
      return DateFormat(dateFormatDateOnly).format(dateTime);
    } else if ((difference.inDays / 7).floor() >= 1) {
      return (numericDates) ? '1 week ago' : 'Last week';
    } else if (difference.inDays >= 2) {
      return '${difference.inDays} days ago';
    } else if (difference.inDays >= 1) {
      return (numericDates) ? '1 day ago' : 'Yesterday';
    } else if (difference.inHours >= 2) {
      return '${difference.inHours} hours ago';
    } else if (difference.inHours >= 1) {
      return (numericDates) ? '1 hour ago' : 'An hour ago';
    } else if (difference.inMinutes >= 2) {
      return '${difference.inMinutes} minutes ago';
    } else if (difference.inMinutes >= 1) {
      return (numericDates) ? '1 minute ago' : 'A minute ago';
    } else if (difference.inSeconds >= 3) {
      return '${difference.inSeconds} seconds ago';
    } else {
      return 'Just now';
    }
  }

  static void showAppNotification(
      {required BuildContext context, String? title, bool isError = true}) {
    showTopSnackBar(
      context,
      isError
          ? SnackBarPro.error(
              title: title!,
            )
          : SnackBarPro.success(
              title: title!,
            ),
    );
  }

  static void showAppNotificationAdvanced(
      { String? title,
        required BuildContext context,
        Widget? avatar,
        String? message,
        bool? isError = true,
        VoidCallback? onTap,
        UserModel? user,
        String? avatarUrl})
  {
    Flushbar(
      titleText: TextWithTap(
        title ?? '',
        fontSize: MainHelper.isWebPlatform() ? 18 : 15,
        color: MainHelper.isDarkMode(context)
            ? kContentColorDarkTheme
            : kContentColorLightTheme,
        overflow: TextOverflow.ellipsis,
        fontWeight: FontWeight.w600,
        maxLines: 1,
      ),
      messageText: TextWithTap(
        message ?? '',
        fontSize: MainHelper.isWebPlatform() ? 15 : 13,
        color: MainHelper.isDarkMode(context)
            ? kContentColorDarkTheme
            : kContentColorLightTheme,
        overflow: TextOverflow.ellipsis,
        maxLines: 2,
      ),
      backgroundColor: MainHelper.isDarkMode(context)
          ? kContentColorLightTheme
          : const Color(0xFFFFFFFF),
      icon: user == null
          ? Icon(
        !isError!
            ? Icons.check_circle_outline
            : Icons.clear,
        size: 34.0,
        color:!isError
            ? Colors.greenAccent
            : const Color(0xffFA3967),)
          : ContainerCorner(
        width: 50.0,
        height: 50,
        child: ActionsHelper.polygonAvatarWidget(
            currentUser:user, fontSize: 12.0),),
      flushbarPosition: MainHelper.isWebPlatform() ? FlushbarPosition.BOTTOM : FlushbarPosition.TOP,
      margin: const EdgeInsets.all(8),
      borderRadius: BorderRadius.circular(8),
      duration: MainHelper.isWebPlatform() ? const Duration(seconds: 10) : const Duration(seconds: 5),
      flushbarStyle: FlushbarStyle.FLOATING,
      leftBarIndicatorColor: user == null
          ? !isError!
            ? Colors.greenAccent
            : const Color(0xffFA3967)
          : kTransparentColor,
    ).show(context);
  }

  static double convertDiamondsToMoney(int diamonds) {
    double totalMoney = (diamonds.toDouble() / 10000) * Setup.withDrawPercent;
    return totalMoney;
  }

  static double convertMoneyToDiamonds(double amount) {
    double diamonds = (amount.toDouble() * 10000) / Setup.withDrawPercent;
    return diamonds;
  }

  static int getDiamondsForReceiver(int diamonds) {
    double finalDiamonds = (diamonds / 100) * Setup.diamondsEarnPercent;
    return int.parse(finalDiamonds.toStringAsFixed(0));
  }

  static int getDiamondsForAgency(int diamonds) {
    double finalDiamonds = (diamonds / 100) * Setup.agencyPercent;
    return int.parse(finalDiamonds.toStringAsFixed(0));
  }

  static Future<ImageFile?> compressImage(ImageFile imageFile,
      {int quality = 40}) async {
    Configuration config = Configuration(
      outputType: ImageOutputType.jpg,
      // can only be true for Android and iOS while using ImageOutputType.jpg or ImageOutputType.pngÏ
      useJpgPngNativeCompressor: MainHelper.isMobile() ? true : false,
      // set quality between 0-100
      quality: quality,
    );

    final param = ImageFileConfiguration(input: imageFile, config: config);
    final output = await compressor.compress(param);

    return output;
  }

  static Future<MediaInfo?> compressVideo(XFile video) async {

    try {
      await VideoCompress.setLogLevel(0);
      final videoInfo = await VideoCompress.compressVideo(
        video.path,
        quality: VideoQuality.MediumQuality,
        deleteOrigin: false,
        includeAudio: true,
        // duration: Config.videoMaxDuration,
      );
      return videoInfo;
    }catch(e){
      VideoCompress.cancelCompression();
      return null;
    }

  }

  static DateTime getUntilDateFromDays(int days) {
    return DateTime.now().add(Duration(days: days));
  }

  static DateTime getUntilDateFromMinutes(int min) {
    return DateTime.now().add(Duration(minutes: min));
  }

  static bool isAvailable(DateTime expireDate) {
    DateTime now = DateTime.now();

    if (expireDate.isAfter(now)) {
      return true;
    } else {
      return false;
    }
  }

  static void showLoadingDialogWithText(BuildContext context,
      {bool? isDismissible,
      bool? useLogo = false,
      required String description,
      Color? backgroundColor}) {
    showDialog(
        context: context,
        barrierDismissible: isDismissible ?? false,
        builder: (BuildContext context) {
          var size = MediaQuery.of(context).size;
          return Scaffold(
            extendBodyBehindAppBar: true,
            backgroundColor: backgroundColor,
            body: Stack(
              children: [
                ContainerCorner(
                  borderWidth: 0,
                  color: kTransparentColor,
                  width: size.width,
                  height: size.height,
                  imageDecoration: "assets/images/app_bg.png",
                ),
                ClipRRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                    child: ContainerCorner(
                      width: size.width,
                      height: size.height,
                    ),
                  ),
                ),
                Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      useLogo! ? appLoadingLogo() : appLoading(),
                      TextWithTap(
                        description,
                        marginTop: !useLogo ? 10 : 15,
                        marginLeft: 15,
                        marginRight: 15,
                        color:Colors.white,
                        textAlign:TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        });
  }

  static void showProgressBarOnUploadingVideo(BuildContext context,
      {bool? isDismissible,
        Color? backgroundColor}) {
    showDialog(
        context: context,
        barrierDismissible: isDismissible ?? false,
        builder: (BuildContext context) {
          return const Dialog(
            child: ProgressBarOnUploadingVideo(),
          );
        });
  }

  static String generateRandomNnumbers(){
    var rng = Random();
    var code = '';

    for (var i = 0; i < 20; i++) {
      code = '$code${rng.nextInt(100)}';
    }
    return code;
  }

  static String getChallengerClassFormated(int? points){
    points = points ?? 0;
    var userClass = (points~/5000);
    String numberReturned = '';
    if(userClass~/100 > 0){
      numberReturned = userClass.toString();
    }else if(userClass~/10 > 0){
      numberReturned = '0$userClass';
    }else {
      numberReturned = '00$userClass';
    }
    return numberReturned;
  }

  static String getChallengerPointsFormated(int? points){
    String numberReturned = '';
    points = points ?? 0;
    if(points~/100 > 0){
      numberReturned = points.toString();
    }else if(points~/10 > 0){
      numberReturned = '0$points';
    }else {
      numberReturned = '00$points';
    }
    return numberReturned;
  }

  static String getViewersNumberFormated(int? points){
    String numberReturned = '';
    points = points ?? 0;
    if(points~/100 > 0){
      numberReturned = points.toString();
    }else if(points~/10 > 0){
      numberReturned = '$points';
    }else {
      numberReturned = '$points';
    }
    return numberReturned;
  }

  static Map convertListIntoMap(List list){
    return {};
  }
}

extension DurationExtensions on Duration {
  String toYearsMonthsDaysString() {
    final years = inDays ~/ 365;
    // You will need a custom logic for the months part, since not every month has 30 days
    final months = (inDays % 365) ~/ 30;
    final days = (inDays % 365) % 30;

    return "$years y - $months m - $days d";
  }
}
