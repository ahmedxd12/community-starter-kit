import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:fade_shimmer/fade_shimmer.dart';
import 'package:flutter_polygon_clipper/flutter_polygon_clipper.dart';
import 'package:flutter_svg/svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/notifications_helper.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:challenge/models/GroupMessageModel.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/NotificationsModel.dart';
import 'package:challenge/models/PostModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/widgets/AvatarInitials.dart';
import 'package:challenge/widgets/need_resume.dart';
import 'package:flutter/material.dart';

import '../../models/ChallengeModel.dart';
import '../../models/ReportModel.dart';
import '../../widgets/custom_widgets/text_with_tap.dart';
import '../main_utilities/colors.dart';

class ActionsHelper {
  
  static Widget avatarWidget(UserModel currentUser,
      {double? width, double? height, EdgeInsets? margin, String? imageUrl}) {
    if (currentUser.getAvatar != null) {
      if (currentUser.getAvatar.runtimeType == ParseFile) {
        return Container(
          margin: margin,
          width: width,
          height: height,
          child: CachedNetworkImage(
            imageUrl: currentUser.getAvatar!.url!,
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
              ),
            ),
            placeholder: (context, url) => _avatarInitials(currentUser),
            errorWidget: (context, url, error) => _avatarInitials(currentUser),
          ),
        );
      } else {
        return ClipRRect(
          borderRadius: BorderRadius.circular(70.0),
          child: Image.asset(
            "assets/images/img_credit_7.png",
            height: height,
            width: width,
            fit: BoxFit.fill,
          ),
        );
      }
    } else if (imageUrl != null) {
      return Container(
        margin: margin,
        width: width,
        height: height,
        child: CachedNetworkImage(
          imageUrl: imageUrl,
          imageBuilder: (context, imageProvider) => Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
            ),
          ),
        ),
      );
    } else {
      return _avatarInitials(currentUser);
    }
  }

  static Widget videoThumbnailWidget(
      VideoModel video, double? width, double? height,
      {EdgeInsets? margin, String? imageUrl}) {
    if (video.getThumbnail != null) {
      if (video.getThumbnail.runtimeType == ParseFile) {
        return ContainerCorner(
          width: width,
          height: height,
          child: CachedNetworkImage(
            imageUrl: video.getThumbnail!.url!,
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
              ),
            ),
            placeholder: (context, url) => _emptyVideoThumbnail(),
            errorWidget: (context, url, error) => _emptyVideoThumbnail(),
          ),
        );
      } else {
        return ClipRRect(
          borderRadius: BorderRadius.circular(70.0),
          child: Image.asset(
            "assets/images/img_credit_7.png",
            height: height,
            width: width,
            fit: BoxFit.fill,
          ),
        );
      }
    } else if (imageUrl != null) {
      return Container(
        margin: margin,
        width: width,
        height: height,
        child: CachedNetworkImage(
          imageUrl: imageUrl,
          imageBuilder: (context, imageProvider) => Container(
            decoration: BoxDecoration(
              image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
            ),
          ),
        ),
      );
    } else {
      return _emptyVideoThumbnail();
    }
  }

  static _emptyVideoThumbnail() {
    return const ContainerCorner(
      width: 30,
      height: 30,
      child: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }

  static Widget polygonAvatarWidget(
      {UserModel? currentUser,
      double? width,
      double? height,
      EdgeInsets? margin,
      String? imageUrl,
      double? fontSize}) {
    if(currentUser != null){
      if (currentUser.getAvatar != null) {
        if (currentUser.getAvatar.runtimeType == ParseFile) {
          return FlutterClipPolygon(
            sides: 6,
            borderRadius: 0.0, // Defaults to 0.0 degrees
            rotate: 0.0, // Defaults to 0.0 degree,
            child: Container(
              margin: margin,
              width: width,
              height: height,
              child: CachedNetworkImage(
                imageUrl: currentUser.getAvatar!.url ?? '',
                imageBuilder: (context, imageProvider) => Container(
                  decoration: BoxDecoration(
                    image:
                    DecorationImage(image: imageProvider, fit: BoxFit.cover),
                  ),
                ),
                placeholder: (context, url) =>
                    polygonAvatarInitials(currentUser, fontSize ?? 60),
                errorWidget: (context, url, error) =>
                    polygonAvatarInitials(currentUser, fontSize ?? 60),
              ),
            ),
          );
        } else {
          return ClipRRect(
            borderRadius: BorderRadius.circular(70.0),
            child: Image.asset(
              "assets/images/img_credit_7.png",
              height: height,
              width: width,
              fit: BoxFit.fill,
            ),
          );
        }
      } else if (imageUrl != null) {
        return FlutterClipPolygon(
          sides: 6,
          borderRadius: 0.0, // Defaults to 0.0 degrees
          rotate: 0.0, // Defaults to 0.0 degree,
          child: Container(
            margin: margin,
            width: width,
            height: height,
            child: CachedNetworkImage(
              imageUrl: imageUrl,
              imageBuilder: (context, imageProvider) => Container(
                decoration: BoxDecoration(
                  image: DecorationImage(image: imageProvider, fit: BoxFit.cover),
                ),
              ),
            ),
          ),
        );
      } else {
        return polygonAvatarInitials(currentUser, fontSize ?? 60);
      }
    }else{
      return const SizedBox();
    }
  }

  static Widget polygonAvatarInitials(UserModel currentUser, double? textSize) {
    return AvatarInitials(
      name: '${currentUser.getFirstName}',
      textSize: textSize ?? 18.0,
      backgroundColor: const Color(0xFFFF00C9),
      textColor: Colors.white,
      polygon: true,
    );
  }

  static Widget _avatarInitials(UserModel currentUser) {
    return AvatarInitials(
      name: '${currentUser.getFirstName}',
      textSize: 18,
      avatarRadius: 10,
      backgroundColor:
          MainHelper.isDarkModeNoContext() ? Colors.white : kPrimaryColor,
      textColor: MainHelper.isDarkModeNoContext()
          ? kContentColorLightTheme
          : kContentColorDarkTheme,
    );
  }

  static Widget groupCover(MessageGroupModel messageGroupModel) {
    if (messageGroupModel.getGroupCover == null) {
      return ContainerCorner(
        // borderRadius: 50,
        height: 55,
        width: 55,
        child:FlutterClipPolygon(
          sides: 6,
          borderRadius: 0.0, // Defaults to 0.0 degrees
          rotate: 0.0, // Defaults to 0.0 degree,
          child: const ContainerCorner(
            imageDecoration: "assets/images/group.jpeg",
            height: 55,
            width: 55,
          ),
        ),
      );
    } else {
      return ContainerCorner(
        // borderRadius: 50,
        height: 55,
        width: 55,
        child:FlutterClipPolygon(
          sides: 6,
          borderRadius: 0.0, // Defaults to 0.0 degrees
          rotate: 0.0, // Defaults to 0.0 degree,
          child: photosWidget(messageGroupModel.getGroupCover!.url,
              borderRadius: 50, width: 50, height: 50),
        ),
      );
    }
  }

  static Widget photosWidget(String? imageUrl,
      {double? borderRadius = 8,
      BoxFit? fit = BoxFit.cover,
      double? width,
      double? height,
      EdgeInsets? margin}) {
    return Container(
      margin: margin,
      width: width,
      height: height,
      child: CachedNetworkImage(
        imageUrl: imageUrl ?? "",
        imageBuilder: (context, imageProvider) => Container(
          decoration: BoxDecoration(
            //shape: boxShape!,
            borderRadius: BorderRadius.circular(borderRadius!),
            image: DecorationImage(image: imageProvider, fit: fit),
          ),
        ),
        placeholder: (context, url) => MainHelper.appLoading(),
        errorWidget: (context, url, error) => MainHelper.appLoading(),
      ),
    );
  }

  static Widget photosWidgetCircle(String imageUrl,
      {double? borderRadius = 8,
      BoxFit? fit = BoxFit.cover,
      double? width,
      double? height,
      EdgeInsets? margin,
      BoxShape? boxShape = BoxShape.rectangle,
      Widget? errorWidget}) {
    return Container(
      margin: margin,
      width: width,
      height: height,
      child: CachedNetworkImage(
        imageUrl: imageUrl,
        imageBuilder: (context, imageProvider) => Container(
          decoration: BoxDecoration(
            shape: boxShape!,
            //borderRadius: BorderRadius.circular(borderRadius!),
            image: DecorationImage(image: imageProvider, fit: fit),
          ),
        ),
        placeholder: (context, url) => _loadingWidget(),
        errorWidget: (context, url, error) => _loadingWidget(),
      ),
    );
  }

  static Widget profileAvatar(String imageUrl,
      {double? borderRadius = 0,
      BoxFit? fit = BoxFit.cover,
      double? width,
      double? height,
      EdgeInsets? margin,
      BoxShape? boxShape = BoxShape.rectangle}) {
    return Container(
      margin: margin,
      width: width,
      height: height,
      child: CachedNetworkImage(
        imageUrl: imageUrl,
        imageBuilder: (context, imageProvider) => Container(
          decoration: BoxDecoration(
            shape: boxShape!,
            //borderRadius: BorderRadius.circular(borderRadius!),
            image: DecorationImage(image: imageProvider, fit: fit),
          ),
        ),
        placeholder: (context, url) => _loadingWidget(),
        errorWidget: (context, url, error) =>
            SvgPicture.asset("assets/svg/ic_avatar.svg"),
      ),
    );
  }

  static Widget profileCover(String imageUrl,
      {double? borderRadius = 0,
      Widget? widget,
      BoxFit? fit = BoxFit.cover,
      double? width,
      double? height,
      EdgeInsets? margin}) {
    widget = Container();
    return Container(
      margin: margin,
      width: width,
      height: height,
      child: Stack(
        children: [
          CachedNetworkImage(
            imageUrl: imageUrl,
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                //shape: boxShape!,
                borderRadius: BorderRadius.circular(borderRadius!),
                image: DecorationImage(image: imageProvider, fit: fit),
              ),
            ),
            placeholder: (context, url) => _loadingWidget(),
            errorWidget: (context, url, error) => Center(
              child: SvgPicture.asset("assets/svg/ic_avatar.svg"),
            ),
          ),
          widget,
        ],
      ),
    );
  }

  static Widget gifWidget(String imageUrl,
      {double? borderRadius = 8, BoxFit? fit = BoxFit.cover}) {
    return CachedNetworkImage(
      imageUrl: imageUrl,
      imageBuilder: (context, imageProvider) => Container(
        decoration: BoxDecoration(
          //shape: BoxShape.circle,
          borderRadius: BorderRadius.circular(borderRadius!),
          image: DecorationImage(image: imageProvider, fit: fit),
        ),
      ),
      placeholder: (context, url) => FadeShimmer(
        height: 80,
        width: 80,
        fadeTheme:
            MainHelper.isDarkMode(context) ? FadeTheme.dark : FadeTheme.light,
        millisecondsDelay: 0,
      ),
      errorWidget: (context, url, error) => FadeShimmer(
        height: 80,
        width: 80,
        fadeTheme:
            MainHelper.isDarkMode(context) ? FadeTheme.dark : FadeTheme.light,
        millisecondsDelay: 0,
      ),
    );
  }

  static Widget _loadingWidget() {
    return const Center(child: CircularProgressIndicator());
  }

  static showUserProfile(
      BuildContext context, UserModel currentUser, UserModel user,
      {ResumableState? resumeState}) {
    MainHelper.goToNavigatorScreen(
        context, UserProfilePage(currentUser: currentUser, mUser: user));
  }

  static Widget noContentFound(String title, String explain, String image,
      {MainAxisAlignment? mainAxisAlignment = MainAxisAlignment.center,
      CrossAxisAlignment? crossAxisAlignment = CrossAxisAlignment.center}) {
    return Column(
      mainAxisAlignment: mainAxisAlignment!,
      crossAxisAlignment: crossAxisAlignment!,
      children: [
        ContainerCorner(
          height: 91,
          width: 91,
          marginBottom: 20,
          color: kTransparentColor,
          child: SvgPicture.asset(
            image,
            color: kGrayColor,
          ),
        ),
        TextWithTap(
          title,
          marginBottom: 0,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: kPrimaryColor,
        ),
        TextWithTap(
          explain,
          marginLeft: 10,
          marginRight: 10,
          marginBottom: 17,
          marginTop: 5,
          fontSize: 18,
          textAlign: TextAlign.center,
          fontWeight: FontWeight.w600,
          color: kGrayColor,
        )
      ],
    );
  }

  static Widget avatarBorder(UserModel user,
      {Function? onTap,
      double? width,
      double? height,
      EdgeInsets? avatarMargin,
      EdgeInsets? borderMargin,
      Color? borderColor = kPrimacyGrayColor,
      double? borderWidth = 1}) {
    return Center(
      child: Container(
        width: width,
        height: height,
        margin: borderMargin,
        decoration: BoxDecoration(
          border: Border.all(
            width: borderWidth!,
            color: borderColor!,
          ),
          shape: BoxShape.circle,
        ),
        child: ActionsHelper.avatarWidget(user,
            width: width, height: height, margin: avatarMargin),
      ),
    );
  }

  static createOrDeleteNotification(
      UserModel currentUser, UserModel toUser, String type,
      {PostsModel? post, LiveStreamingModel? live, ChallengeModel? challenge}) async {
    QueryBuilder<NotificationsModel> queryBuilder =
        QueryBuilder<NotificationsModel>(NotificationsModel());
    queryBuilder.whereEqualTo(NotificationsModel.keyAuthor, currentUser);
    queryBuilder.whereEqualTo(NotificationsModel.keyNotificationType, type);

    if (post != null) {
      queryBuilder.whereEqualTo(NotificationsModel.keyPost, post);
    }

    if (challenge != null) {
      queryBuilder.whereEqualTo(NotificationsModel.keyChallenge, challenge);
    }

    ParseResponse parseResponse = await queryBuilder.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        NotificationsModel notification = parseResponse.results!.first;
        await notification.delete();
      } else {
        NotificationsModel notificationsModel = NotificationsModel();
        notificationsModel.setAuthor = currentUser;
        notificationsModel.setAuthorId = currentUser.objectId!;

        notificationsModel.setReceiver = toUser;
        notificationsModel.setReceiverId = toUser.objectId!;

        notificationsModel.setNotificationType = type;
        notificationsModel.setRead = false;

        if (post != null) {
          notificationsModel.setPost = post;
        }

        if (live != null) {
          notificationsModel.setLive = live;
        }

        if (challenge != null) {
          notificationsModel.setChallenge = challenge;
        }

        await notificationsModel.save();

        if (post != null) {
          NotificationsHelper.sendPush(currentUser, toUser, type,
              objectId: post.objectId!);
        } else if (live != null) {
          NotificationsHelper.sendPush(currentUser, toUser, type,
              objectId: live.objectId!);
        } else if (challenge != null) {
          NotificationsHelper.sendPush(currentUser, toUser, type,
              objectId: challenge.objectId!,message: "message_screen.challenge_invite_alert_message".tr());
        } else {
          NotificationsHelper.sendPush(currentUser, toUser, type);
        }
      }
    }
  }

  static Future<ParseResponse> report({required String type,
    required String message,
    String? description,
    required UserModel accuser,
    required UserModel accused,
    LiveStreamingModel? liveStreamingModel,
    PostsModel? postsModel}) async {

    ReportModel reportModel = ReportModel();

    reportModel.setReportType = type;

    reportModel.setAccuser = accuser;
    reportModel.setAccuserId = accuser.objectId!;

    reportModel.setAccused = accused;
    reportModel.setAccusedId = accused.objectId!;

    if(liveStreamingModel != null) reportModel.setLiveStreaming = liveStreamingModel;
    /*if(postsModel != null) reportModel.setPost = postsModel;*/

    reportModel.setMessage = message;
    if(description != null) reportModel.setDescription = description;

    return await reportModel.save();

  }
}
