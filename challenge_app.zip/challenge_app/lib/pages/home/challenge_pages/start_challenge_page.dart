// ignore_for_file: must_be_immutable, use_build_context_synchronously
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:lottie/lottie.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/livestreaming_pages/live_creation_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/pages/home/stories_page/story_type_chooser_page.dart';
import 'package:challenge/pages/home/video_pages/elimination_videos_page.dart';
import 'package:challenge/pages/home/video_pages/upload_video_page.dart';
import 'package:challenge/models/CategoryModel.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/widgets/custome_drawer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../configurations/constants_config.dart';
import '../../../configurations/global_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../models/AudioChatUsersModel.dart';
import '../../../models/LiveStreamingModel.dart';
import '../../../widgets/components_widgets/coins_payment_widget.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../audio_live_page/audio_live_page.dart';
import '../profile_pages/profile_edit_page.dart';

class StartChallengePage extends StatefulWidget {
  static const String route = "/Challenge";

  UserModel? currentUser;

  StartChallengePage({this.currentUser, Key? key}) : super(key: key);

  @override
  State<StartChallengePage> createState() => _StartChallengePageState();
}

class _StartChallengePageState extends State<StartChallengePage> {
  int tabIndex = 0;
  TextEditingController searchController = TextEditingController();
  TextEditingController pointController = TextEditingController();
  String searchText = "";

  String selectedMode = "";
  String selectedReward = "";
  int numberOfRounds = 0;
  UserModel? challenger;

  var categoriesIcons = [
    "assets/svg/ic_cat_dance.svg",
    "assets/svg/ic_cat_art.svg",
    "assets/svg/ic_cat_jokes.svg",
    "assets/svg/ic_cat_sport.svg",
    "assets/svg/ic_cat_logic.svg",
    "assets/svg/ic_cat_fun.svg",
    "assets/svg/ic_cat_cook.svg",
    "assets/svg/ic_cat_sing.svg",
    "assets/svg/ic_cat_inventive.svg",
    "assets/svg/ic_cat_family.svg",
    "assets/svg/ic_cat_jokes.svg",
    "assets/svg/ic_cat_sport.svg"
  ];

  var categoriesLabels = [
    ChallengeModel.categoryDance,
    ChallengeModel.categoryART,
    ChallengeModel.categoryJOKES,
    ChallengeModel.categorySPORT,
    ChallengeModel.categoryLOGIC,
    ChallengeModel.categoryFUN,
    ChallengeModel.categoryCOOK,
    ChallengeModel.categorySING,
    ChallengeModel.categoryINVENTIVE,
    ChallengeModel.categoryFAMILY,
    ChallengeModel.categorySNERVATING,
    ChallengeModel.categoryPENANCE,
  ];

  var selectedCategory = '';
  var selectedDuration = 0;
  var challengePoints = 0;

  var duration = [1440, 60, 5, 360, 2880];
  var rounds = [3, 5, 7, 9, 11];
  var points = [10, 25, 40, 90, 150];

  var steps = [1, 2, 3, 4, 5];
  String image = '';

  List<dynamic> stack = [];
  List<dynamic> allCategories = [];

  bool showSmallNativeAd = false;
  bool isNativeAdLoaded = false;

  bool isFirstTime = false;
  late SharedPreferences sharedPreferences;
  
  _initPreferences() async {
    sharedPreferences = await SharedPreferences.getInstance();
  }

  Future<void> checkPermissionAudio(bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) async {
    if (MainHelper.isAndroidPlatform()) {
      PermissionStatus status = await Permission.storage.status;
      PermissionStatus status2 = await Permission.camera.status;
      PermissionStatus status3 = await Permission.microphone.status;
      if (kDebugMode) {
        print('Permission android');
      }

      checkStatusAudio(status, status2, status3, isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    } else if (MainHelper.isIOSPlatform()) {
      PermissionStatus status = await Permission.photos.status;
      PermissionStatus status2 = await Permission.camera.status;
      PermissionStatus status3 = await Permission.microphone.status;
      if (kDebugMode) {
        print('Permission ios');
      }

      checkStatusAudio(status, status2, status3, isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    } else {
      if (kDebugMode) {
        print('Permission other device');
      }
      _gotoLiveScreenAudio(isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    }
  }

  void checkStatusAudio(PermissionStatus status, PermissionStatus status2,
      PermissionStatus status3, bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) {
    if (status.isDenied || status2.isDenied || status3.isDenied) {
      // We didn't ask for permission yet or the permission has been denied before but not permanently.

      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access".tr(),
          confirmButtonText: "permissions.okay_".tr().toUpperCase(),
          message: "permissions.photo_access_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () async {
            MainHelper.hideLoadingDialog(context);
            //if (await Permission.camera.request().isGranted) {
            // Either the permission was already granted before or the user just granted it.
            //}
            // You can request multiple permissions at once.
            Map<Permission, PermissionStatus> statuses = await [
              Permission.camera,
              Permission.photos,
              Permission.storage,
              Permission.microphone,
            ].request();

            if (statuses[Permission.camera]!.isGranted &&
                statuses[Permission.photos]!.isGranted ||
                statuses[Permission.storage]!.isGranted ||
                statuses[Permission.microphone]!.isGranted) {
              _gotoLiveScreenAudio(isBroadcaster,
                  channel: channel, liveStreamingModel: liveStreamingModel);
            }
          });
    } else if (status.isPermanentlyDenied ||
        status2.isPermanentlyDenied ||
        status3.isPermanentlyDenied) {
      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access_denied".tr(),
          confirmButtonText: "permissions.okay_settings".tr().toUpperCase(),
          message: "permissions.photo_access_denied_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () {
            MainHelper.hideLoadingDialog(context);

            openAppSettings();
          });
    } else if (status.isGranted && status2.isGranted && status3.isGranted) {
      //_uploadPhotos(ImageSource.gallery);
      _gotoLiveScreenAudio(isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    }

    if (kDebugMode) {
      print('Permission $status');
      print('Permission $status2');
      print('Permission $status3');
    }

  }

  changeImage(String path) {
    setState(() {
      image = path;
    });
  }

  getAllCategories() async {
    QueryBuilder<CategoryModel> query = QueryBuilder(CategoryModel());
    query.orderByAscending(CategoryModel.keyName);

    ParseResponse response = await query.query();

    if (response.success) {
      if (response.result != null) {
        setState(() {
          allCategories = response.results as List<dynamic>;
        });
      }
    }
  }

  late final AdManagerBannerAd banner;
  late final AdWidget adWidget;

  bool isBannerInit = false;

  loadBanner(){
    banner = AdManagerBannerAd(
      adUnitId: Constants.getAdmobBannerUnit(),
      sizes: [AdSize.banner],
      request: const AdManagerAdRequest(),
      listener: AdManagerBannerAdListener(),
    );

    banner.load();
    adWidget = AdWidget(ad: banner);

    isBannerInit = true;
  }

  @override
  void initState() {
    getAllCategories();
    _initPreferences();
    super.initState();
  }

  @override
  dispose() {
    super.dispose();
    banner.dispose();
  }

  double getProgressPercentage(int? amount, Size size) {
    if (amount! > Config.progressBarLimit) {
      return double.parse(Config.progressBarLimit.toString());
    } else {
      var coin = amount;
      return (size.width - (size.width / 10 * 2)) *
          coin /
          Config.progressBarLimit;
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    if(!isBannerInit){
      loadBanner();
    }

    return GestureDetector(
      onTap: () => MainHelper.removeFocusOnTextField(context),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: false,
        backgroundColor: kTransparentColor,
        endDrawer: CustomDrawer(
          currentUser: widget.currentUser,
        ),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          backgroundColor: kAppBarBackgroundColor,
          leading: ContainerCorner(
            onTap: () {
              MainHelper.goToNavigatorScreen(
                context,
                ProfilePage(
                  currentUser: widget.currentUser!,
                ),
                back: true,
              );
            },
            width: size.width / 30,
            height: size.width / 30,
            child: Padding(
              padding: const EdgeInsets.only(left: 8.0, top: 4.5, bottom: 4.5),
              child: ActionsHelper.polygonAvatarWidget(
                  currentUser: widget.currentUser!,
                  fontSize: 13),
            ),
          ),
          titleSpacing: 2.0,
          title: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWithTap(
                    widget.currentUser!.getUsername ?? '',
                    fontSize: 13,
                    color: kContentColorDarkTheme,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWithTap(
                        'challenges.user_class'.tr(namedArgs: {
                          'number': widget.currentUser!.getPoints.toString()
                        }),
                        color: kProfileProgressbarColor,
                        fontSize: 11,
                      ),
                      TextWithTap(
                        'challenges.user_point'.tr(namedArgs: {
                          'number': widget.currentUser!.getCredits.toString()
                        }),
                        color: kTicketYellowColor,
                        fontSize: 11,
                      ),
                    ],
                  )
                ],
              ),
              ContainerCorner(
                borderColor: kProfileProgressbarColor,
                borderWidth: 1,
                color: kTransparentColor,
                height: size.width / 32,
                marginTop: 5,
                child: Row(
                  children: [
                    ContainerCorner(
                      alignment: Alignment.centerLeft,
                      color: kProfileProgressbarColor,
                      height: size.width / 32,
                      width: getProgressPercentage(
                          widget.currentUser!.getPoints, size),
                    ),
                  ],
                ),
              ),
            ],
          ),
          actions: [
            Builder(builder: (ctx) {
              return ContainerCorner(
                onTap: () => Scaffold.of(ctx).openEndDrawer(),
                imageDecoration: "assets/images/top_btn.png",
                width: size.width / 7,
                height: size.height / 5,
              );
            }),
          ],
        ),
        body: Stack(
          alignment: AlignmentDirectional.bottomCenter,
          children: [
            ContainerCorner(
              imageDecoration: "assets/images/app_bg.png",
              width: size.width,
              height: size.height,
              borderWidth: 0,
            ),
            SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: SafeArea(
                      child: ContainerCorner(
                        width: size.width,
                        height: size.height * 0.80,
                        color: kPrimaryViolet,
                        child: widget.currentUser!.getIsViewer!
                            ? eliminationChallenge(size)
                            : Stack(
                                children: [
                                  IndexedStack(
                                    index: tabIndex,
                                    children: [
                                      createOrStart(size),
                                      challengeMode(size),
                                      selectChallenger(size),
                                      challengeReward(size),
                                      livePollRounds(size),
                                      pollStartStep(size),
                                      oneVsOneCategory(size),
                                      enterPoints(size)
                                    ],
                                  ),
                                  Visibility(
                                    visible: stack.isNotEmpty,
                                    child: Positioned(
                                      left: size.width * 0.02,
                                      top: size.width * 0.02,
                                      child: ContainerCorner(
                                        onTap: () {
                                          stack.removeLast();
                                          setState(() {
                                            if (stack.isNotEmpty) {
                                              tabIndex = stack.last;
                                              changeImage(
                                                  'assets/images/${steps[stack.indexOf(stack.last)]}.png');
                                            } else {
                                              tabIndex = 0;
                                              image = '';
                                            }
                                          });
                                        },
                                        child: const Center(
                                          child: Icon(
                                            Icons.arrow_back,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget eliminationChallenge(var size) {
    return Padding(
      padding: EdgeInsets.only(top: size.height * 0.15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextWithTap(
            "challenges.start_elimination".tr().toUpperCase(),
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontSize: size.width / 15,
            textAlign: TextAlign.center,
            marginTop: size.width / 15,
            marginBottom: size.width / 30,
          ),
          TextWithTap(
            "challenges.voting_message".tr(),
            color: Colors.white,
            fontSize: size.width / 24,
            marginBottom: size.width / 10,
            textAlign: TextAlign.center,
          ),
          ContainerCorner(
            radiusBottomRight: 20,
            borderWidth: 2,
            imageDecoration: "assets/images/btn_design.png",
            radiusTopLeft: 20,
            marginTop: size.width / 15,
            height: size.width / 7,
            marginLeft: size.width / 15,
            marginRight: size.width / 15,
            width: size.width,
            onTap: () => MainHelper.goToNavigatorScreen(
              context,
              VideoEliminationPage(
                currentUser: widget.currentUser,
              ),
            ),
            child: Center(
              child: TextWithTap(
                "challenges.elimination".tr().toUpperCase(),
                color: Colors.white,
                fontSize: size.width / 20,
              ),
            ),
          ),
          showBanner(size),
        ],
      ),
    );
  }

  Widget createOrStart(var size) {
    return Column(
      children: [
        TextWithTap(
          "challenges.new_challenge".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.choose".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width / 10,
        ),
        ContainerCorner(
          radiusBottomRight: 20,
          borderWidth: 2,
          imageDecoration: "assets/images/btn_design.png",
          radiusTopLeft: 20,
          marginTop: size.width / 15,
          height: size.width / 7,
          marginLeft: size.width / 15,
          marginRight: size.width / 15,
          width: size.width,
          onTap: () {
            setState(() {
              tabIndex = 1;
              stack.add(tabIndex);
              changeImage('assets/images/${steps[0]}.png');
            });
          },
          child: Center(
            child: TextWithTap(
              "challenges.create".tr().toUpperCase(),
              color: Colors.white,
              fontSize: size.width / 20,
            ),
          ),
        ),
        ContainerCorner(
          radiusBottomRight: 20,
          borderWidth: 2,
          imageDecoration: "assets/images/btn_design.png",
          radiusTopLeft: 20,
          marginTop: size.width / 15,
          height: size.width / 7,
          marginLeft: size.width / 15,
          marginRight: size.width / 15,
          width: size.width,
          onTap: () => MainHelper.goToNavigatorScreen(
              context,
              StoryTypeChooserPage(
                currentUser: widget.currentUser,
              )),
          child: Center(
            child: TextWithTap(
              "challenges.create_story".tr().toUpperCase(),
              color: Colors.white,
              fontSize: size.width / 20,
            ),
          ),
        ),
        showBanner(size),
      ],
    );
  }

  Widget showBanner(var size){
    return Visibility(
      visible: isBannerInit,
      child: ContainerCorner(
        marginTop: size.height * 0.035,
        width: size.width,
        height: size.height * 0.08,
        child: adWidget,
      ),
    );
  }

  Widget challengeMode(var size) {
    return Column(
      children: [
        TextWithTap(
          "challenges.new_challenge".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.choose_mode".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width * 0.2,
        ),
        Flexible(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: List.generate(
              MainHelper.getChallengeModeCodeList().length,
              (index) => ContainerCorner(
                imageDecoration: "assets/images/btn_design.png",
                marginTop: size.width / 40,
                marginBottom: size.width / 20,
                height: size.width / 10,
                marginLeft: size.width / 15,
                marginRight: size.width / 15,
                width: size.width,
                onTap: () {
                  selectedMode = MainHelper.getChallengeModeCodeList()[index];
                  if (MainHelper.getChallengeModeCodeList()[index] ==
                      ChallengeModel.mode1VS1) {
                    setState(() {
                      tabIndex = 2;
                      stack.add(tabIndex);
                      changeImage('assets/images/${steps[1]}.png');
                    });
                  } else if (MainHelper.getChallengeModeCodeList()[index] ==
                      ChallengeModel.modeLIVESTREAMING) {
                    MainHelper.goToNavigatorScreen(
                      context,
                      LiveCreationPage(currentUser: widget.currentUser!),
                    );
                  } else if (MainHelper.getChallengeModeCodeList()[index] ==
                      ChallengeModel.modeAUDIOROOM) {
                    checkPermissionAudio(true);
                  }
                },
                child: Center(
                  child: TextWithTap(
                    MainHelper.getChallengeModeList(
                            MainHelper.getChallengeModeCodeList()[index])
                        .toUpperCase(),
                    color: Colors.white,
                    fontSize: size.width / 20,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget challengeReward(var size) {
    return Column(
      children: [
        TextWithTap(
          selectedMode == ChallengeModel.mode1VS1
              ? "challenges.1v1".tr().toUpperCase()
              : "challenges.live_poll".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.choose_reward".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width / 50,
        ),
        Flexible(
          child: Column(
            children: List.generate(
              6,
              (index) => ContainerCorner(
                imageDecoration: "assets/images/btn_design.png",
                marginTop: size.width / 40,
                height: size.width / 10,
                marginLeft: size.width / 15,
                marginRight: size.width / 15,
                width: size.width,
                onTap: () {
                  setState(() {
                    selectedReward =
                        MainHelper.getChallengeRewardCodeList()[index];

                    if (selectedMode == ChallengeModel.mode1VS1) {
                      createChallenge();
                    }

                    changeImage(
                        'assets/images/${steps[selectedMode != ChallengeModel.mode1VS1 ? 3 : 4]}.png');
                  });
                },
                child: Center(
                  child: TextWithTap(
                    MainHelper.getChallengeRewardList(
                            MainHelper.getChallengeRewardCodeList()[index])
                        .toUpperCase(),
                    color: Colors.white,
                    fontSize: size.width / 20,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget livePollRounds(var size) {
    return Column(
      children: [
        TextWithTap(
          "challenges.live_poll".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.choose_rounds".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width / 50,
        ),
        Flexible(
          child: Column(
            children: List.generate(
              rounds.length,
              (index) => ContainerCorner(
                imageDecoration: "assets/images/btn_design.png",
                marginTop: size.width / 40,
                height: size.width / 10,
                marginLeft: size.width / 15,
                marginRight: size.width / 15,
                width: size.width,
                onTap: () {
                  setState(() {
                    numberOfRounds = rounds[index];
                    tabIndex = 5;
                    stack.add(tabIndex);
                    changeImage('assets/images/${steps[4]}.png');
                  });
                },
                child: Center(
                  child: TextWithTap(
                    rounds[index].toString(),
                    color: Colors.white,
                    fontSize: size.width / 20,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget pollStartStep(var size) {
    return Column(
      children: [
        TextWithTap(
          "challenges.live_poll".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.create_challenges".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width / 50,
        ),
        Flexible(
          child: Column(
            children: List.generate(
              rounds.length,
              (index) => ContainerCorner(
                imageDecoration: "assets/images/btn_start_challenge.png",
                marginTop: size.width / 40,
                height: size.width / 10,
                marginLeft: size.width * 0.025,
                marginRight: size.width * 0.025,
                width: size.width,
                onTap: () {
                  createChallenge();
                },
                child: Center(
                  child: Row(
                    children: [
                      TextWithTap(
                        "challenges.round_start"
                            .tr(namedArgs: {"index": (index + 1).toString()}),
                        color: Colors.white,
                        fontSize: size.width / 23,
                        marginLeft: size.width * 0.07,
                        marginRight: size.width * 0.09,
                      ),
                      TextWithTap(
                        points[index].toString(),
                        color: kPrimaryViolet,
                        fontSize: size.width / 23,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget selectChallenger(var size) {
    return Column(
      children: [
        TextWithTap(
          selectedMode == ChallengeModel.mode1VS1
              ? "challenges.1v1".tr().toUpperCase()
              : "challenges.live_poll".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.select_challenger".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width / 50,
        ),
        ContainerCorner(
          radiusBottomRight: 20,
          borderWidth: 2,
          imageDecoration: "assets/images/btn_design.png",
          radiusTopLeft: 20,
          marginTop: size.width / 15,
          height: size.width / 7,
          marginLeft: size.width / 10,
          marginRight: size.width / 10,
          width: size.width,
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: Center(
              child: TextField(
                autocorrect: false,
                keyboardType: TextInputType.emailAddress,
                maxLines: 1,
                style: const TextStyle(color: Colors.white),
                onChanged: (text) {
                  setState(() {
                    searchText = text;
                  });
                },
                textAlign: TextAlign.center,
                controller: searchController,
                decoration: InputDecoration(
                  hintText: "challenges.search_".tr().toLowerCase(),
                  hintStyle: GoogleFonts.azeretMono(
                      color: Colors.white, fontSize: size.width / 20),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
        ),
        TextWithTap(
          "challenges.your_favorite".tr().toUpperCase(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginTop: size.width / 15,
        ),
        Visibility(
          visible: searchText.isEmpty,
          child: Expanded(
            child: _getYourFavorites(),
          ),
        ),
        Visibility(
          visible: searchText.isNotEmpty,
          child: Expanded(
            child: _searchYourFavorites(),
          ),
        ),
      ],
    );
  }

  _getYourFavorites() {
    var size = MediaQuery.of(context).size;
    QueryBuilder<UserModel> query =
        QueryBuilder<UserModel>(UserModel.forQuery());
    query.whereNotEqualTo(UserModel.keyObjectId, widget.currentUser!.objectId);
    query.whereNotEqualTo(UserModel.keyUsername, UserModel.roleAdmin);
    query.whereNotContainedIn(UserModel.keyObjectId, widget.currentUser!.getBlockedUsersIDs!);
    query.whereEqualTo(UserModel.keyIsViewer, false);

    return ParseLiveListWidget<UserModel>(
      query: query,
      reverse: false,
      lazyLoading: false,
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      duration: const Duration(milliseconds: 200),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<UserModel> snapshot) {
        if (snapshot.hasData) {
          UserModel user = snapshot.loadedData!;

          return GestureDetector(
            onTap: () {
              setState(() {
                if(checkChallenger(user)){
                  challenger = user;
                  tabIndex = selectedMode != ChallengeModel.mode1VS1 ? 3 : 6;
                  stack.add(tabIndex);
                  changeImage('assets/images/${steps[2]}.png');
                }else{
                  MainHelper.showAppNotificationAdvanced(
                      title: 'challenges.challenge_forbidden_title'.tr(),
                      message: 'challenges.challenge_forbidden_message'.tr(),
                      context: context
                  );
                }
              });
            },
            child: ContainerCorner(
              height: 107,
              child: Column(
                children: [
                  ContainerCorner(
                    borderWidth: 0.0,
                    marginLeft: 10,
                    height: size.width / 5,
                    width: size.width / 5,
                    child:
                        ActionsHelper.polygonAvatarWidget(
                            currentUser:user, fontSize: 30),
                  ),
                  TextWithTap(
                    "@${user.getFirstName!}",
                    overflow: TextOverflow.ellipsis,
                    color: Colors.white,
                  )
                ],
              ),
            ),
          );
        } else {
          return Center(
            child: MainHelper.appLoading(),
          );
        }
      },
      listLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  _searchYourFavorites() {
    var size = MediaQuery.of(context).size;
    QueryBuilder<UserModel> query =
        QueryBuilder<UserModel>(UserModel.forQuery());

    query.whereContains(UserModel.keyFullName, searchText);
    query.whereNotEqualTo(UserModel.keyObjectId, widget.currentUser!.objectId);
    query.whereNotEqualTo(UserModel.keyUsername, UserModel.roleAdmin);
    query.whereNotContainedIn(UserModel.keyObjectId, widget.currentUser!.getBlockedUsersIDs!);
    query.whereEqualTo(UserModel.keyIsViewer, false);

    return ParseLiveListWidget<UserModel>(
      query: query,
      reverse: false,
      lazyLoading: false,
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      duration: const Duration(milliseconds: 200),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<UserModel> snapshot) {
        if (snapshot.hasData) {
          UserModel user = snapshot.loadedData!;

          return GestureDetector(
            onTap: () {
              setState(() {
                if(checkChallenger(user)){
                  challenger = user;
                  tabIndex = selectedMode != ChallengeModel.mode1VS1 ? 3 : 6;
                  stack.add(tabIndex);
                  changeImage('assets/images/${steps[2]}.png');
                }else{
                  MainHelper.showAppNotificationAdvanced(
                      title: 'challenges.challenge_forbidden_title'.tr(),
                      message: 'challenges.challenge_forbidden_message'.tr(),
                      context: context
                  );
                }

              });
            },
            child: ContainerCorner(
              height: 107,
              child: Column(
                children: [
                  ContainerCorner(
                    borderWidth: 0.0,
                    marginLeft: 10,
                    height: size.width / 5,
                    width: size.width / 5,
                    child:
                        ActionsHelper.polygonAvatarWidget(
                            currentUser:user, fontSize: 30),
                  ),
                  TextWithTap(
                    "@${user.getFirstName!}",
                    overflow: TextOverflow.ellipsis,
                    color: Colors.white,
                  )
                ],
              ),
            ),
          );
        } else {
          return Center(
            child: TextWithTap(
              "challenges.loading_".tr(),
              overflow: TextOverflow.ellipsis,
              color: Colors.white,
            ),
          );
        }
      },
      listLoadingElement: Center(
        child: TextWithTap(
          "challenges.loading_".tr(),
          overflow: TextOverflow.ellipsis,
          color: Colors.white,
        ),
      ),
      queryEmptyElement: Center(
        child: TextWithTap(
          "challenges.none_found".tr(),
          overflow: TextOverflow.ellipsis,
          color: Colors.white,
        ),
      ),
    );
  }

  Widget oneVsOneCategory(var size) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          TextWithTap(
            "challenges.1v1".tr().toUpperCase(),
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontSize: size.width / 15,
            marginTop: size.width / 15,
            marginBottom: size.width / 30,
          ),
          TextWithTap(
            "challenges.choose_category".tr(),
            color: Colors.white,
            fontSize: size.width / 23,
          ),
          Visibility(
            visible: allCategories.isNotEmpty,
            child: GridView.count(
              shrinkWrap: true,
              crossAxisCount: 4,
              mainAxisSpacing: 10.0,
              crossAxisSpacing: 10.0,
              physics: const NeverScrollableScrollPhysics(),
              children: List.generate(
                allCategories.length,
                (index) {
                  CategoryModel category = allCategories[index];

                  return ContainerCorner(
                    borderWidth: 2,
                    borderRadius: 4,
                    onTap: () {
                      selectedCategory = category.objectId!;
                      createChallenge();
                      /*setState(() {
                        tabIndex = 3;
                        stack.add(tabIndex);
                        changeImage('assets/images/${steps[3]}.png');
                      });*/
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SvgPicture.network(
                          category.getImage!.url!,
                          height: 25,
                          width: 25,
                        ),
                        TextWithTap(
                          category.getName!.toUpperCase(),
                          color: Colors.white,
                          fontSize: size.width / 35,
                          marginTop: 5,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget enterPoints(var size) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        TextWithTap(
          "challenges.1v1".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 50,
        ),
        TextWithTap(
          "challenges.point".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
        ),
        ContainerCorner(
          radiusBottomRight: 20,
          borderWidth: 2,
          imageDecoration: "assets/images/btn_design.png",
          radiusTopLeft: 20,
          marginTop: size.width / 5,
          height: size.width / 7,
          marginLeft: size.width / 15,
          marginRight: size.width / 15,
          width: size.width,
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: Center(
              child: TextField(
                controller: pointController,
                autocorrect: false,
                keyboardType: TextInputType.number,
                maxLines: 1,
                style: const TextStyle(color: Colors.white),
                onChanged: (text) {
                  setState(() {
                    challengePoints = int.parse(text);
                  });
                },
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: "challenges.add_points".tr().toLowerCase(),
                  hintStyle: GoogleFonts.azeretMono(
                      color: Colors.white, fontSize: size.width / 20),
                  border: InputBorder.none,
                ),
              ),
            ),
          ),
        ),
        ContainerCorner(
          radiusBottomRight: 20,
          borderWidth: 2,
          imageDecoration: "assets/images/btn_design.png",
          radiusTopLeft: 20,
          marginTop: size.width / 15,
          height: size.width / 7,
          marginLeft: size.width / 15,
          marginRight: size.width / 15,
          width: size.width,
          onTap: () {
            verifyPoints();
          },
          child: Center(
            child: TextWithTap(
              "challenges.add_point_button".tr(),
              color: Colors.white,
              fontSize: size.width / 20,
            ),
          ),
        ),
      ],
    );
  }

  Widget oneVsOneDuration(var size) {
    return Column(
      children: [
        TextWithTap(
          "challenges.1v1".tr().toUpperCase(),
          fontWeight: FontWeight.w900,
          color: Colors.white,
          fontSize: size.width / 15,
          marginTop: size.width / 15,
          marginBottom: size.width / 30,
        ),
        TextWithTap(
          "challenges.choose_duration".tr(),
          color: Colors.white,
          fontSize: size.width / 23,
          marginBottom: size.width / 50,
        ),
        Flexible(
          child: Column(
            children: List.generate(
              rounds.length,
              (index) => ContainerCorner(
                imageDecoration: "assets/images/btn_design.png",
                marginTop: size.width / 40,
                height: size.width / 10,
                marginLeft: size.width / 15,
                marginRight: size.width / 15,
                width: size.width,
                onTap: () {
                  setState(() {
                    selectedDuration = duration[index];
                  });
                  createChallenge();
                },
                child: Center(
                  child: TextWithTap(
                    duration[index] == 5
                        ? '${duration[index]}min'
                        : '${convertDuration(duration[index])}h',
                    color: Colors.white,
                    fontSize: size.width / 20,
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  convertDuration(int time) {
    return time ~/ 60;
  }

  verifyPoints() {
    if (challengePoints <= 0) {
      MainHelper.showAppNotificationAdvanced(
          title: "challenges.point_required_message".tr(), context: context);
    } else if (widget.currentUser!.getGoldenCoin == null ||
        challengePoints > widget.currentUser!.getGoldenCoin!) {
      MainHelper.showAppNotificationAdvanced(
          title: "challenges.author_points_message".tr(), context: context);
    } else if (challenger!.getGoldenCoin == null ||
        challengePoints > challenger!.getGoldenCoin!) {
      MainHelper.showAppNotificationAdvanced(
          title: "challenges.challenger_points_message".tr(), context: context);
    } else {
      createChallenge();
    }
  }

  createChallenge() {
    ChallengeModel newChallenge = ChallengeModel();

    newChallenge.setAuthor = widget.currentUser!;
    newChallenge.setAuthorId = widget.currentUser!.objectId!;

    if (selectedMode == ChallengeModel.mode1VS1) {
      newChallenge.setChallenger = challenger!;
      newChallenge.setChallengerId = challenger!.objectId!;
    }

    newChallenge.setMode = selectedMode;
    newChallenge.setReward = selectedReward;

    /*if (selectedMode == ChallengeModel.modePOLL) {
      newChallenge.setRound = numberOfRounds;
    }*/

    if (selectedMode == ChallengeModel.mode1VS1) {
      newChallenge.setCategory = selectedCategory;
      // newChallenge.setDuration = selectedDuration;
      // newChallenge.setPoint = challengePoints;
      // newChallenge.setExpireDate = MainHelper.getUntilDateFromMinutes(selectedDuration);
    }

    MainHelper.goToNavigatorScreen(
        context,
        UploadVideoPage(
          currentUser: widget.currentUser,
          challenge: newChallenge,
          isRePropose: false,
          isAuthor: true,
        ));
  }

  bool checkChallenger(UserModel challenger){
    return !challenger.getBlockedUsersIDs!.contains(widget.currentUser!.objectId);
  }

  _gotoLiveScreenAudio(bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) async {
    if (widget.currentUser!.getAvatar == null) {
      MainHelper.showDialogLivEend(
        context: context,
        dismiss: true,
        title: 'live_streaming.photo_needed'.tr(),
        confirmButtonText: 'live_streaming.add_photo'.tr(),
        message: 'live_streaming.photo_needed_explain'.tr(),
        onPressed: () {
          MainHelper.goBackToPreviousPage(context);
          MainHelper.goToNavigatorScreen(
              context,
              ProfileEditPage(
                currentUser: widget.currentUser,
              ));
        },
      );
    } else {
      if (isBroadcaster) {
        createLiveAudio();
      } else {
        if (liveStreamingModel!.getPrivate!) {
          if (!liveStreamingModel.getPrivateViewersId!
              .contains(widget.currentUser!.objectId!)) {
            openPayPrivateLiveSheet(liveStreamingModel);
          } else {
            MainHelper.goToNavigatorScreen(
                context,
                AudioLivePage(
                  channelName: channel!,
                  isBroadcaster: false,
                  currentUser: widget.currentUser!,
                  mUser: liveStreamingModel.getAuthor,
                  isUserInvited: liveStreamingModel.getInvitedPartyUid!
                      .contains(widget.currentUser!.getUid!),
                  mLiveStreamingModel: liveStreamingModel,
                  preferences: sharedPreferences,
                ));
          }
        } else {
          MainHelper.goToNavigatorScreen(
              context,
              AudioLivePage(
                channelName: channel!,
                isBroadcaster: false,
                currentUser: widget.currentUser!,
                mUser: liveStreamingModel.getAuthor,
                isUserInvited: liveStreamingModel.getInvitedPartyUid!
                    .contains(widget.currentUser!.getUid!),
                mLiveStreamingModel: liveStreamingModel,
                preferences: sharedPreferences,
              ));
        }
      }
    }
  }

  void isFirstLiveAudio() async {
    QueryBuilder<LiveStreamingModel> queryBuilder =
    QueryBuilder(LiveStreamingModel());
    queryBuilder.whereEqualTo(
        LiveStreamingModel.keyAuthorId, widget.currentUser!.objectId);

    ParseResponse parseResponse = await queryBuilder.count();

    if (parseResponse.success) {
      if (parseResponse.count > 0) {
        isFirstTime = false;
      } else {
        isFirstTime = true;
      }
    }
  }

  void createLiveAudio() async {
    MainHelper.showLoadingDialog(context, isDismissible: false);

    QueryBuilder<LiveStreamingModel> queryBuilder =
    QueryBuilder(LiveStreamingModel());
    queryBuilder.whereEqualTo(
        LiveStreamingModel.keyAuthorId, widget.currentUser!.objectId);
    queryBuilder.whereEqualTo(LiveStreamingModel.keyStreaming, true);

    ParseResponse parseResponse = await queryBuilder.query();
    if (parseResponse.success) {
      if (parseResponse.results != null) {
        LiveStreamingModel live =
        parseResponse.results!.first! as LiveStreamingModel;

        live.setStreaming = false;
        await live.save();

        createLiveFinishAudio();
      } else {
        createLiveFinishAudio();
      }
    } else {
      MainHelper.showErrorResult(context, parseResponse.error!.code);
      MainHelper.hideLoadingDialog(context);
    }
  }

  createLiveFinishAudio() async {
    LiveStreamingModel streamingModel = LiveStreamingModel();
    streamingModel.setStreamingChannel =
        widget.currentUser!.objectId! + widget.currentUser!.getUid!.toString();

    streamingModel.setAuthor = widget.currentUser!;
    streamingModel.setAuthorId = widget.currentUser!.objectId!;
    streamingModel.setAuthorUid = widget.currentUser!.getUid!;
    streamingModel.addAuthorTotalDiamonds =
    widget.currentUser!.getPointsTotal!;
    streamingModel.setFirstLive = isFirstTime;
    streamingModel.setLiveType = LiveStreamingModel.liveAudio;

    if (widget.currentUser!.getAvatar != null) {
      streamingModel.setImage = widget.currentUser!.getAvatar!;
    }

    /*if (widget.currentUser!.getGeoPoint != null) {
      streamingModel.setStreamingGeoPoint = widget.currentUser!.getGeoPoint!;
    }*/

    streamingModel.setPrivate = false;
    streamingModel.setStreaming = false;
    streamingModel.addViewersCount = 0;
    streamingModel.addDiamonds = 0;

    ParseResponse parseResponse = await streamingModel.save();

    if (parseResponse.success) {
      LiveStreamingModel liveStreaming = parseResponse.results!.first!;

      _createAudioLiveChallenge(liveStreaming);

      for (int i = 0; i < 9; i++) {
        AudioChatUsersModel audioChatUsersModel = AudioChatUsersModel();
        audioChatUsersModel.setSeatIndex = i;
        audioChatUsersModel.setLiveStreaming = liveStreaming;
        audioChatUsersModel.setLiveStreamingId = liveStreaming.objectId!;

        if (i == 0) {
          audioChatUsersModel.setJoinedUser = widget.currentUser!;
          audioChatUsersModel.setJoinedUserId = widget.currentUser!.objectId!;
          audioChatUsersModel.setJoinedUserUid = widget.currentUser!.getUid!;
          audioChatUsersModel.setCanUserTalk = true;
        }else if(i > 0){
          audioChatUsersModel.setCanUserTalk = false;
        }
        audioChatUsersModel.setLetTheRoom = false;

        if (i < 8) {
          audioChatUsersModel.save();
        }
        if (i == 8) {
          ParseResponse response = await audioChatUsersModel.save();

          if (response.success) {
            MainHelper.hideLoadingDialog(context);
            MainHelper.goToNavigatorScreen(
              context,
              AudioLivePage(
                channelName: streamingModel.getStreamingChannel!,
                isBroadcaster: true,
                currentUser: widget.currentUser!,
                mLiveStreamingModel: liveStreaming,
                preferences: sharedPreferences,
              ),
            );
          } else {
            MainHelper.hideLoadingDialog(context);
            MainHelper.showErrorResult(context, 100);
          }
        }
      }
    }
  }

  _createAudioLiveChallenge(LiveStreamingModel liveStreaming) async {
    ChallengeModel challenge = ChallengeModel();

    challenge.setAuthor = widget.currentUser!;
    challenge.setAuthorId = widget.currentUser!.objectId!;

    challenge.setMode = ChallengeModel.modeLIVESTREAMING;

    challenge.setLiveStreaming = liveStreaming;
    challenge.setLiveStreamingId = liveStreaming.objectId!;

    await challenge.save();
  }

  void openPayPrivateLiveSheet(LiveStreamingModel live) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showPayPrivateLiveBottomSheet(live);
        });
  }

  Widget _showPayPrivateLiveBottomSheet(LiveStreamingModel live) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.5,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Scaffold(
                    appBar: AppBar(
                      toolbarHeight: 35.0,
                      backgroundColor: kTransparentColor,
                      automaticallyImplyLeading: false,
                      elevation: 0,
                      actions: [
                        IconButton(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(Icons.close)),
                      ],
                    ),
                    backgroundColor: kTransparentColor,
                    body: Column(
                      children: [
                        Center(
                            child: TextWithTap(
                              "live_streaming.private_live".tr(),
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 25,
                              marginBottom: 15,
                            )),
                        Center(
                          child: TextWithTap(
                            "live_streaming.private_live_explain".tr(),
                            color: Colors.white,
                            fontSize: 16,
                            marginLeft: 20,
                            marginRight: 20,
                            marginTop: 20,
                          ),
                        ),
                        Expanded(
                            child: Lottie.network(
                                live.getPrivateGift!.getFile!.url!,
                                width: 150,
                                height: 150,
                                animate: true,
                                repeat: true)),
                        ContainerCorner(
                          color: kTransparentColor,
                          marginTop: 1,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                "assets/svg/ic_coin_with_star.svg",
                                width: 24,
                                height: 24,
                              ),
                              TextWithTap(
                                live.getPrivateGift!.getCoins.toString(),
                                color: Colors.white,
                                fontSize: 18,
                                marginLeft: 5,
                              )
                            ],
                          ),
                        ),
                        ContainerCorner(
                          borderRadius: 10,
                          height: 50,
                          width: 150,
                          color: kPrimaryColor,
                          onTap: () {
                            if (widget.currentUser!.getCredits! >=
                                live.getPrivateGift!.getCoins!) {
                              //_payForPrivateLive(live);
                              //sendGift(live);
                            } else {
                              CoinsFlowPayment(
                                context: context,
                                currentUser: widget.currentUser!,
                                showOnlyCoinsPurchase: true,
                                onCoinsPurchased: (coins) {
                                  if (kDebugMode) {
                                    print(
                                      "onCoinsPurchased: $coins new: ${widget.currentUser!.getCredits}");
                                  }

                                  if (widget.currentUser!.getCredits! >=
                                      live.getPrivateGift!.getCoins!) {
                                    //_payForPrivateLive(live);
                                    //sendGift(live);
                                  }
                                },
                              );
                            }
                          },
                          marginTop: 15,
                          marginBottom: 40,
                          child: Center(
                            child: TextWithTap(
                              "live_streaming.pay_for_live".tr(),
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }
}
