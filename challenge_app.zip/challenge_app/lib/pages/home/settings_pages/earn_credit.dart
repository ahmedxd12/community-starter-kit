// ignore_for_file: must_be_immutable

import 'dart:ui';

import 'package:challenge/configurations/global_config.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../configurations/constants_config.dart';
import '../../../models/UserModel.dart';
import '../../../utilities/helper_classes/main_helper.dart';
import '../../../utilities/main_utilities/colors.dart';
import '../../../widgets/custom_widgets/app_bar.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class EarnCreditPage extends StatefulWidget {
  static String route = "/menu/settings/earnCredit";
  UserModel? currentUser;

  EarnCreditPage({Key? key,this.currentUser}) : super(key: key);

  @override
  State<EarnCreditPage> createState() => _EarnCreditPageState();
}

class _EarnCreditPageState extends State<EarnCreditPage> {
  get size => MediaQuery.of(context).size;

  RewardedAd? _rewardedAd;

  late final AdManagerBannerAd banner;
  late final AdWidget adWidget;

  bool isBannerInit = false;
  bool isRewardedInit = false;
  late SharedPreferences sharedPreferences;

  bool wasRewardAlreadyShown = false;

  _initPreferences() async {
    sharedPreferences = await SharedPreferences.getInstance();
  }

  void loadRewarded() {
    RewardedAd.load(
        adUnitId: Constants.getAdmobRewardedVideoUnit(),
        request: const AdRequest(),
        rewardedAdLoadCallback: RewardedAdLoadCallback(
          // Called when an ad is successfully received.
          onAdLoaded: (ad) {
            ad.fullScreenContentCallback = FullScreenContentCallback(
              // Called when the ad showed the full screen content.
                onAdShowedFullScreenContent: (ad) {},
                // Called when an impression occurs on the ad.
                onAdImpression: (ad) {},
                // Called when the ad failed to show full screen content.
                onAdFailedToShowFullScreenContent: (ad, err) {
                  // Dispose the ad here to free resources.
                  ad.dispose();
                },
                // Called when the ad dismissed full screen content.
                onAdDismissedFullScreenContent: (ad) {
                  // Dispose the ad here to free resources.
                  ad.dispose();
                  wasRewardAlreadyShown = true;
                },
                // Called when a click is recorded for an ad.
                onAdClicked: (ad) {});

            debugPrint('$ad loaded.');
            // Keep a reference to the ad so you can show it later.
            _rewardedAd = ad;
          },
          // Called when an ad request failed.
          onAdFailedToLoad: (LoadAdError error) {
            debugPrint('RewardedAd failed to load: $error');
            MainHelper.showAppNotificationAdvanced(
              context: context,
              title: "error".tr(),
              message: "admob.rewarded_failed".tr()
            );
          },
        ),);

    isRewardedInit = true;
  }

  loadBanner(){
    banner = AdManagerBannerAd(
      adUnitId: Constants.getAdmobBannerUnit(),
      sizes: [AdSize.banner],
      request: const AdManagerAdRequest(),
      listener: AdManagerBannerAdListener(),
    );

    banner.load();
    adWidget = AdWidget(ad: banner);

    isBannerInit = true;
  }

  _showAadAndRewardUser(){
    _rewardedAd?.show(
        onUserEarnedReward: (AdWithoutView ad, RewardItem rewardItem) {
        widget.currentUser!.addCredit = Config.rewardedCredit;
        widget.currentUser?.save();

        MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "admob.reward_earned_title".tr(),
          message: "admob.reward_earned_message".tr(),
          isError: false,
        );
    });
  }

  _rewardedErrorMessage(){
    MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "admob.reward_limit_title".tr(),
        message: "admob.reward_limit_message".tr()
    );
  }

  @override
  void initState() {
    _initPreferences();
    super.initState();
  }

  @override
  dispose() {
    super.dispose();
    banner.dispose();
    _rewardedAd?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if(!isBannerInit){
      loadBanner();
    }

    if(!isRewardedInit){
      loadRewarded();
    }

    return ToolBar(
        extendBodyBehindAppBar: true,
        backgroundColor: kTransparentColor,
        titleChild: TextWithTap(
          "page_title.earn_credit".tr(),
          color:Colors.white,
        ),
        centerTitle: MainHelper.isAndroidPlatform() ? false : true,
        leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            SafeArea(
              child: SingleChildScrollView(child: body()),
            ),
          ],
        ));
  }

  Widget showBanner(var size){
    return Visibility(
      visible: isBannerInit,
      child: ContainerCorner(
        marginTop: size.height * 0.035,
        width: size.width,
        height: size.height * 0.08,
        child: adWidget,
      ),
    );
  }

  Widget body(){
    return Padding(
      padding: EdgeInsets.only(top: size.height * 0.15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextWithTap(
            "credit.earn_credit_title".tr().toUpperCase(),
            fontWeight: FontWeight.w900,
            color: Colors.white,
            fontSize: size.width / 15,
            textAlign: TextAlign.center,
            marginTop: size.width / 15,
            marginBottom: size.width / 10,
          ),
          TextWithTap(
            "credit.earn_credit_message".tr(),
            color: Colors.white,
            fontSize: size.width / 24,
            marginBottom: size.width / 10,
            marginLeft:  size.width / 20,
            marginRight:  size.width / 20,
            textAlign: TextAlign.center,
          ),
          ContainerCorner(
            radiusBottomRight: 20,
            borderWidth: 2,
            imageDecoration: "assets/images/btn_design.png",
            radiusTopLeft: 20,
            marginTop: size.width / 15,
            height: size.width / 7,
            marginLeft: size.width / 15,
            marginRight: size.width / 15,
            width: size.width,
            onTap: () => !wasRewardAlreadyShown
              ? _showAadAndRewardUser()
              : _rewardedErrorMessage(),
            child: Center(
              child: TextWithTap(
                "credit.earn_credit_button".tr().toUpperCase(),
                color: Colors.white,
                fontSize: size.width / 20,
              ),
            ),
          ),
          showBanner(size),
        ],
      ),
    );
  }
}
