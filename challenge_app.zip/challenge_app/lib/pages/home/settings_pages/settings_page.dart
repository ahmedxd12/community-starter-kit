// ignore_for_file: must_be_immutable, use_build_context_synchronously, library_private_types_in_public_api

import 'dart:ui';

import 'package:challenge/configurations/constants_config.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:share_plus/share_plus.dart';
import 'package:challenge/pages/authentication/signin_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/coins_pages/refill_coins_page.dart';
import 'package:challenge/pages/home/settings_pages/blocked_users_page.dart';
import 'package:challenge/pages/home/settings_pages/get_money_page.dart';
import 'package:challenge/pages/home/settings_pages/account_settings_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_edit_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/button_widget.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../configurations/global_config.dart';
import '../../../services/dynamic_link_service.dart';
import '../../../widgets/custom_widgets/button_with_icon.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import 'earn_credit.dart';

class SettingsPage extends StatefulWidget {
  static String route = "/menu/settings";

  UserModel? currentUser;

  SettingsPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  get size => MediaQuery.of(context).size;
  late Uri shareUrl;
  final DynamicLinkService _dynamicLinkService = DynamicLinkService();

  late final AdManagerBannerAd banner;
  late final AdWidget adWidget;

  bool isBannerInit = false;

  loadBanner(){
    banner = AdManagerBannerAd(
      adUnitId: Constants.getAdmobBannerUnit(),
      sizes: [AdSize.banner],
      request: const AdManagerAdRequest(),
      listener: AdManagerBannerAdListener(),
    );

    banner.load();
    adWidget = AdWidget(ad: banner);

    isBannerInit = true;
  }

  createShareLink() async{
    shareUrl = (await _dynamicLinkService.createDynamicLink(widget.currentUser!.objectId!,
        type:'invite'))!;
  }

  @override
  initState(){
    super.initState();
    createShareLink();
  }

  @override
  dispose(){
    super.dispose();
    banner.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    if(!isBannerInit){
      loadBanner();
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: kTransparentColor,
        centerTitle: true,
        automaticallyImplyLeading: false,
        leading: const BackButton(color: Colors.white,),
        title: TextWithTap(
          "page_title.settings_title".tr(),
          color: Colors.white,
          fontSize: 25,
          fontWeight: FontWeight.w700,
        ),
      ),
      body: ContainerCorner(
        borderWidth: 0,
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            SingleChildScrollView(
              child: SafeArea(
                child: Column(
                  children: [
                    ContainerCorner(
                      borderColor: kTransparentColor,
                      borderWidth: 0,
                      borderRadius: 1,
                      marginTop: 0,
                      marginLeft: 5,
                      marginRight: 5,
                      marginBottom: 15,
                      child: Column(
                        children: [
                          settingsOptions("settings_screen.edit_profile".tr(),
                              "assets/images/ic_settings_profile_settings.png",
                              route: ProfileEditPage.route,
                              arguments: widget.currentUser),
                          settingsOptions(
                              "settings_screen.invite_to_app"
                                  .tr(namedArgs: {"app_name": Config.appName}),
                              "assets/images/ic_settings_invite_friends.png",
                              share: true,
                              arguments: widget.currentUser),
                          settingsOptions(
                            "settings_screen.account_settings".tr(),
                            "assets/images/ic_settings_app.png",
                            route: AccountSettingsPage.route,
                            arguments: widget.currentUser,
                          ),
                          profileOptions(
                            "profile_screen.op_blocked_users".tr(),
                            "assets/svg/ic_blocked_menu.svg",
                            BlockedUsersPage(
                              currentUser: widget.currentUser,
                            ),
                          ),
                          coinBalanceOption(
                            "profile_screen.op_refill_coin_balance".tr(),
                            "assets/svg/ic_refill_menu.svg",
                            route: RefillCoinsPage.route,
                          ),
                          ButtonWithIcon(
                            text: "credit.earn_credit_title".tr(),
                            backgroundColor: kButtonTextColor,
                            // backgroundColor: Colors.white.withOpacity(0.02),
                            marginTop: 0,
                            marginBottom: 10,
                            textColor: Colors.white,
                            urlIconColor: Colors.white.withOpacity(0.5),
                            mainAxisAlignment: MainAxisAlignment.start,
                            fontSize: 18,
                            height: 50,
                            onTap: () => MainHelper.goToNavigatorScreen(
                              context, EarnCreditPage(
                                currentUser: widget.currentUser,
                              ),),
                          ),
                          getMoneyOption(
                            "profile_screen.op_get_money".tr(),
                            "assets/svg/ic_redeem_menu.svg",
                            GetMoneyPage(
                              currentUser: widget.currentUser,
                            ),
                          ),
                          ButtonWithIcon(
                            text: "page_title.terms_of_use".tr(),
                            backgroundColor: kButtonTextColor,
                            // backgroundColor: Colors.white.withOpacity(0.02),
                            marginTop: 5,
                            textColor: Colors.white,
                            urlIconColor: Colors.white.withOpacity(0.5),
                            mainAxisAlignment: MainAxisAlignment.start,
                            fontSize: 18,
                            height: 50,
                            onTap: () => MainHelper.goToWebPage(context,
                                pageType: MainHelper.pageTypeTerms),
                          ),
                          ButtonWithIcon(
                            text: "page_title.privacy_policy".tr(),
                            backgroundColor: kButtonTextColor,
                            // backgroundColor: Colors.white.withOpacity(0.02),
                            marginTop: 10,
                            textColor: Colors.white,
                            urlIconColor: Colors.white.withOpacity(0.5),
                            mainAxisAlignment: MainAxisAlignment.start,
                            fontSize: 18,
                            height: 50,
                            onTap: () => MainHelper.goToWebPage(context,
                                pageType: MainHelper.pageTypePrivacy),
                          ),
                          ButtonWithIcon(
                            text: 'logout'.tr(),
                            backgroundColor: kButtonTextColor,
                            // backgroundColor: Colors.white.withOpacity(0.02),
                            marginTop: 10,
                            textColor: Colors.white,
                            urlIconColor: Colors.white.withOpacity(0.5),
                            mainAxisAlignment: MainAxisAlignment.start,
                            fontSize: 18,
                            height: 50,
                            onTap: () => showAlert(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            /*Positioned(
              bottom: 2,
              child: ContainerCorner(
                width: size.width,
                height: size.height * 0.08,
                child: adWidget,
              ),
            ),*/
          ],
        ),
      ),
    );
  }

  Widget getDivider() {
    return Divider(
      color: MainHelper.isDarkMode(context) ? kGreyColor2 : kColorsGrey300,
      height: 1,
      thickness: 1,
    );
  }

  Widget settingsOptions(String text, String iconUrl,
      {String? route, Object? arguments, bool? share = false}) {
    return ButtonWithIcon(
      text: text,
      backgroundColor: kButtonTextColor,
      // backgroundColor: Colors.white.withOpacity(0.02),
      marginTop: 10,
      textColor: Colors.white,
      urlIconColor: Colors.white.withOpacity(0.5),
      mainAxisAlignment: MainAxisAlignment.start,
      fontSize: 17,
      height: 50,
      onTap: () => route == ProfileEditPage.route
          ? MainHelper.goToNavigatorScreen(
          context,
          ProfileEditPage(
            currentUser: widget.currentUser,
          ),)
          : share == true
          ? Share.share("settings_screen.share_app_url".tr(namedArgs: {
        "app_name": Config.appName,
        "url": shareUrl.toString(),
      }))
          : MainHelper.goToNavigator(context, route!, arguments: arguments),
    );
  }

  showAlert() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  "logout_question".tr(),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w600,
                    color:Colors.white,
                  ),
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    ContainerCorner(
                      height: 50,
                      width: size.width * 0.3,
                      borderRadius: 10,
                      color: kButtonTextColor,
                      onTap: () { Navigator.of(context).pop(); },
                      child: Center(
                        child: TextWithTap(
                          "cancel".tr(),
                          color: Colors.white,
                        ),
                      ),
                    ),
                    ContainerCorner(
                      height: 50,
                      width: size.width * 0.3,
                      borderRadius: 10,
                      color: kPrimaryColor,
                      onTap: () => doUserLogout(widget.currentUser),
                      child: Center(
                        child: TextWithTap(
                          "logout".tr(),
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  void doUserLogout(UserModel? userModel) async {
    MainHelper.showLoadingDialog(context);

    userModel!.unset("installation");
    await userModel.save();

    ParseResponse response = await userModel.logout(deleteLocalUserData: true);
    if (response.success) {
      MainHelper.initInstallation(null, null);
      MainHelper.hideLoadingDialog(context);

      MainHelper.goToNavigatorScreen(
        context,
        const SignInPage(),
        finish: true,
        back: false,
      );
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotification(
          context: context, title: response.error!.message);
    }
  }

  Widget profileOptions(String text, String svgIconURL, Widget widgetNav) {
    return ButtonWithIcon(
      text: text,
      borderWidth: 0,
      backgroundColor: kButtonTextColor,
      // backgroundColor: Colors.white.withOpacity(0.02),
      height: 50,
      marginTop: 10,
      marginBottom: 10,
      fontSize: 18,
      iconSize: 30,
      textColor: Colors.white,
      urlIconColor: Colors.white.withOpacity(0.5),
      mainAxisAlignment: MainAxisAlignment.start,
      onTap: () => MainHelper.goToNavigatorScreen(context, widgetNav),
    );
  }

  Widget coinBalanceOption(String text, String svgIconURL, {String? route}) {
    return ButtonWidget(
      height: 50,
      borderWidth: 0,
      marginBottom: 10,
      color: kButtonTextColor,
      padding: const EdgeInsets.only(top: 10, bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ContainerCorner(
            color: kTransparentColor,
            child: Row(
              children: [
                TextWithTap(
                  text,
                  marginLeft: 16,
                  fontSize: 17,
                  color: Colors.white,
                ),
              ],
            ),
          ),
        ],
      ),
      onTap: () => route == RefillCoinsPage.route
          ? MainHelper.goToNavigatorScreen(
          context,
          RefillCoinsPage(
            currentUser: widget.currentUser,
          ))
          : MainHelper.goToNavigator(context, route!),
    );
  }

  Widget getMoneyOption(String text, String svgIconURL, Widget widgetNav) {
    return ButtonWidget(
        color: kButtonTextColor,
        // color: Colors.white.withOpacity(0.02),
        marginBottom: 5,
        borderWidth: 0,
        padding: const EdgeInsets.only(top: 10, bottom: 5),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ContainerCorner(
              color: kTransparentColor,
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWithTap(
                        text,
                        marginLeft: 16,
                        fontSize: 15,
                        color: Colors.white,
                        //color: Colors.black,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
        onTap: () async {
          UserModel? user = await MainHelper.goToNavigatorScreenForResult(
              context, widgetNav,
              route: GetMoneyPage.route);

          if (user != null) {
            widget.currentUser = user;
          }
        });
  }
}