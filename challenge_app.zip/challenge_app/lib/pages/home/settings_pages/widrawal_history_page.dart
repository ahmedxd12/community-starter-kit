 // ignore_for_file: must_be_immutable, use_build_context_synchronously, library_private_types_in_public_api

import 'dart:ui';

import 'package:fade_shimmer/fade_shimmer.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../../../models/WithdrawModel.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class WithdrawHistoryPage extends StatefulWidget {
  static const String route = '/users/withdrawal';

  UserModel? currentUser;

  WithdrawHistoryPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _WithdrawHistoryPageState createState() => _WithdrawHistoryPageState();
}

class _WithdrawHistoryPageState extends State<WithdrawHistoryPage> {
  get size => MediaQuery.of(context).size;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //MainHelper.setWebPageTitle(context, "page_title.blocked_users_title".tr());

    return ToolBar(
        extendBodyBehindAppBar: true,
        backgroundColor: kTransparentColor,
        titleChild: TextWithTap(
          "page_title.withdraw_title".tr(),
          color:Colors.white,
        ),
        centerTitle: MainHelper.isAndroidPlatform() ? false : true,
        leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            SafeArea(
              child: SingleChildScrollView(child: withdrawals()),
            ),
          ],
        ));
  }

  Widget withdrawals(){
    QueryBuilder<WithdrawModel> query =
    QueryBuilder<WithdrawModel>(WithdrawModel());

    query.whereEqualTo(WithdrawModel.keyAuthor, widget.currentUser);
    query.orderByDescending(WithdrawModel.keyCreatedAt);

    query.includeObject([
      WithdrawModel.keyAuthor,
    ]);
    
    return ParseLiveListWidget<WithdrawModel>(
      query: query,
      reverse: false,
      /*crossAxisSpacing: 10,
      mainAxisSpacing: 10,*/
      scrollPhysics: const NeverScrollableScrollPhysics(),
      lazyLoading: false,
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<WithdrawModel> snapshot) {
        if (snapshot.failed) {
          return emptyHistory();
        } else if (snapshot.hasData) {
          WithdrawModel withdraw = snapshot.loadedData!;
          return Center(child: withdrawCard(withdraw));
        } else {
          return showShimmer();
        }
      },
      queryEmptyElement:emptyHistory(),
      listLoadingElement: showShimmer(),
    );
  }

  Widget withdrawCard(WithdrawModel withdraw){
    return ContainerCorner(
      color: kButtonTextColor,
      borderRadius: 5,
      width: size.width * 0.95,
      marginTop: 10,
      marginBottom: 10,
      child: Padding(
        padding: const EdgeInsets.all(5.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextWithTap(
                    '\$${withdraw.getAmountString!}',
                    color:Colors.white,
                    fontSize: 22,
                  ),
                  TextWithTap(
                    DateFormat.yMMMMd().format(withdraw.createdAt!),
                    color:Colors.white,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(bottom:10.0,left: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  getLogo(withdraw.getMethod!),
                  ContainerCorner(
                    // color: getStatusColors(withdraw.getStatus!),
                    borderRadius: 5,
                    marginRight: 8,
                    child: TextWithTap(
                      withdraw.getStatus!,
                      color: getStatusColors(withdraw.getStatus!),
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget getLogo(String type){
    switch(type){
      case WithdrawModel.payoneer:
        return SvgPicture.asset(
          "assets/svg/Payoneer-Logo.wine.svg",
          height: 40,
          color:Colors.white,
        );

      case WithdrawModel.paypal:
        return ContainerCorner(
          marginBottom: 5,
          marginTop: 5,
          child: SvgPicture.asset(
            "assets/svg/paypal-seeklogo.com.svg",
            height: 20,
            color: Colors.white,
          ),
        );

      default:
        return TextWithTap(
          "get_money.bank_account_title"
              .tr()
              .toUpperCase(),
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 17,
          marginBottom: 5,
          marginTop: 5,
        );
    }
  }

  MaterialAccentColor getStatusColors(String status) {
    if(status == WithdrawModel.complete){
      return Colors.greenAccent;
    }else if(status == WithdrawModel.pending){
      return Colors.yellowAccent;
    }else {
      return Colors.lightBlueAccent;
    }
  }

  Widget showShimmer(){
    return ListView.builder(
      itemCount: 20,
      shrinkWrap: true,
      itemBuilder: (context, index) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: FadeShimmer(
            height:size.height * 0.15,
            width: size.width * 0.9,
            radius: 4,
            highlightColor: const Color(0xff000000).withOpacity(0.4),
            baseColor: const Color(0xff000000).withOpacity(0.3),
          ),
        );
      },
    );
  }

  Widget emptyHistory() {
    return ContainerCorner(
      width: size.width,
      height: size.height * 0.7,
      child: Center(
        child: TextWithTap(
          'withdraw_page.no_withdraw'.tr(),
          fontSize: size.width / 22,
          textAlign: TextAlign.center,
          marginTop: size.height * 0.17,
          color:Colors.white,
        ),
      ),
    );
  }

  showUnblockUserAlert(UserModel user){
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      top: 15.0, bottom: 10.0),
                  child: ContainerCorner(
                    width: 130,
                    height: 130,
                    child: ActionsHelper.polygonAvatarWidget(
                      currentUser: user, fontSize: 20
                    ),
                  ),
                ),
                TextWithTap(
                  user.getFullName!,
                  textAlign: TextAlign.center,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                TextWithTap(
                  "feed.unlock_user_confirm".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kRedColor1,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kGreenColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "confirm_"
                              .tr()
                              .toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {  },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }
}