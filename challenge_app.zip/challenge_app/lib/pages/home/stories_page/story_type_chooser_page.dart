// ignore_for_file: use_build_context_synchronously

import 'dart:ui';
import 'package:camera/camera.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/stories_page/create_photo_story_page.dart';
import 'package:challenge/pages/home/stories_page/create_text_story_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../configurations/global_setup.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class StoryTypeChooserPage extends StatefulWidget {
  final UserModel? currentUser;

  const StoryTypeChooserPage({Key? key, this.currentUser}) : super(key: key);
  static String route = "/home/choose_story_type";

  @override
  State<StoryTypeChooserPage> createState() => _StoryTypeChooserPageState();
}

class _StoryTypeChooserPageState extends State<StoryTypeChooserPage> {
  List<CameraDescription>? cameras; //list out the camera available
  CameraController? controller;

  loadCamera() async {
    cameras = await availableCameras();
    if (cameras != null) {
      controller = CameraController(cameras![0], ResolutionPreset.max);
      //cameras[0] = first camera, change to 1 to another camera

      controller!.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {});
      });
    }
  } //controller for camera

  @override
  void initState() {
    loadCamera();

    super.initState();
  }

  checkPermission() async {
    if (MainHelper.isMobile()) {
      if (await Permission.camera.isGranted) {
        //Choose picture
        MainHelper.goToNavigatorScreen(
            context,
            CreatePhotoStory(
              controller: controller,
              currentUser: widget.currentUser,
            ));
      } else if (await Permission.camera.isDenied) {
        MainHelper.showDialogPermission(
            context: context,
            title: "permissions.photo_access".tr(),
            confirmButtonText: "permissions.okay_".tr().toUpperCase(),
            message: "permissions.photo_access_explain"
                .tr(namedArgs: {"app_name": Setup.appName}),
            onPressed: () async {
              MainHelper.hideLoadingDialog(context);

              // You can request multiple permissions at once.
              Map<Permission, PermissionStatus> statuses =
                  await [Permission.camera].request();

              if (statuses[Permission.camera]!.isGranted) {
                //Choose picture
                MainHelper.goToNavigatorScreen(
                    context,
                    CreatePhotoStory(
                      controller: controller,
                      currentUser: widget.currentUser,
                    ));
              } else {
                MainHelper.showAppNotificationAdvanced(
                    title: "permissions.photo_access_denied".tr(),
                    message: "permissions.photo_access_denied_explain"
                        .tr(namedArgs: {"app_name": Setup.appName}),
                    context: context,
                    isError: true);
              }
            });
      } else if (await Permission.camera.isPermanentlyDenied) {
        openAppSettings();
      }
    } else {
      //Choose picture
      MainHelper.goToNavigatorScreen(
          context,
          CreatePhotoStory(
            controller: controller,
            currentUser: widget.currentUser,
          ));
    }
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: kTransparentColor,
          centerTitle: true,
          automaticallyImplyLeading: false,
          leading: const BackButton(
            color: Colors.white,
          ),
          title: TextWithTap(
            "stories.story_type".tr(),
            color: Colors.white,
            fontSize: size.width / 17,
            fontWeight: FontWeight.w700,
          ),
        ),
        body: ContainerCorner(
          borderWidth: 0,
          height: size.height,
          width: size.width,
          child: Stack(
            alignment: AlignmentDirectional.center,
            children: [
              ContainerCorner(
                height: size.height,
                width: size.width,
                borderWidth: 0,
                imageDecoration: "assets/images/app_bg.png",
              ),
              ClipRRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                  child: SizedBox(
                    height: size.height,
                    width: size.width,
                  ),
                ),
              ),
              ContainerCorner(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ContainerCorner(
                      radiusBottomRight: 20,
                      borderWidth: 2,
                      imageDecoration: "assets/images/btn_design.png",
                      radiusTopLeft: 20,
                      marginTop: size.width / 15,
                      height: size.width / 7,
                      marginLeft: size.width / 15,
                      marginRight: size.width / 15,
                      width: size.width,
                      onTap: () => checkPermission(),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.camera_alt,
                              color: Colors.white,
                              size: size.width / 14,
                            ),
                            TextWithTap(
                              "stories.type_camera".tr(),
                              color: Colors.white,
                              // marginTop: size.width / 50,
                              fontSize: 18,
                              marginLeft: 6,
                            )
                          ],
                        ),
                      ),
                    ),
                    ContainerCorner(
                      radiusBottomRight: 20,
                      borderWidth: 2,
                      imageDecoration: "assets/images/btn_design.png",
                      radiusTopLeft: 20,
                      marginTop: size.width / 15,
                      height: size.width / 7,
                      marginLeft: size.width / 15,
                      marginRight: size.width / 15,
                      width: size.width,
                      onTap: () => MainHelper.goToNavigatorScreen(
                          context,
                          CreateTextStoryPage(
                            currentUser: widget.currentUser,
                          )),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TextWithTap(
                              "stories.a_".tr(),
                              color: Colors.white,
                              fontSize: size.width / 18,
                              fontWeight: FontWeight.w700,
                              marginRight: 6,
                            ),
                            TextWithTap(
                              "stories.type_text".tr(),
                              color: Colors.white,
                              // marginTop: size.width / 50,
                              fontSize: 18,
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }

}
