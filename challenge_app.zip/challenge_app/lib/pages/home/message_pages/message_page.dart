// ignore_for_file: must_be_immutable, invalid_use_of_protected_member, use_build_context_synchronously
import 'dart:ui';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:camera/camera.dart';
import 'package:challenge/pages/home/message_pages/send_picture_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/CallsModel.dart';
import 'package:challenge/models/MessageListModel.dart';
import 'package:challenge/models/MessageModel.dart';
import 'package:challenge/models/StoriesModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/utilities/main_utilities/utilsConstants.dart';
import 'package:sticky_grouped_list/sticky_grouped_list.dart';

import '../../../configurations/global_setup.dart';
import '../../../models/GiftsModel.dart';
import '../../../utilities/helper_classes/cloud_helper.dart';
import '../../../utilities/helper_classes/notifications_helper.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../stories_page/see_one_story_page.dart';

class MessagePage extends StatefulWidget {
  UserModel? currentUser, mUser;

  MessagePage({Key? key, this.currentUser, this.mUser}) : super(key: key);

  static String route = '/messages/chat';

  @override
  State<MessagePage> createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage> {
  get size => MediaQuery.of(context).size;

  TextEditingController messageController = TextEditingController();

  String? sendButtonIcon = "assets/svg/ic_menu_gifters.svg";
  Color sendButtonBackground = Colors.deepOrangeAccent;

  GroupedItemScrollController listScrollController =
      GroupedItemScrollController();

  List<CameraDescription>? cameras; //list out the camera available
  CameraController? controller;

  switchCameraMethod(int? index){
    if(cameras != null){
      if(cameras!.length != 1){
        controller?.pausePreview();
        controller = CameraController(cameras![index!], ResolutionPreset.max);

        controller!.initialize().then((_) {
          if (!mounted) {
            return;
          }

          setState(() {});
        });
      }
    }
  }

  loadCamera() async {
    cameras = await availableCameras();
    if (cameras != null) {
      controller = CameraController(cameras![0], ResolutionPreset.max);
      //cameras[0] = first camera, change to 1 to another camera

      controller!.initialize().then((_) {
        if (!mounted) {
          return;
        }

        setState(() {});
      });
    }
  } //controller for camera

  int currentView = 0;
  List<Widget>? pages;

  //Live query stuff
  late QueryBuilder<MessageModel> queryBuilder;
  final LiveQuery liveQuery = LiveQuery();
  Subscription? subscription;
  List<dynamic> results = <dynamic>[];

  void openPicture(ParseFileBase picture) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showMessagePictureBottomSheet(picture);
        });
  }

  void changeButtonIcon(String text) {
    setState(() {
      /*if (text.isNotEmpty) {
        sendButtonIcon = "assets/svg/ic_send_message.svg";
        sendButtonBackground = kPrimaryColor;
      } else {
        sendButtonIcon = "assets/svg/ic_menu_gifters.svg";
        sendButtonBackground = Colors.deepOrangeAccent;
      }*/
    });
  }

  @override
  void dispose() {
    messageController.dispose();

    if (subscription != null) {
      liveQuery.client.unSubscribe(subscription!);
    }

    super.dispose();
  }

  @override
  void initState() {
    loadCamera();
    super.initState();
  }

  scrollToBottom(
      {required int position,
      bool? animated = false,
      int? duration = 3,
      Curve? curve = Curves.easeOut}) {
    if (listScrollController.isAttached) {
      if (animated = true) {
        listScrollController.scrollTo(
            index: position,
            duration: Duration(seconds: duration!),
            curve: curve!);
      } else {
        listScrollController.jumpTo(index: position, automaticAlignment: false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode focusScopeNode = FocusScope.of(context);
        if (!focusScopeNode.hasPrimaryFocus &&
            focusScopeNode.focusedChild != null) {
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: kTransparentColor,
          title: Row(
            children: [
              ContainerCorner(
                width: 50,
                height: 50,
                child: ActionsHelper.polygonAvatarWidget(
                    currentUser:widget.mUser!),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWithTap(
                    widget.mUser!.getFirstName!,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    marginLeft: 10,
                    marginRight: 10,
                  ),
                  TextWithTap(
                    MainHelper.isUserOnlineChat(widget.mUser!),
                    color: MainHelper.isUserOnline(widget.mUser!)
                        ? Colors.green
                        : kGrayColor,
                    marginLeft: 10,
                    fontSize: 12,
                  )
                ],
              ),
            ],
          ),
        ),
        body: _messageSpace(context),
      ),
    );
  }

  checkPermission() async {
    if (await Permission.camera.isGranted) {
      _goToSendPicturePage(controller!);
    } else if (await Permission.camera.isDenied) {
      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.camera_access_title".tr(),
          confirmButtonText: "permissions.okay_".tr().toUpperCase(),
          message: "permissions.camera_access_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () async {
            MainHelper.hideLoadingDialog(context);

            // You can request multiple permissions at once.
            Map<Permission, PermissionStatus> statuses = await [
              Permission.camera].request();

            if (statuses[Permission.camera]!.isGranted) {
              _goToSendPicturePage(controller!);
            } else {
              MainHelper.showAppNotificationAdvanced(
                  title: "permissions.Access camera Denied".tr(),
                  message: "permissions.camera_access_denied_explain"
                      .tr(namedArgs: {"app_name": Setup.appName}),
                  context: context,
                  isError: true);

              MainHelper.goToNavigatorScreen(
                context,
                SendPicturePage(
                  currentUser: widget.currentUser,
                  mUser: widget.mUser,
                ),
              );
            }
          });
    }else{
      MainHelper.goToNavigatorScreen(
        context,
        SendPicturePage(
          currentUser: widget.currentUser,
          mUser: widget.mUser,
        ),
      );
    }
  }

  _goToSendPicturePage(CameraController controller){
    MainHelper.goToNavigatorScreen(
      context,
      SendPicturePage(
        currentUser: widget.currentUser,
        mUser: widget.mUser,
        controller: controller,
      ),
    );
  }

  _updateMessageList(MessageListModel messageListModel) async {
    messageListModel.setIsRead = true;
    messageListModel.setCounter = 0;
    await messageListModel.save();
  }

  _updateMessageStatus(MessageModel messageModel) async {
    messageModel.setIsRead = true;
    await messageModel.save();
  }

  Future<void> _objectUpdated(MessageModel object) async {
    for (int i = 0; i < results.length; i++) {
      if (results[i].get<String>(keyVarObjectId) ==
          object.get<String>(keyVarObjectId)) {
        if (UtilsConstant.after(results[i], object) == null) {
          setState(() {
            results[i] = object.clone(object.toJson(full: true));
          });
        }
        break;
      }
    }
  }

  setupLiveQuery() async {
    subscription =
        subscription ?? await liveQuery.client.subscribe(queryBuilder);

    subscription!.on(LiveQueryEvent.create, (MessageModel message) {
      if (message.getAuthorId == widget.mUser!.objectId) {
        setState(() {
          results.add(message);
        });
      } else {
        setState(() {});
      }
    });

    subscription!.on(LiveQueryEvent.update, (MessageModel message) {
      _objectUpdated(message);
    });
  }

  Future<List<dynamic>?> _loadMessages() async {
    QueryBuilder<MessageModel> queryFrom =
        QueryBuilder<MessageModel>(MessageModel());

    queryFrom.whereEqualTo(MessageModel.keyAuthor, widget.currentUser!);

    queryFrom.whereEqualTo(MessageModel.keyReceiver, widget.mUser!);

    QueryBuilder<MessageModel> queryTo =
        QueryBuilder<MessageModel>(MessageModel());
    queryTo.whereEqualTo(MessageModel.keyAuthor, widget.mUser!);
    queryTo.whereEqualTo(MessageModel.keyReceiver, widget.currentUser!);

    queryBuilder = QueryBuilder.or(MessageModel(), [queryFrom, queryTo]);
    queryBuilder.orderByDescending(MessageModel.keyCreatedAt);

    setupLiveQuery();

    queryBuilder.includeObject([
      MessageModel.keyCall,
      MessageModel.keyAuthor,
      MessageModel.keyReceiver,
      MessageModel.keyListMessage,
      MessageModel.keyStoryReplied
    ]);

    ParseResponse apiResponse = await queryBuilder.query();
    if (apiResponse.success) {
      if (apiResponse.results != null) {
        return apiResponse.results;
      } else {
        return const AsyncSnapshot.nothing() as dynamic;
      }
    } else {
      return apiResponse.error as dynamic;
    }
  }

  Widget _messageSpace(BuildContext showContext) {
    return Stack(children: [
      ContainerCorner(
        borderWidth: 0,
        color: kTransparentColor,
        width: size.width,
        height: size.height,
        imageDecoration: "assets/images/app_bg.png",
      ),
      ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
          child: ContainerCorner(
            width: size.width,
            height: size.height,
          ),
        ),
      ),
      SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: FutureBuilder<List<dynamic>?>(
                    future: _loadMessages(), //_future, //loadUser(),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.hasData) {
                        results = snapshot.data as List<dynamic>;
                        var reversedList = results.reversed.toList();

                        return StickyGroupedListView<dynamic, DateTime>(
                          elements: reversedList,
                          reverse: true,
                          order: StickyGroupedListOrder.DESC,
                          // Check first
                          groupBy: (dynamic message) {
                            if (message.createdAt != null) {
                              return DateTime(
                                  message.createdAt!.year,
                                  message.createdAt!.month,
                                  message.createdAt!.day);
                            } else {
                              return DateTime(DateTime.now().year,
                                  DateTime.now().month, DateTime.now().day);
                            }
                          },
                          floatingHeader: true,
                          groupComparator: (DateTime value1, DateTime value2) {
                            return value1.compareTo(value2);
                          },
                          itemComparator: (dynamic element1, dynamic element2) {
                            if (element1.createdAt != null &&
                                element2.createdAt != null) {
                              return element1.createdAt!
                                  .compareTo(element2.createdAt!);
                            } else if (element1.createdAt == null &&
                                element2.createdAt != null) {
                              return DateTime.now()
                                  .compareTo(element2.createdAt!);
                            } else if (element1.createdAt != null &&
                                element2.createdAt == null) {
                              return element1.createdAt!
                                  .compareTo(DateTime.now());
                            } else {
                              return DateTime.now().compareTo(DateTime.now());
                            }
                          },
                          groupSeparatorBuilder: (dynamic element) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 0, top: 3),
                              child: TextWithTap(
                                MainHelper.getMessageTime(
                                    element.createdAt != null
                                        ? element.createdAt!
                                        : DateTime.now()),
                                textAlign: TextAlign.center,
                                color: kGreyColor1,
                                fontSize: 12,
                              ),
                            );
                          },
                          itemBuilder: (context, dynamic chatMessage) {
                            bool isMe = chatMessage.getAuthorId! ==
                                    widget.currentUser!.objectId!
                                ? true
                                : false;
                            if (!isMe && !chatMessage.isRead!) {
                              _updateMessageStatus(chatMessage);
                            }

                            if (chatMessage.getMessageList != null &&
                                chatMessage.getMessageList!.getAuthorId ==
                                    widget.mUser!.objectId) {
                              MessageListModel chatList = chatMessage
                                  .getMessageList as MessageListModel;

                              if (!chatList.isRead! &&
                                  chatList.objectId ==
                                      chatMessage.getMessageListId) {
                                _updateMessageList(chatMessage.getMessageList!);
                              }
                            }

                            return Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: Container(
                                padding: const EdgeInsets.only(top: 20),
                                child: isMe
                                    ? Align(
                                        alignment: Alignment.centerRight,
                                        child: Column(
                                          children: [
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageStoryReply)
                                              storyMessage(
                                                  chatMessage.getStoryReplied!,
                                                  chatMessage.isRead ?? false,
                                                  true,
                                                  chatMessage.getMessageText!,
                                                  chatMessage.getReceiver),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypeCall)
                                              ContainerCorner(
                                                radiusBottomLeft: 10,
                                                radiusTopLeft: 10,
                                                radiusTopRight: 10,
                                                marginTop: 10,
                                                marginBottom: 10,
                                                color: kPrimaryColor,
                                                child: callMessage(
                                                    chatMessage, true),
                                              ),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypeText)
                                              ContainerCorner(
                                                radiusBottomLeft: 10,
                                                radiusTopLeft: 10,
                                                radiusTopRight: 10,
                                                radiusBottomRight: 10,
                                                color: kPrimaryColor,
                                                /*colors: const [
                                                kPrimaryColor,
                                                kSecondaryColor
                                              ],*/
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  children: [
                                                    TextWithTap(
                                                      chatMessage
                                                          .getMessageText!,
                                                      marginBottom: 5,
                                                      marginTop: 10,
                                                      color: Colors.white,
                                                      marginLeft: 10,
                                                      marginRight: 10,
                                                      fontSize: 14,
                                                    ),
                                                    Row(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.end,
                                                      children: [
                                                        TextWithTap(
                                                          chatMessage.createdAt !=
                                                                  null
                                                              ? MainHelper
                                                                  .getMessageTime(
                                                                      chatMessage
                                                                          .createdAt!,
                                                                      time:
                                                                          true)
                                                              : "sending_".tr(),
                                                          color: Colors.white
                                                              .withOpacity(0.8),
                                                          fontSize: 12,
                                                          marginRight: 10,
                                                          marginLeft: 10,
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  right: 3),
                                                          child: Icon(
                                                            chatMessage.createdAt !=
                                                                    null
                                                                ? Icons.done_all
                                                                : Icons
                                                                    .access_time_outlined,
                                                            color: chatMessage
                                                                    .isRead!
                                                                ? kBlueColor1
                                                                : Colors.white,
                                                            size: 15,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypeGif)
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  gifMessage(chatMessage
                                                      .getGifMessage),
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      TextWithTap(
                                                        chatMessage.createdAt !=
                                                                null
                                                            ? MainHelper
                                                                .getMessageTime(
                                                                    chatMessage
                                                                        .createdAt!,
                                                                    time: true)
                                                            : "sending_".tr(),
                                                        color: kGrayColor,
                                                        fontSize: 12,
                                                        marginRight: 10,
                                                        marginLeft: 10,
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 10),
                                                        child: Icon(
                                                          chatMessage.createdAt !=
                                                                  null
                                                              ? Icons.done_all
                                                              : Icons
                                                                  .access_time_outlined,
                                                          color: chatMessage
                                                                  .isRead!
                                                              ? kBlueColor1
                                                              : kGrayColor,
                                                          size: 15,
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypePicture)
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  pictureMessage(chatMessage
                                                      .getPictureMessage),
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.end,
                                                    children: [
                                                      TextWithTap(
                                                        chatMessage.createdAt !=
                                                                null
                                                            ? MainHelper
                                                                .getMessageTime(
                                                                    chatMessage
                                                                        .createdAt!,
                                                                    time: true)
                                                            : "sending_".tr(),
                                                        color: kGrayColor,
                                                        fontSize: 12,
                                                        marginRight: 10,
                                                        marginLeft: 10,
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                right: 10),
                                                        child: Icon(
                                                          chatMessage.createdAt !=
                                                                  null
                                                              ? Icons.done_all
                                                              : Icons
                                                                  .access_time_outlined,
                                                          color: chatMessage
                                                                  .isRead!
                                                              ? kBlueColor1
                                                              : kGrayColor,
                                                          size: 15,
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                ],
                                              ),
                                          ],
                                        ),
                                      )
                                    : Align(
                                        alignment: Alignment.centerLeft,
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageStoryReply)
                                              storyMessage(
                                                  chatMessage.getStoryReplied!,
                                                  chatMessage.isRead ?? false,
                                                  false,
                                                  chatMessage.getMessageText!,
                                                  chatMessage.getReceiver),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypeCall)
                                              ContainerCorner(
                                                radiusTopLeft: 10,
                                                radiusTopRight: 10,
                                                radiusBottomRight: 10,
                                                marginTop: 10,
                                                marginBottom: 10,
                                                color: kPrimaryColor,
                                                child: callMessage(
                                                    chatMessage, false),
                                              ),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypeText)
                                              ContainerCorner(
                                                child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    ContainerCorner(
                                                      width: 25,
                                                      height: 25,
                                                      child: ActionsHelper
                                                          .polygonAvatarWidget(
                                                        currentUser:widget.mUser!,
                                                        fontSize: 5,
                                                      ),
                                                    ),
                                                    Flexible(
                                                      child: GestureDetector(
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            ContainerCorner(
                                                              radiusTopLeft: 10,
                                                              radiusTopRight:
                                                                  10,
                                                              radiusBottomRight:
                                                                  10,
                                                              radiusBottomLeft:
                                                                  10,
                                                              marginRight: 10,
                                                              marginLeft: 5,
                                                                 
                                                              color:
                                                                  kButtonTextColor,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  TextWithTap(
                                                                    chatMessage
                                                                        .getMessageText!,
                                                                    marginBottom:
                                                                        10,
                                                                    marginTop:
                                                                        10,
                                                                    color: Colors
                                                                        .white,
                                                                    marginLeft:
                                                                        10,
                                                                    marginRight:
                                                                        10,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                  Row(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .end,
                                                                    children: [
                                                                      TextWithTap(
                                                                        chatMessage.createdAt !=
                                                                                null
                                                                            ? MainHelper.getMessageTime(chatMessage.createdAt!,
                                                                                time: true)
                                                                            : "sending_".tr(),
                                                                        color:
                                                                            kGrayColor,
                                                                        fontSize:
                                                                            12,
                                                                        marginRight:
                                                                            10,
                                                                        marginLeft:
                                                                            10,
                                                                        marginBottom:
                                                                            5,
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypeGif)
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  ActionsHelper.avatarWidget(
                                                      widget.mUser!,
                                                      width: 25,
                                                      height: 25),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      gifMessage(chatMessage
                                                          .getGifMessage),
                                                      TextWithTap(
                                                        chatMessage.createdAt !=
                                                                null
                                                            ? MainHelper
                                                                .getMessageTime(
                                                                    chatMessage
                                                                        .createdAt!,
                                                                    time: true)
                                                            : "sending_".tr(),
                                                        color: kGrayColor,
                                                        fontSize: 12,
                                                        marginRight: 10,
                                                        marginLeft: 10,
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            if (chatMessage.getMessageType ==
                                                MessageModel.messageTypePicture)
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  ContainerCorner(
                                                    width: 25,
                                                    height: 25,
                                                    child: ActionsHelper
                                                        .polygonAvatarWidget(
                                                      currentUser:widget.mUser!,
                                                      fontSize: 5,
                                                    ),
                                                  ),
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      pictureMessage(chatMessage
                                                          .getPictureMessage),
                                                      Row(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .end,
                                                        children: [
                                                          TextWithTap(
                                                            chatMessage.createdAt !=
                                                                    null
                                                                ? MainHelper.getMessageTime(
                                                                    chatMessage
                                                                        .createdAt!,
                                                                    time: true)
                                                                : "sending_"
                                                                    .tr(),
                                                            color: kGrayColor,
                                                            fontSize: 12,
                                                            marginRight: 10,
                                                            marginLeft: 10,
                                                          ),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                ],
                                              ),
                                          ],
                                        ),
                                      ),
                              ),
                            );
                          },
                          // optional
                          itemScrollController: listScrollController,
                        );
                      } else if (snapshot.hasError) {
                        return noMessages();
                      } else {
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      }
                    }),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: chatInputField(),
            ),
          ],
        ),
      )
    ]);
  }

  Widget noMessages() {
    return Center(
      child: TextWithTap(
        'message_screen.no_message_title'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        marginTop: size.height * 0.17,
        color: Colors.white,
      ),
    ); 
  }

  Widget chatInputField() {
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: 20,
        horizontal: 20 / 2,
      ),
      decoration: const BoxDecoration(
        color: kTransparentColor,
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(
              Icons.photo,
              color: kPrimaryColor,
              size: 35,
            ),
            onPressed: () {
              checkPermission();
            },
          ),
          const SizedBox(
            width: 5,
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 20 * 0.75,
              ),
              decoration: BoxDecoration(
                color: kPrimaryColor.withOpacity(0.2),
                borderRadius: BorderRadius.circular(40),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      autocorrect: false,
                      keyboardType: TextInputType.multiline,
                      maxLines: null,
                      controller: messageController,
                      onChanged: (text) {
                        setState(() {
                          changeButtonIcon(text);
                        });
                      },
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: "message_screen.type_message".tr(),
                        border: InputBorder.none,
                        hintStyle: const TextStyle(
                          color: Colors.white,
                        ),
                      ), 
                    ),
                  ),
                ],
              ),
            ),
          ),
          ContainerCorner(
            marginLeft: 10,
            color: kPrimaryColor,
            // colors: const [Colors.deepOrangeAccent, kPrimaryColor],
            borderRadius: 50,
            height: 45,
            width: 45,
            onTap: () {
              _saveMessage(messageController.text,
                  messageType: MessageModel.messageTypeText);
              messageController.text = "";
              /*if (messageController.text.isNotEmpty) {
                _saveMessage(messageController.text,
                    messageType: MessageModel.messageTypeText);
                setState(() {
                  messageController.text = "";
                  changeButtonIcon(messageController.text);
                });
              } else {
                CoinsFlowPayment(
                  context: context,
                  currentUser: widget.currentUser!,
                  showOnlyCoinsPurchase: false,
                  onCoinsPurchased: (coins) {},
                  onGiftSelected: (gift) {
                    _checkAndSendGift(gift);
                  },
                );
              }*/
            },
            child: ContainerCorner(
              color: kTransparentColor,
              marginAll: 5,
              height: 30,
              width: 30,
              child: SvgPicture.asset(
                // sendButtonIcon!,
                "assets/svg/ic_send_message.svg",
                color: Colors.white,
                height: 10,
                width: 30,
              ),
            ),
          ),
        ],
      ),
    );
  }

  checkAndSendGift(GiftsModel gift) async {
    if (widget.currentUser!.getCredits! >= gift.getCoins!) {
      widget.currentUser!.removeCredit = gift.getCoins!;
      ParseResponse saved = await widget.currentUser!.save();
      if (saved.success) {
        CloudCodeHelper.sendGift(
            author: widget.mUser!, credits: gift.getCoins!);
        widget.currentUser = saved.results!.first! as UserModel;
        _saveMessage(MessageModel.messageTypeGif,
            gif: gift.getFile!, messageType: MessageModel.messageTypeGif);
      }
    }
  }

  // Save the message
  _saveMessage(String messageText,
      {ParseFileBase? gif,
      required String messageType,
      ParseFileBase? pictureFile}) async {
    if (messageText.isNotEmpty) {
      MessageModel message = MessageModel();

      message.setAuthor = widget.currentUser!;
      message.setAuthorId = widget.currentUser!.objectId!;

      if (pictureFile != null) {
        message.setPictureMessage = pictureFile;
      }

      message.setReceiver = widget.mUser!;
      message.setReceiverId = widget.mUser!.objectId!;

      message.setMessageText = messageText;
      message.setIsMessageFile = false;

      message.setMessageType = messageType;

      message.setIsRead = false;

      if (gif != null) {
        message.setGifMessage = gif;
      }

      setState(() {
        results.insert(0, message as dynamic);
      });

      await message.save();
      _saveList(message);

      NotificationsHelper.sendPush(
          widget.currentUser!, widget.mUser!, NotificationsHelper.typeChat,
          message: getMessageType(messageType, widget.currentUser!.getFullName!,
              message: messageText));
    }
  }

  // Update or Create message list
  _saveList(MessageModel messageModel) async {
    QueryBuilder<MessageListModel> queryFrom =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryFrom.whereEqualTo(MessageListModel.keyListId,
        widget.currentUser!.objectId! + widget.mUser!.objectId!);

    QueryBuilder<MessageListModel> queryTo =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryTo.whereEqualTo(MessageListModel.keyListId,
        widget.mUser!.objectId! + widget.currentUser!.objectId!);

    QueryBuilder<MessageListModel> queryBuilder =
        QueryBuilder.or(MessageListModel(), [queryFrom, queryTo]);

    ParseResponse parseResponse = await queryBuilder.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        MessageListModel messageListModel = parseResponse.results!.first;

        messageListModel.setAuthor = widget.currentUser!;
        messageListModel.setAuthorId = widget.currentUser!.objectId!;

        messageListModel.setReceiver = widget.mUser!;
        messageListModel.setReceiverId = widget.mUser!.objectId!;

        messageListModel.setMessage = messageModel;
        messageListModel.setMessageId = messageModel.objectId!;
        messageListModel.setText = messageModel.getMessageText!;
        messageListModel.setIsMessageFile = false;

        messageListModel.setMessageType = messageModel.getMessageType!;

        messageListModel.setIsRead = false;
        messageListModel.setListId =
            widget.currentUser!.objectId! + widget.mUser!.objectId!;

        messageListModel.incrementCounter = 1;
        await messageListModel.save();

        messageModel.setMessageList = messageListModel;
        messageModel.setMessageListId = messageListModel.objectId!;

        await messageModel.save();
      } else {
        MessageListModel messageListModel = MessageListModel();

        messageListModel.setAuthor = widget.currentUser!;
        messageListModel.setAuthorId = widget.currentUser!.objectId!;

        messageListModel.setReceiver = widget.mUser!;
        messageListModel.setReceiverId = widget.mUser!.objectId!;

        messageListModel.setMessage = messageModel;
        messageListModel.setMessageId = messageModel.objectId!;
        messageListModel.setText = messageModel.getMessageText!;
        messageListModel.setIsMessageFile = false;

        messageListModel.setMessageType = messageModel.getMessageType!;

        messageListModel.setListId =
            widget.currentUser!.objectId! + widget.mUser!.objectId!;
        messageListModel.setIsRead = false;

        messageListModel.incrementCounter = 1;
        await messageListModel.save();

        messageModel.setMessageList = messageListModel;
        messageModel.setMessageListId = messageListModel.objectId!;
        await messageModel.save();
      }
    }
  }

  String getMessageType(String type, String name, {String? message}) {
    if (type == MessageModel.messageTypeGif) {
      return "push_notifications.new_gif_title".tr(namedArgs: {"name": name});
    } else if (type == MessageModel.messageTypePicture) {
      return "push_notifications.new_picture_title"
          .tr(namedArgs: {"name": name});
    } else {
      return message!;
    }
  }

  Widget gifMessage(ParseFileBase? gifMessage) {
    return Column(
      children: [
        ContainerCorner(
          color: kTransparentColor,
          borderRadius: 20,
          child: Column(
            children: [
              ContainerCorner(
                color: kTransparentColor,
                marginTop: 5,
                marginLeft: 5,
                marginRight: 5,
                height: 160,
                width: 170,
                marginBottom: 5,
                borderRadius: 20,
                child: Lottie.network(gifMessage!.url!,
                    width: 170, height: 160, animate: true, repeat: true),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String voiceStatus(CallsModel call) {
    String response = "";

    if (!call.getAccepted! &&
        call.getAuthorId! != widget.currentUser!.objectId!) {
      response = "message_screen.missed_call".tr();
    } else if (call.getAuthorId != widget.currentUser!.objectId!) {
      response = "message_screen.out_going_call".tr();
    } else if (call.getAuthorId == widget.currentUser!.objectId!) {
      response = "message_screen.incoming_call".tr();
    }
    return response;
  }

  Widget callMessage(MessageModel messageModel, bool isMe) {
    return Column(
      children: [
        ContainerCorner(
          color: kTransparentColor,
          borderRadius: 20,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ContainerCorner(
                marginRight: 50,
                marginLeft: 10,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Visibility(
                      visible: !messageModel.getCall!.getAccepted! &&
                          messageModel.getCall!.getAuthorId! !=
                              widget.currentUser!.objectId!,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.call_received,
                            color: Colors.white,
                          ),
                          TextWithTap(
                            "message_screen.missed_call".tr(),
                            color: Colors.white,
                            marginLeft: 10,
                          )
                        ],
                      ),
                    ),
                    Visibility(
                      visible: !messageModel.getCall!.getAccepted! &&
                          messageModel.getCall!.getAuthorId! ==
                              widget.currentUser!.objectId!,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.call_made,
                            color: Colors.white,
                          ),
                          TextWithTap(
                            "message_screen.missed_call".tr(),
                            color: Colors.white,
                            marginLeft: 10,
                          )
                        ],
                      ),
                    ),
                    Visibility(
                      visible: messageModel.getCall!.getAccepted! &&
                          messageModel.getCall!.getAuthorId ==
                              widget.currentUser!.objectId!,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.call_made,
                            color: isMe ? Colors.white : Colors.black,
                          ),
                          TextWithTap(
                            "message_screen.out_going_call".tr(),
                            color: Colors.white,
                            marginLeft: 10,
                          )
                        ],
                      ),
                    ),
                    Visibility(
                      visible: messageModel.getCall!.getAccepted! &&
                          messageModel.getCall!.getAuthorId !=
                              widget.currentUser!.objectId!,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.call_received,
                            color: Colors.white,
                          ),
                          TextWithTap(
                            "message_screen.incoming_call".tr(),
                            color: Colors.white,
                            marginLeft: 10,
                          )
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        TextWithTap(
                          MainHelper.getMessageTime(messageModel.createdAt!,
                              time: true),
                          marginRight: 10,
                          color: Colors.white,
                        ),
                        Visibility(
                          visible: messageModel.getCall!.getAccepted!,
                          child: TextWithTap(
                            messageModel.getCall!.getDuration!,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
              ContainerCorner(
                colors: const [Colors.deepOrangeAccent, kPrimaryColor],
                height: 50,
                marginBottom: 5,
                marginRight: 2,
                marginTop: 5,
                borderRadius: 70,
                child: Center(
                    child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Icon(
                    messageModel.getCall!.getIsVoiceCall!
                        ? Icons.phone
                        : Icons.videocam,
                    color: Colors.white,
                    size: 25,
                  ),
                )),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget callInfo(bool appear, IconData icon, String text) {
    return Visibility(
      visible: appear,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: Colors.red,
          ),
          TextWithTap(
            text,
            color: Colors.red,
            marginLeft: 10,
          )
        ],
      ),
    );
  }

  Widget storyMessage(StoriesModel story, bool isRead, bool isMe,
      String message, UserModel author) {
    return ContainerCorner(
      color: kTransparentColor,
      borderRadius: 10,
      onTap: () {
        MainHelper.goToNavigatorScreen(
            context,
            SeeOneStory(
              currentUser: widget.currentUser,
              storyAuthor: author,
              storyImage: story.getImage,
              createdDate: story.createdAt,
              story: story,
            ));
      },
      child: Column(
        children: [
          story.getImage != null
              ? Opacity(
                  opacity: 0.5,
                  child: ContainerCorner(
                    color: kTransparentColor,
                    marginTop: 5,
                    marginLeft: 5,
                    marginRight: 5,
                    borderWidth: 0,
                    height: 150,
                    width: 100,
                    child: ActionsHelper.photosWidget(
                      story.getImage!.saved ? story.getImage!.url : "",
                      borderRadius: 10,
                      fit: BoxFit.cover,
                      height: 170,
                      width: 100,
                    ),
                  ),
                )
              : Opacity(
                  opacity: 0.5,
                  child: ContainerCorner(
                    borderRadius: 10,
                    height: 150,
                    width: 100,
                    color: MainHelper.stringToColor(story.getTextBgColors!),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: AutoSizeText(
                        story.getText!,
                        style: GoogleFonts.nunito(
                          fontSize: 20,
                          color: MainHelper.stringToColor(story.getTextColors!),
                        ),
                        minFontSize: 10,
                        stepGranularity: 5,
                        maxLines: 5,
                      ),
                    ),
                  ),
                ),
          Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned(
                child: ContainerCorner(
                  borderRadius: 5,
                  width: 160,
                  colors: const [Colors.deepOrangeAccent, kPrimaryColor],
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextWithTap(
                        message,
                        color: Colors.white,
                        fontSize: 14,
                        textAlign: TextAlign.left,
                        marginLeft: 5,
                        marginTop: 3,
                        marginBottom: 5,
                        marginRight: 5,
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            TextWithTap(
                              MainHelper.getMessageTime(story.createdAt!,
                                  time: true),
                              color: Colors.white.withOpacity(0.7),
                              fontSize: 12,
                              marginRight: 10,
                              marginLeft: 10,
                            ),
                            if (isMe)
                              Padding(
                                padding: const EdgeInsets.only(right: 3),
                                child: Icon(
                                  Icons.done_all,
                                  color: isRead ? kBlueColor1 : Colors.white,
                                  size: 15,
                                ),
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  Widget pictureMessage(ParseFileBase picture) {
    return Column(
      children: [
        ContainerCorner(
          color: kTransparentColor,
          borderRadius: 20,
          onTap: () => openPicture(picture),
          child: Column(
            children: [
              ContainerCorner(
                color: kTransparentColor,
                marginTop: 5,
                marginLeft: 5,
                marginRight: 5,
                height: 300,
                width: 250,
                marginBottom: 5,
                child: ActionsHelper.photosWidget(
                    picture.saved ? picture.url : "",
                    borderRadius: 20,
                    fit: BoxFit.cover,
                    width: 200,
                    height: 200),
              ),
            ],
          ),
        ),
      ],
    );
  }

  _showMessagePictureBottomSheet(ParseFileBase picture) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.005),
        child: GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: DraggableScrollableSheet(
            initialChildSize: 1.0,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.8),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: ContainerCorner(
                    color: kTransparentColor,
                    height: MediaQuery.of(context).size.height - 200,
                    child: ActionsHelper.photosWidget(picture.url,
                        borderRadius: 5, fit: BoxFit.contain),
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

}
