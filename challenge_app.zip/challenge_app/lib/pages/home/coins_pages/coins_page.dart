// ignore_for_file: must_be_immutable, deprecated_member_use, iterable_contains_unrelated_type, avoid_function_literals_in_foreach_calls, use_build_context_synchronously, depend_on_referenced_packages, library_private_types_in_public_api
import 'dart:async';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/others/in_app_model.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:in_app_purchase_storekit/store_kit_wrappers.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:whatsapp_unilink/whatsapp_unilink.dart';

import '../../../configurations/global_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../models/PaymentsModel.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class CoinsPage extends StatefulWidget {
  UserModel? currentUser;

  CoinsPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _CoinsPageState createState() => _CoinsPageState();
}

class _CoinsPageState extends State<CoinsPage> {
  get size => MediaQuery.of(context).size;
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;
  late StreamSubscription<List<PurchaseDetails>> _subscription;
  bool _isAvailable = false;
  bool _purchasePending = false;
  bool _loading = true;
  String? _queryProductError;
  List<ProductDetails> _products = [];
  InAppPurchaseModel? _inAppPurchaseModel;

  final List<String> _kProductIds = <String>[
    Config.credit200,
    Config.credit1000,
    Config.credit100,
    Config.credit500,
    Config.credit2200,
    Config.credit5260,
    Config.credit10600,
  ];

  List bgImages = [
    "assets/images/img_credit_7.png",
    "assets/images/img_credit_2.png",
    "assets/images/img_credit_6.png",
    "assets/images/img_credit_4.png",
    "assets/images/img_credit_5.png",
    "assets/images/img_credit_3.png",
    "assets/images/img_credit_1.png"
  ];

  List<InAppPurchaseModel> getInAppList() {
    List<InAppPurchaseModel> inAppPurchaseList = [];

    for (ProductDetails productDetails in _products) {

      if (productDetails.id == Config.credit200) {
        InAppPurchaseModel credits200 = InAppPurchaseModel(
            id: Config.credit200,
            coins: 200,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typePopular,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit200)) {
          inAppPurchaseList.add(credits200);
        }
      }

      if (productDetails.id == Config.credit1000) {
        InAppPurchaseModel credits1000 = InAppPurchaseModel(
            id: Config.credit1000,
            coins: 1000,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeHot,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit1000)) {
          inAppPurchaseList.add(credits1000);
        }
      }

      if (productDetails.id == Config.credit100) {
        InAppPurchaseModel credits100 = InAppPurchaseModel(
            id: Config.credit100,
            coins: 100,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit100)) {
          inAppPurchaseList.add(credits100);
        }
      }

      if (productDetails.id == Config.credit500) {
        InAppPurchaseModel credits500 = InAppPurchaseModel(
            id: Config.credit500,
            coins: 500,
            price: productDetails.price,
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit500)) {
          inAppPurchaseList.add(credits500);
        }
      }

      if (productDetails.id == Config.credit2200) {
        InAppPurchaseModel credits2100 = InAppPurchaseModel(
            id: Config.credit2200,
            coins: 2200,
            price: productDetails.price,
            discount: "22,09",
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit2200)) {
          inAppPurchaseList.add(credits2100);
        }
      }

      if (productDetails.id == Config.credit5260) {
        InAppPurchaseModel credits5250 = InAppPurchaseModel(
            id: Config.credit5260,
            coins: 5260,
            price: productDetails.price,
            discount: "57,79",
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit5260)) {
          inAppPurchaseList.add(credits5250);
        }
      }

      if (productDetails.id == Config.credit10600) {
        InAppPurchaseModel credits10500 = InAppPurchaseModel(
            id: Config.credit10600,
            coins: 10600,
            price: productDetails.price,
            discount: "110,29",
            image: "assets/images/ic_coins_4000.png",
            type: InAppPurchaseModel.typeNormal,
            productDetails: productDetails,
            currency: productDetails.currencyCode,
            currencySymbol: productDetails.currencySymbol);

        if (!inAppPurchaseList.contains(Config.credit10600)) {
          inAppPurchaseList.add(credits10500);
        }
      }
    }

    return inAppPurchaseList;
  }

  void getUser() async {
    widget.currentUser = await ParseUser.currentUser();
  }

  @override
  void dispose() {
    if (MainHelper.isIOSPlatform()) {
      var iosPlatformAddition = _inAppPurchase
          .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      iosPlatformAddition.setDelegate(null);
    }
    _subscription.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    final Stream<List<PurchaseDetails>> purchaseUpdated =
        _inAppPurchase.purchaseStream;

    _subscription = purchaseUpdated.listen((purchaseDetailsList) {
        _listenToPurchaseUpdated(purchaseDetailsList);
      }, onDone: () {
        _subscription.cancel();
      }, onError: (error) {
        // handle error here.
      }
    );
    getUser();
    initStoreInfo();
  }

  Future<void> initStoreInfo() async {
    final bool isAvailable = await _inAppPurchase.isAvailable();
    if (!isAvailable) {
      setState(() {
        _isAvailable = isAvailable;
        _products = [];
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (MainHelper.isIOSPlatform()) {
      var iosPlatformAddition = _inAppPurchase
          .getPlatformAddition<InAppPurchaseStoreKitPlatformAddition>();
      await iosPlatformAddition.setDelegate(IOSPaymentQueueDelegate());
    }

    ProductDetailsResponse productDetailResponse =
        await _inAppPurchase.queryProductDetails(_kProductIds.toSet());

    if (productDetailResponse.error != null) {
      setState(() {
        _queryProductError = productDetailResponse.error!.message;
        _isAvailable = isAvailable;
        _products = productDetailResponse.productDetails;
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    if (productDetailResponse.productDetails.isEmpty) {
      setState(() {
        _queryProductError = null;
        _isAvailable = isAvailable;
        _products = productDetailResponse.productDetails;
        _purchasePending = false;
        _loading = false;
      });
      return;
    }

    setState(() {
      _isAvailable = isAvailable;
      _products = productDetailResponse.productDetails;
      _purchasePending = false;
      _loading = false;
    });
  }

  void _listenToPurchaseUpdated(List<PurchaseDetails> purchaseDetailsList) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        showPendingUI();
      } else {
        if (purchaseDetails.status == PurchaseStatus.canceled) {
          MainHelper.hideLoadingDialog(context);

          MainHelper.showAppNotificationAdvanced(
            context: context,
            user: widget.currentUser,
            title: "in_app_purchases.purchase_cancelled_title".tr(),
            message: "in_app_purchases.purchase_cancelled".tr(),
          );
        } else if (purchaseDetails.status == PurchaseStatus.error) {
          handleError(purchaseDetails.error!);
        } else if (purchaseDetails.status == PurchaseStatus.purchased ||
            purchaseDetails.status == PurchaseStatus.restored) {
          bool valid = await _verifyPurchase(purchaseDetails);
          if (valid) {
            _addPurchaseToUserAccount(purchaseDetails);
          } else {
            _handleInvalidPurchase(purchaseDetails);
          }
        }

        if (purchaseDetails.pendingCompletePurchase) {
          await InAppPurchase.instance.completePurchase(purchaseDetails);
        }
      }
    });
  }

  _purchaseProduct(ProductDetails productDetails) async {
    if (MainHelper.isAndroidPlatform()) {
      MainHelper.showLoadingDialog(context);
    }

    _inAppPurchase
      .buyConsumable(
          purchaseParam: PurchaseParam(productDetails: productDetails),
          autoConsume: true)
      .onError((error, stackTrace) {
        if (error is PlatformException &&
            error.code == "storekit_duplicate_product_object") {
          MainHelper.showAppNotification(
            context: context,
            title: "in_app_purchases.purchase_pending_error".tr(),
          );
        }
        return false;
    });
  }

  Future<bool> _verifyPurchase(PurchaseDetails purchaseDetails) async {
    // IMPORTANT!! Always verify a purchase before delivering the product.
    // For the purpose of an example, we directly return true.
    QueryBuilder<PaymentsModel> query = QueryBuilder(PaymentsModel());
    query.whereEqualTo(PaymentsModel.keyItemTransactionId,
        purchaseDetails.productID);

    ParseResponse response = await query.query();

    if(response.success){
      if(response.results != null){
        return Future<bool>.value(false);
      }else{
        return Future<bool>.value(true);
      }
    }else{
      return Future<bool>.value(true);
    }
  }

  void _handleInvalidPurchase(PurchaseDetails purchaseDetails) {
    // handle invalid purchase here if  _verifyPurchase` failed.
    MainHelper.showAppNotification(
        context: context, title: "in_app_purchases.invalid_purchase".tr());
    MainHelper.hideLoadingDialog(context);
  }

  _addPurchaseToUserAccount(PurchaseDetails purchaseDetails) async {

    _inAppPurchase.completePurchase(purchaseDetails);

    if (MainHelper.isAndroidPlatform()) {
      final InAppPurchaseAndroidPlatformAddition androidAddition =
          _inAppPurchase
              .getPlatformAddition<InAppPurchaseAndroidPlatformAddition>();

      await androidAddition.consumePurchase(purchaseDetails);
    }

    if (widget.currentUser != null) {
      widget.currentUser?.addCredit = _inAppPurchaseModel!.coins!;
      ParseResponse parseResponse = await widget.currentUser!.save();
      if (parseResponse.success) {
        widget.currentUser = parseResponse.results!.first as UserModel;
        MainHelper.hideLoadingDialog(context);
        MainHelper.showAppNotificationAdvanced(
          context: context,
          user: widget.currentUser,
          title: "in_app_purchases.coins_purchased"
              .tr(namedArgs: {"coins": _inAppPurchaseModel!.coins!.toString()}),
          message: "in_app_purchases.coins_added_to_account".tr(),
          isError: false,
        );

        registerPayment(purchaseDetails, _inAppPurchaseModel!.productDetails!);
      } else {
        MainHelper.hideLoadingDialog(context);
        MainHelper.showAppNotification(
            context: context, title: parseResponse.error!.message);
      }
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotification(
          context: context, title: "in_app_purchases.error_found".tr());
    }
  }

  void registerPayment(
      PurchaseDetails purchaseDetails, ProductDetails productDetails) async {
    // Save all payment information
    PaymentsModel paymentsModel = PaymentsModel();
    paymentsModel.setAuthor = widget.currentUser!;
    paymentsModel.setAuthorId = widget.currentUser!.objectId!;
    paymentsModel.setPaymentType = PaymentsModel.paymentTypeConsumible;

    paymentsModel.setId = productDetails.id;
    paymentsModel.setTitle = productDetails.title;
    paymentsModel.setTransactionId = purchaseDetails.purchaseID!;
    paymentsModel.setCurrency = productDetails.currencyCode.toUpperCase();
    paymentsModel.setPrice = productDetails.price;
    paymentsModel.setMethod = MainHelper.isAndroidPlatform()
        ? "Google Play"
        : MainHelper.isIOSPlatform()
            ? "App Store"
            : "";
    paymentsModel.setStatus = PaymentsModel.paymentStatusCompleted;

    await paymentsModel.save();
  }

  void handleError(IAPError error) {
    MainHelper.hideLoadingDialog(context);
    MainHelper.showAppNotification(context: context, title: error.message);

    setState(() {
      _purchasePending = false;
    });
  }

  showPendingUI() {
    MainHelper.showLoadingDialog(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: MainHelper.isDarkMode(context)
        ? kContentColorLightTheme
        : Colors.white,
      body: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          SafeArea(
            child: getBody(),
          ),
        ],
      ),
    );
  }

  Widget getBody() {

    if (_purchasePending) {}

    if (_loading) {
      return MainHelper.appLoading();
    } else if (_isAvailable && _products.isNotEmpty) {
      if (_queryProductError == null) {
        return getProductList();
      } else {
        return noProducts(_queryProductError.toString());
      }
    } else {
      return noProducts("in_app_purchases.no_product_found_title".tr());
    }
  }

  Widget getProductList() {
    var size = MediaQuery.of(context).size;

    return ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.only(bottom: 100),
      children: [
        const SizedBox(
          height: 3,
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.only(left: 5.0, right: 5),
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              children: List.generate(getInAppList().length, (index) {
                InAppPurchaseModel inApp = getInAppList()[index];

                return GestureDetector(
                  onTap: () {
                    _inAppPurchaseModel = inApp;
                    _purchaseProduct(inApp.getProductDetails()!);
                  },
                  child: ContainerCorner(
                    width: size.width * 0.30,
                    height: size.width * 0.2,
                    // imageDecoration: bgImages[index],
                    color: kButtonTextColor,
                    borderWidth: 0,
                    borderRadius: 10,
                    child: Stack(
                      children: [
                        ContainerCorner(
                            width: size.width * 0.30,
                            height: size.width * 0.2,
                            borderWidth: 0,
                            borderRadius: 10,
                            color: kTransparentColor,
                            child: Stack(
                                alignment: AlignmentDirectional.center,
                                children: [
                                  Positioned(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.center,
                                          children: [
                                            SvgPicture.asset(
                                              "assets/svg/ic_coin_with_star.svg",
                                              height: size.width / 27,
                                              width: size.width / 27,
                                            ),
                                            TextWithTap(
                                              "${inApp.coins}",
                                              fontSize: 18,
                                              marginLeft: 10,
                                              color:
                                              Colors.white.withOpacity(0.8),
                                            ),
                                          ],
                                        ),
                                        TextWithTap(
                                          inApp.price!,
                                          fontWeight: FontWeight.bold,
                                          fontSize: size.width / 25,
                                          marginTop: 12,
                                          color: Colors.white.withOpacity(0.8),
                                          textAlign: TextAlign.center,
                                        ),
                                      ],
                                    ),
                                  ),
                                ]))
                      ],
                    ),
                  ),
                );
              }),
            ),
          ),
        )
      ],
    );
  }

  sendWhatAppMessage() async {
    MainHelper.hideLoadingDialog(context);

    final link = WhatsAppUnilink(
      phoneNumber: Setup.coinsSupportNumber,
      text: "invite_friends.need_help_coins"
          .tr(namedArgs: {"id": widget.currentUser!.objectId!}),
    );
    // Convert the WhatsAppUnilink instance to a string.
    // Use either Dart's string interpolation or the toString() method.
    // The "launch" method is part of "url_launcher".
    await launch(
      '$link',
      forceSafariVC: false,
    );

    //String url = "https://api.whatsapp.com/send?phone=${Setup.coinsSupportNumber}&text=Hello";
    //String url = "https://api.whatsapp.com/send?phone=${Setup.coinsSupportNumber}&text=${"invite_friends.need_help_coins".tr(namedArgs: {"id" : widget.currentUser!.objectId!}).replaceAll(" ", "%20")}";
    //MainHelper.launchInWebViewWithJavaScript(url);

    //print("URL: $url");
  }

  Widget noProducts(String message) {
    return ContainerCorner(
      width: size.width,
      height: size.height * 0.9,
      child: Center(
        child: TextWithTap(
          message,
          fontSize: size.width / 22,
          textAlign: TextAlign.center,
          marginTop: size.height * 0.17,
          color:Colors.white,
        ),
      ),
    );
  }
}

class IOSPaymentQueueDelegate implements SKPaymentQueueDelegateWrapper {
  @override
  bool shouldContinueTransaction(
      SKPaymentTransactionWrapper transaction, SKStorefrontWrapper storefront) {
    return true;
  }

  @override
  bool shouldShowPriceConsent() {
    return false;
  }
}
