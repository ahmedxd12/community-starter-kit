import 'dart:ui';

import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/NotificationsModel.dart';
import 'package:challenge/models/PostModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../../../models/ChallengeModel.dart';
import '../../../widgets/custom_widgets/app_bar.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../livestreaming_pages/live_streaming_page.dart';
import '../profile_pages/user_profile_page.dart';
import '../video_pages/accept_challenge_page.dart';

// ignore: must_be_immutable
class NotificationsPage extends StatefulWidget {
  static const String route = '/home/notifications';
  UserModel? currentUser;

  NotificationsPage({Key? key, this.currentUser}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  // UserModel? currentUser;
  get size => MediaQuery.of(context).size;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ToolBar(
        extendBodyBehindAppBar: true,
        backgroundColor: kTransparentColor,
        titleChild: TextWithTap(
          "page_title.notification_title".tr(),
          color:Colors.white,
        ),
        centerTitle: MainHelper.isAndroidPlatform() ? false : true,
        leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            ContainerCorner(
              width: size.width,
              height: size.height,
              child: SafeArea(
                child: showUserNotifications(),
              ),
            ),
          ],
        ));
  }

  Widget showUserNotifications() {
    QueryBuilder<NotificationsModel> queryBuilder =
    QueryBuilder<NotificationsModel>(NotificationsModel());

    queryBuilder.includeObject([
      NotificationsModel.keyAuthor,
      NotificationsModel.keyReceiver,
      NotificationsModel.keyLive,
      NotificationsModel.keyLiveAuthor,
      NotificationsModel.keyChallenge,
      NotificationsModel.keyChallengeAuthor,
    ]);

    queryBuilder.whereEqualTo(
        NotificationsModel.keyReceiver, widget.currentUser!);
    queryBuilder.orderByDescending(NotificationsModel.keyCreatedAt);
    queryBuilder.whereNotEqualTo(
        NotificationsModel.keyAuthor, widget.currentUser!);


    return ParseLiveListWidget<NotificationsModel>(
      query: queryBuilder,
      reverse: false,
      lazyLoading: false,
      duration: const Duration(seconds: 0),
      scrollPhysics: const NeverScrollableScrollPhysics(),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<ParseObject> snapshot) {
        if (snapshot.failed) {
          return Text('not_connected'.tr());
        } else if (snapshot.hasData) {
          NotificationsModel notifications =
              snapshot.loadedData! as NotificationsModel;

          return buidNotify(
            notifications.getAuthor!,
            notifications.getNotificationType!,
            post: notifications.getPost,
            notification: notifications,
            live: notifications.getLive,
            challenge: notifications.getChallenge
          );
        } else {
          return noNotifications();
        }
      },
      listLoadingElement: const Center(
        child: CircularProgressIndicator(),
      ),
      queryEmptyElement: noNotifications(),
    );
  }

  Widget noNotifications() {
    return ContainerCorner(
      width: size.width,
      height: size.height * 0.7,
      child: Center(
        child: TextWithTap(
          'notifications_screen.no_notif_title'.tr(),
          fontSize: size.width / 22,
          textAlign: TextAlign.center,
          marginTop: size.height * 0.17,
          color:Colors.white,
        ),
      ),
    );
  }

  Widget buidNotify(UserModel user, String type,
      {PostsModel? post,
        LiveStreamingModel? live,
        NotificationsModel? notification,
        ChallengeModel? challenge}) {
    String description = "";

    if (type == NotificationsModel.notificationTypeFollowers) {
      description = "notifications_screen.started_follow_you".tr();
    } else if (type == NotificationsModel.notificationTypeLikedPost) {
      description = "notifications_screen.liked_your_post".tr();
    } else if (type == NotificationsModel.notificationTypeCommentPost) {
      description = "notifications_screen.commented_post".tr();
    } else if (type == NotificationsModel.notificationTypeLiveInvite) {
      description = "notifications_screen.commented_post".tr();
    } else if (type == NotificationsModel.notificationTypeChallengeInvite) {
      description = "notifications_screen.challenge_invite".tr(
          namedArgs: {"userName":"${user.getFullName}",});
    }

    return ContainerCorner(
      color: notification!.isRead! 
          ? kTransparentColor : kButtonTextColor.withOpacity(0.2),
      onTap: () {
        _saveRead(notification);

        if (type == NotificationsModel.notificationTypeFollowers) {
          // ActionsHelper.showUserProfile(context, widget.currentUser!, user);
          _goToProfile(user,);
        } else if (type == NotificationsModel.notificationTypeCommentPost) {
          /*MainHelper.goToNavigatorScreen(
              context,
              CommentPostPage(
                currentUser: widget.currentUser,
                post: post,
              ));*/
        } else if (type == NotificationsModel.notificationTypeLikedPost) {
          /*MainHelper.goToNavigatorScreen(
              context,
              CommentPostPage(
                currentUser: widget.currentUser,
                post: post,
              ));*/
        } else if (type == NotificationsModel.notificationTypeLiveInvite) {
          MainHelper.goToNavigatorScreen(
            context,
            LiveStreamingPage(
              channelName: live!.getStreamingChannel!,
              isBroadcaster: false,
              currentUser: widget.currentUser!,
              mUser: live.getAuthor!,
              mLiveStreamingModel: live,
            ),
          );
        } else if (type == NotificationsModel.notificationTypeChallengeInvite) {
          MainHelper.goToNavigatorScreen(
            context,
            AcceptChallengePage(
              challenge: challenge,
              currentUser: widget.currentUser,
              video: challenge!.getAuthorVideo!,
              isAuthor: false,
            ),
          );
        }
      },
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Row(
          children: [
            ContainerCorner(
              color: kTransparentColor,
              height: 65,
              width: 65,
              child: ActionsHelper.polygonAvatarWidget(
                  currentUser:user,fontSize: 24),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextWithTap(
                    user.getFullName!,
                    marginLeft: 10,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                  TextWithTap(
                    description,
                    marginLeft: 10,
                    marginTop: 2,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    fontSize: 13,
                    color: Colors.white.withOpacity(0.9),
                  ),
                  TextWithTap(
                    MainHelper.getMessageTime(notification.createdAt!,),
                    marginLeft: 10,
                    marginTop: 5,
                    maxLines: 5,
                    overflow: TextOverflow.ellipsis,
                    color: Colors.white.withOpacity(0.4),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  _goToProfile(UserModel user) {
    MainHelper.goToNavigatorScreen(
      context,
      user.getUid == widget.currentUser!.getUid
      ? ProfilePage(
        currentUser: widget.currentUser!,)
      : UserProfilePage(
        currentUser: widget.currentUser, mUser: user
      ),
    );
  }

  _saveRead(NotificationsModel notifications) async {
    notifications.setRead = true;
    await notifications.save();
  }

}
