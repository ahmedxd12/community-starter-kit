// ignore_for_file: must_be_immutable, use_build_context_synchronously

import 'dart:io';

import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/pages/global/global_loading_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock/wakelock.dart';

import '../../../models/NotificationsModel.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';

class ApproveVideoPage extends StatefulWidget {
  static const String route = "/Video/Approve";
  final UserModel? currentUser;
  final File? video;
  final File? thumbnail;
  ChallengeModel? challenge;
  ChallengeModel? originalChallenge;
  bool? isRePropose = false;
  bool? isAuthor = true;

  ApproveVideoPage(
      {Key? key,
       this.currentUser,
       this.video,
       this.challenge,
       this.originalChallenge,
       this.isRePropose,
       this.isAuthor,
       this.thumbnail
  }) : super(key: key);

  @override
  State<ApproveVideoPage> createState() => _ApproveVideoPageState();
}

class _ApproveVideoPageState extends State<ApproveVideoPage> {
  get size => MediaQuery.of(context).size;
  late VideoPlayerController _controller;
  bool videoApproved = false;
  bool isPlaying = false;

  ParseFileBase? parseFile;
  ParseFileBase? thumbnailFile;

  @override
  void initState() {
    super.initState();

      _controller = VideoPlayerController.file(
          File(widget.video!.path)
      )
        ..addListener(() {})
        ..setLooping(false)
        ..initialize().then((_) {
          //_controller.play();
        });

    Wakelock.enable();
  }

  @override
  void dispose() {
    Wakelock.disable();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: _getBody(),
    );
  }

  playOrPauseVideo(){
    setState((){
      if(_controller.value.isPlaying){
        _controller.pause();
        isPlaying = false;
      }else{
        _controller.play();
        isPlaying = true;
      }
    });
  }

  Widget _getBody() {
    return Stack(
      children: [
        ContainerCorner(
          onTap: (){
            playOrPauseVideo();
          },
          width: size.width,
          height: size.height,
          imageDecoration: "assets/images/app_bg.png",
          child: videoPlayer(),
        ),
        Visibility(
          visible: !_controller.value.isPlaying,
            child: ContainerCorner(
              onTap: (){
                playOrPauseVideo();
              },
              width: size.width,
              height: size.height,
              child: Center(
                child: ContainerCorner(
                  onTap: (){
                    playOrPauseVideo();
                  },
                  width: size.width*0.20,
                  height: size.width*0.20,
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: 50,
                  child: Center(
                    child: Icon(
                      Icons.play_arrow,
                      color: Colors.white,
                      size: size.width*0.16,
                    ),
                  ),
                ),
              ),
            )
        ),
        Visibility(
            visible: true,
            child:SafeArea(
              child: ContainerCorner(
                width: size.width,
                height: size.height*0.15,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ContainerCorner(
                          onTap: () {
                            cancelUpload();
                          },
                          width:size.width/8,
                          height:size.width/8,
                          marginLeft: 10,
                          marginRight: 10,
                          marginTop:16,
                          marginBottom:16,
                          color: kButtonTextColor,
                          borderRadius: 50,
                          child: Center(
                            child: Icon(Icons.close, size: size.width/15,color: kContentColorDarkTheme,),
                          ),
                        ),
                        ContainerCorner(
                          onTap: () {
                            approveUpload();
                          },
                          width:size.width/8,
                          height:size.width/8,
                          marginLeft: 10,
                          marginRight: 10,
                          marginTop:16,
                          marginBottom:16,
                          color: kButtonTextColor,
                          borderRadius: 50,
                          child: Center(
                            child: Icon(Icons.check, size: size.width/15,color: kContentColorDarkTheme,),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            )
        ),
      ],
    );
  }

  Widget videoPlayer(){
    return _controller.value.isInitialized
        ? AspectRatio(
        aspectRatio: _controller.value.aspectRatio,
        child: VideoPlayer(_controller))
        : Image.file(widget.thumbnail!,fit: BoxFit.fill,);
  }

  approveUpload() async {
    setState(() {
      videoApproved = true;
    });

    MainHelper.showLoadingDialog(context, isDismissible:false,);

    setState(() {
      if (widget.video!.path.isNotEmpty) {
        parseFile = ParseFile(File(widget.video!.path), name: "video.mp4");
      }
      
      if (widget.thumbnail!.path.isNotEmpty){
        thumbnailFile = ParseFile(widget.thumbnail, name: "thumbnail.png");
      }
    });

    ParseResponse parseResponse = await parseFile!.save();
    ParseResponse parseTResponse = await thumbnailFile!.save();

    if (parseResponse.success && parseTResponse.success) {
      if (parseResponse.results!.isNotEmpty && parseTResponse.results!.isNotEmpty) {
        saveVideo();
      }
    } else {
      MainHelper.showDialogLivEend(
        context: context,
        title: 'video.video'.tr(),
        confirmButtonText: 'ok'.tr(),
        message: 'video.upload_failed'.tr(),
        onPressed: () {
          // Count as one more re-propose and upload a new video
          MainHelper.hideLoadingDialog(context);
          MainHelper.goBackToPreviousPage(context);
        },
      );
    } 
  }

  saveVideo() async {
    VideoModel newVideo = VideoModel();

    newVideo.setAuthor = widget.currentUser!;
    newVideo.setAuthorId = widget.currentUser!.objectId!;

    newVideo.setVideo = parseFile!;
    newVideo.setUrl = parseFile!.url!;

    newVideo.setDuration = _controller.value.duration.toString().substring(2, 7);
    newVideo.setCurrentState = VideoModel.videoCurrentStatePublished;
    newVideo.setThumbnail = thumbnailFile!;
    await newVideo.save();

    saveChallenge(newVideo);
  }

  saveChallenge(VideoModel video) async {
    ChallengeModel challenge = widget.challenge!;

    if(widget.isAuthor!){
      challenge.setAuthorVideo = video;
      challenge.setAuthorVideoId = video.objectId!;
    } else {
      challenge.setChallengerVideo = video;
      challenge.setChallengerVideoId = video.objectId!;
    }

    await challenge.save();

    ActionsHelper.createOrDeleteNotification(
        widget.challenge!.getAuthor!,
        widget.challenge!.getChallenger!,
        NotificationsModel.notificationTypeChallengeInvite,
        challenge: challenge
    );

    if(widget.isRePropose!){
      updateOriginalChallenge(widget.challenge!);
    }else{
      goBackHome();
    }
  }

  updateOriginalChallenge(ChallengeModel challenge) async {
    widget.originalChallenge!.setRePropose = challenge.objectId!;
    await widget.originalChallenge!.save();

    goBackHome();
  }

  goBackHome(){
    MainHelper.hideLoadingDialog(context);
    MainHelper.showDialogLivEend(
      context: context,
      title: 'video.video'.tr(),
      confirmButtonText: 'ok'.tr(),
      message: 'video.upload_successful'.tr(),
      dismiss: false,
      onPressed: () {
        Wakelock.disable();
        _controller.dispose();

        if(widget.isRePropose!){
          MainHelper.goBackToPreviousPage(context);
          MainHelper.goBackToPreviousPage(context);
        }else{
          MainHelper.goToNavigatorScreen(
            context,
            GlobalLoadingPage(currentUser: widget.currentUser,),
            finish: true,
            back: false,
          );
        }
      },
    );
  }

  cancelUpload(){
    MainHelper.goBackToPreviousPage(context);
  }
}
