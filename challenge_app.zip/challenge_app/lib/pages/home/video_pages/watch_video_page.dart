// ignore_for_file: must_be_immutable, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:challenge/models/ReportModel.dart';
import 'package:challenge/pages/home/home_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:challenge/pages/home/video_pages/all_challenge_re_propose.dart';
import 'package:challenge/pages/home/video_pages/upload_video_page.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoCommentModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/widgets/custome_drawer.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock/wakelock.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';
import 'package:clipboard/clipboard.dart';
import 'package:dio/dio.dart';
import 'package:lecle_downloads_path_provider/lecle_downloads_path_provider.dart';

import '../../../configurations/global_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../configurations/router_config.dart';
import '../../../services/dynamic_link_service.dart';
import '../../../widgets/custom_widgets/button_with_icon.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../utilities/main_utilities/colors.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class WatchVideoPage extends StatefulWidget {
  static const String route = "/video/watch";
  UserModel? currentUser;
  ChallengeModel? challenge;
  VideoModel? video;

  WatchVideoPage({
    Key? key,
    this.currentUser,
    this.video,
    this.challenge
  }) : super(key: key);

  @override
  State<WatchVideoPage> createState() => _WatchVideoPageState();
}

class _WatchVideoPageState extends State<WatchVideoPage> with RouteAware {
  get size => MediaQuery.of(context).size;
  late Uri shareUrl;
  final DynamicLinkService _dynamicLinkService = DynamicLinkService();

  late VideoPlayerController _controller;
  late bool isLiked;
  bool _showThumbsUp = false;
  bool _showThumbsDown = false;
  bool _showChat = false;
  bool _hideSendButton = false;
  bool visibleKeyBoard = false;

  int viewsCount = 0;

  TextEditingController textEditingController = TextEditingController();
  late FocusNode? chatTextFieldFocusNode;

  createShareLink() async{
    shareUrl = (await _dynamicLinkService.createDynamicLink(widget.currentUser!.objectId!,
        type:'invite'))!;
  }

  @override
  void didPopNext() {
    Wakelock.enable();
    initController();
    super.didPopNext();
  }

  @override
  void initState() {
    super.initState();
    chatTextFieldFocusNode = FocusNode();

    isVideoLiked();
    initController();

    Wakelock.enable();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      AppRouter.routeObserver.subscribe(this, ModalRoute.of(context)! as PageRoute);
    });

    createShareLink();
  }

  @override
  void dispose() {
    Wakelock.disable();
    _controller.dispose();
    super.dispose();
  }

  void toggleSendButton(bool active) {
    setState(() {
      _hideSendButton = active;
    });
  }

  void isVideoLiked() {
    isLiked = widget.video!.getLikes!.contains(widget.currentUser!.getUid);
  }

  void initController() {
      _controller = VideoPlayerController.network(
        widget.video!.getVideo != null
            ? '${widget.video!.getVideo!.url}'
            : '${widget.video!.getUrl}',
      )
        ..addListener(() {
          setState((){});
        })
        ..setLooping(true)
        ..initialize().then((_) {

          _controller.play();

          Timer(
              Duration(
                  seconds: (_controller.value.duration.inSeconds.round() ~/ 2)),
                  () {
                  if (widget.video!.getAuthor!.objectId !=
                      widget.currentUser!.objectId) {
                    addViews();
                  }
              });
        });
  }

  void changeVideoSpeed(double speed) {
    _controller.setPlaybackSpeed(speed);
  }

  void showThumbsUp(){
    setState((){
      _showThumbsUp = !_showThumbsUp;
    });
    Timer(const Duration(seconds: 1),(){
      setState((){
        _showThumbsUp = !_showThumbsUp;
      });
    });
  }
  
  void showThumbsDown(){
    setState((){
      _showThumbsDown = !_showThumbsDown;
    });
    Timer(const Duration(seconds: 1),(){
      setState((){
        _showThumbsDown = !_showThumbsDown;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => MainHelper.removeFocusOnTextField(context),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        extendBodyBehindAppBar: true,
        endDrawer: CustomDrawer(currentUser: widget.currentUser,isVideoPage: true,),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: kTransparentColor,
          leading: ContainerCorner(
            onTap: () {
              Wakelock.disable();
              _controller.dispose();

              MainHelper.goToNavigatorScreen(
                  context,
                  widget.video!.getAuthor!.getUid == widget.currentUser!.getUid
                      ? ProfilePage(
                          currentUser: widget.currentUser!,
                        )
                      : UserProfilePage(
                          currentUser: widget.currentUser,
                          mUser: widget.video!.getAuthor),
                back: true,
              );
            },
            width: size.width / 15,
            height: size.width / 15,
            child: Padding(
              padding: const EdgeInsets.only(left: 8.0,top: 4.5, bottom: 4.5),
              child: ActionsHelper.polygonAvatarWidget(
                  currentUser:widget.video!.getAuthor!,
                  fontSize: 26),
            ),
          ),
          title: TextWithTap(
            '@${widget.video!.getAuthor!.getUsername}',
            fontSize: 16.5,
            color: kContentColorDarkTheme,
          ),
          titleSpacing: 2.0,
          actions: [
            Container(),
          ],
        ),
        body: _getBody(),
      ),
    );
  }

  Widget _getBody() {
    return Stack(
      children: [
        ContainerCorner(
          width: size.width,
          height: size.height,
          color: Colors.black.withOpacity(0.99),
          // imageDecoration: "assets/images/app_bg.png",
          child: Center(
            child: ContainerCorner(
                width: size.width,
                child: videoPlayer()
            ),
          ),
        ),
        Visibility(
          visible: _controller.value.isInitialized,
          child: Align(
            alignment: Alignment.centerRight,
            child: btnActions(),
          ),
        ),
        Visibility(
          visible: _showChat && _controller.value.isInitialized,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: ContainerCorner(
                height: size.height * 0.8,
                marginRight: size.width * 0.27,
                marginBottom: visibleKeyBoard
                    ? MediaQuery.of(context).viewInsets.bottom
                    : 1,
                child: audienceBottom(),
              ),
            ),
          ),
        ),
        Visibility(
          visible: _controller.value.isInitialized,
          child: Align(
            alignment: Alignment.centerLeft,
            child: ContainerCorner(
              color: kTransparentColor,
              height: size.height*0.38,
              width: size.width*0.03,
              marginLeft: size.width/30,
              child: Stack(
                children:[
                  Center(
                    child: ContainerCorner(
                      color: kButtonTextColor,
                      height:size.height*0.38,
                      width:2,
                    ),
                  ),
                  Center(
                    child: SfSlider.vertical(
                      min: 0.25,
                      max: 2.0,
                      value: _controller.value.playbackSpeed,
                      interval: 0.25,
                      thumbIcon: SvgPicture.asset(
                        'assets/svg/ic_speed.svg',
                        width:70.0,
                        height:70.0,
                        fit: BoxFit.fill,
                      ),
                      activeColor: kTransparentColor,
                      inactiveColor: kTransparentColor,
                      onChanged: (dynamic value){
                        setState(() {
                          changeVideoSpeed(value);
                        });
                      },
                    ),
                  ),
                ]
              ),
            ),
          ),
        ),
        Visibility(
          visible: _showThumbsUp,
          child: Center(
            child: Image.asset(
              'assets/images/ic_thumbs_up.png',
              width: 100,
              height: 100,
            ),
          ),
        ),
        Visibility(
          visible: _showThumbsDown,
          child: Center(
            child: Transform.rotate(
              angle: 135,
              child: Image.asset(
                'assets/images/ic_thumbs_up.png',
                width: 100,
                height: 100,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget videoPlayer() {
    return _controller.value.isInitialized
        ? AspectRatio(
            aspectRatio: _controller.value.aspectRatio,
            child: VideoPlayer(_controller))
        : Stack(
          children: [
            CachedNetworkImage(
              imageUrl: widget.video!.getThumbnail!.url!,
                  imageBuilder: (context, imageProvider) => Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      image: DecorationImage(image: imageProvider,
                          fit: BoxFit.fitWidth),
                    ),
                  ),
                  placeholder: (context, url) => MainHelper.appLoading(),
                  errorWidget: (context, url, error) => MainHelper.appLoading()
            ),
            //MainHelper.appLoading(),
          ],
        );
  }

  Widget btnActions() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      ContainerCorner(
        onTap: () => MainHelper.goBackToPreviousPage(context),
        width:size.width/8,
        height:size.width/8,
        marginLeft: 10,
        marginRight: 10,
        marginTop:16,
        marginBottom:16,
        color: kButtonTextColor,
        borderRadius: 50,
        child: Center(
          child: Icon(Icons.close, size: size.width/13,color: kContentColorDarkTheme,),
        ),
      ),
      /*!widget.currentUser!.getIsViewer!
          ? actionButton(Icons.copy, startChallenge)
          : const SizedBox(),*/
      // actionButton(Icons.flag, report),
      // actionButton(Icons.block, showBlockContentAlert),
      actionButton(Icons.thumb_up, likeVideo),
      actionButton(Icons.chat, showVideoComments),
      // actionButton('assets/svg/ic_app_views_videos.svg', showAllRepropose),
      actionButton(Icons.more_horiz, shareVideo),
    ] // List.generate(imagesPath.length, (index) => action(imagesPath[index], (){})),
        );
  }

  Widget action(String imagePath, VoidCallback action) {
    return GestureDetector(
      onTap: action,
      child: SvgPicture.asset(
        imagePath,
        height: size.width / 5,
        width: size.width / 5,
        color: kButtonTextColor,
      ),
    );
  }

  Widget actionButton(IconData icon, VoidCallback action) {
    return ContainerCorner(
      onTap: action,
      width:size.width/8,
      height:size.width/8,
      marginLeft: 10,
      marginRight: 10,
      marginTop:16,
      marginBottom:16,
      color: kButtonTextColor,
      borderRadius: 50,
      child: Center(
        child: Icon(icon, size: size.width/15,color: kContentColorDarkTheme,),
      ),
    );
  }

  Widget audienceBottom() {
    return ContainerCorner(
      alignment: Alignment.bottomCenter,
      marginBottom: MediaQuery.of(context).viewInsets.bottom,
      color: Colors.transparent,
      child: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            videoComments(),
            chatInputField(),
          ],
        ),
      ),
    );
  }

  Widget chatInputField() {
    return ContainerCorner(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ContainerCorner(
              color: kTransparentColor,
              borderColor: kContentColorDarkTheme,
              borderRadius: 50,
              marginLeft: 10,
              marginRight: 10,
              child: Padding(
                padding: const EdgeInsets.only(left: 10),
                child: TextField(
                  keyboardType: TextInputType.multiline,
                  style: GoogleFonts.nunito(
                    color: Colors.white,
                  ),
                  onChanged: (text) {
                    if (text.isNotEmpty) {
                      toggleSendButton(true);
                    } else {
                      toggleSendButton(false);
                    }
                  },
                  focusNode: chatTextFieldFocusNode,
                  minLines: 1,
                  maxLines: 2,
                  controller: textEditingController,
                  decoration: InputDecoration(
                    hintText: "comment_post.leave_comment".tr(),
                    hintStyle: GoogleFonts.nunito(color: Colors.white),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
          ),
          Visibility(
            visible: _hideSendButton,
            child: ContainerCorner(
              marginRight: 10,
              marginTop: 3.5,
              color: kPrimaryColor,
              borderRadius: 50,
              height: 45,
              width: 45,
              onTap: () {
                if (textEditingController.text.isNotEmpty) {
                  sendComment(textEditingController.text, widget.currentUser!,
                      widget.video!);
                  setState(() {
                    textEditingController.text = "";
                    visibleKeyBoard = false;
                  });
                  toggleSendButton(false);
                  MainHelper.removeFocusOnTextField(context);
                }
              },
              child: ContainerCorner(
                color: kTransparentColor,
                marginAll: 5,
                height: 30,
                width: 30,
                child: SvgPicture.asset(
                  "assets/svg/ic_send_message.svg",
                  color: Colors.white,
                  height: 10,
                  width: 30,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget videoComments() {
    QueryBuilder<VideoCommentModel> queryBuilder =
        QueryBuilder<VideoCommentModel>(VideoCommentModel());
    queryBuilder.whereEqualTo(
        VideoCommentModel.keyVideoId, widget.video!.objectId);

    queryBuilder.includeObject([
      VideoCommentModel.keyAuthor,
      VideoCommentModel.keyVideo,
    ]);

    queryBuilder.orderByDescending(VideoCommentModel.keyCreatedAt);

    var size = MediaQuery.of(context).size;
    return ContainerCorner(
      color: kTransparentColor,
      marginLeft: 10,
      marginRight: 10,
      height: size.height*0.19,
      width: size.width / 1.3,
      marginBottom: 15,
      //color: kTransparentColor,
      child: ParseLiveListWidget<VideoCommentModel>(
        query: queryBuilder,
        reverse: true,
        duration: const Duration(microseconds: 500),
        childBuilder: (BuildContext context,
            ParseLiveListElementSnapshot<VideoCommentModel> snapshot) {
          if (snapshot.failed) {
            return Text('not_connected'.tr());
          } else if (snapshot.hasData) {
            VideoCommentModel videoComment = snapshot.loadedData!;

            return getComments(videoComment);
          } else {
            return Container();
          }
        },
      ),
    );
  }

  Widget getComments(VideoCommentModel videoComment) {
    return commentAvatar(nameOrYou(videoComment), videoComment.getText!,
        user: videoComment.getAuthor!);
  }

  String nameOrYou(VideoCommentModel videoComment) {
    if (videoComment.getAuthorId == widget.currentUser!.objectId) {
      return "live_streaming.you_".tr();
    } else {
      return videoComment.getAuthor!.getFullName!;
    }
  }

  Widget commentAvatar(String title, String message, {UserModel? user}) {
    return ContainerCorner(
      borderRadius: 50,
      marginBottom: 5,
      //colors: [Colors.black.withOpacity(0.5), Colors.black.withOpacity(0.02)],
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ContainerCorner(
            width: 50,
            height: 50,
            color: kTransparentColor,
            borderRadius: 50,
            marginRight: 10,
            onTap: () {
              if (user != null) {
                //openBottomSheet(_showTheUser(widget.mChallengeModel!.getAuthor!));
              }
            },
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:user!, fontSize: 10),
          ),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom:3.0,top:10.0),
                  child: RichText(
                      text: TextSpan(children: [
                    TextSpan(
                      text: title,
                      style: const TextStyle(
                        color: kContentColorDarkTheme,
                        fontSize: 13.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ])),
                ),
                RichText(
                  text: TextSpan(children: [
                    TextSpan(
                      text: message,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 11.8
                      ),
                    ),
                  ])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  sendComment(String text, UserModel author, VideoModel video) async {
    VideoCommentModel videoCommentModel = VideoCommentModel();

    videoCommentModel.setAuthor = author;
    videoCommentModel.setAuthorId = author.objectId!;
    videoCommentModel.setVideo = video;
    videoCommentModel.setVideoId = video.objectId!;
    videoCommentModel.setText = text;

    await videoCommentModel.save().then((value) async {
      widget.video!.setComments = value.results?.first.objectId;
      await widget.video!.save();
    });
  }

  addViews() async {
    if (!widget.video!.getViews!.contains(widget.currentUser!.objectId)) {
      widget.video!.setViews = widget.currentUser!.objectId.toString();
    }

    viewsCount = widget.video!.getViewsCount ?? 0;
    widget.video!.setViewsCount = viewsCount + 1;

    await widget.video!.save();
    // MainHelper.showAppNotificationAdvanced(title: '$viewsCount', context: context);
  }

  likeVideo() async {
    if (!widget.video!.getLikes!.contains(widget.currentUser!.objectId!)) {
      widget.video!.setLikes = widget.currentUser!.objectId!;
      await widget.video!.save();
      setState(() {
        isLiked = true;
      });

      showThumbsUp();
    } else {
      widget.video!.removeLike = widget.currentUser!.objectId!;
      await widget.video!.save();
      setState(() {
        isLiked = false;
      });

      showThumbsDown();
    }
  }

  showVideoComments() {
    setState(() {
      _showChat = !_showChat;
    });
  }

  showAllRepropose() {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: false,
        backgroundColor: kPrimaryColor,// Colors.black.withOpacity(0.4),
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return Column(
            children: [
              GestureDetector(
                onTap: () => MainHelper.hideLoadingDialog(context),
                child: const Align(
                  alignment: Alignment.topRight,
                  child: Icon(Icons.close,color: kContentColorDarkTheme,),
                ),
              ),
              Expanded(
                  child: AllChallengeRePropose(
                    context,
                    currentUser: widget.currentUser,
                    video: widget.video,
                    videoController: _controller,
                  ),
              ),
          ]
          );
        });
  }

  showBlockContentAlert(){
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "video.block_content_confirm".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "confirm_"
                              .tr()
                              .toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          blockContent(widget.video!);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  blockContent(VideoModel video) async {
    MainHelper.hideLoadingDialog(context);
    MainHelper.showLoadingDialog(context);

    widget.currentUser!.setBlockedContentIds = widget.video!.objectId!;
    ParseResponse response = await widget.currentUser!.save();

    if(response.success){
      MainHelper.hideLoadingDialog(context);

      Wakelock.disable();
      _controller.dispose();

      MainHelper.goToNavigatorScreen(
        context,
        HomePage(
          currentUser: widget.currentUser,
        ),
        back: false,
        finish: true,
      );
    }else{
      MainHelper.hideLoadingDialog(context);

      MainHelper.showAppNotificationAdvanced(
        title: 'video.something_wrong'.tr(),
        context: context,
        isError: false,
      );
    }
  }

  Widget noViewersMessage() {
    return Center(
      child: TextWithTap(
        'video.no_viewers'.tr(),
        fontSize: size.width / 19,
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget notConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 17,
        textAlign: TextAlign.center,
      ),
    );
  }

  shareVideo() {
    showModalBottomSheet(
      context: (context),
      isScrollControlled: false,
      backgroundColor: kTransparentColor,// Colors.black.withOpacity(0.4),
      enableDrag: false,
      builder: (context) {
        return Align(
          alignment: Alignment.bottomCenter,
          child: ContainerCorner(
            width: size.width,
            height: size.height*0.5,
            child: Stack(
              children: [
                ContainerCorner(
                  borderWidth: 0,
                  color: Colors.black.withOpacity(0.4),
                  width: size.width,
                  height: size.height*0.5,
                  radiusTopRight: 25,
                  radiusTopLeft: 25,
                  imageDecoration: "assets/images/app_bg.png",
                ),
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(25),
                    topLeft: Radius.circular(25),
                  ),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                    child: ContainerCorner(
                        color: kTransparentColor,
                        height: size.height,
                        width: size.width),
                  ),
                ),
                ListView(
                  children: [
                    GestureDetector(
                      onTap: () => MainHelper.hideLoadingDialog(context),
                      child: const Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                          padding: EdgeInsets.only(right:8.0,top:8.0),
                          child: Icon(Icons.close,color: kContentColorDarkTheme,),
                        ),
                      ),
                    ),
                    ContainerCorner(
                      marginRight: size.width/13,
                      marginLeft: size.width/13,
                      marginTop: size.height/36,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          shareButtonAction('video.report'.tr(), 'assets/svg/ic_flag_report.svg', report),
                          shareButtonAction('video.block'.tr(), 'assets/svg/ic_block.svg', showBlockContentAlert),
                          shareButtonAction('video.save'.tr(), 'assets/svg/ic_save.svg', save),
                          shareButtonAction('video.download'.tr(), 'assets/svg/ic_donwload.svg', download),
                          //shareButtonAction('video.send'.tr(), 'assets/svg/ic_send.svg', send),
                          shareButtonAction('video.url'.tr(), 'assets/svg/ic_url.svg', copyUrl),
                        ],
                      )
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      });
  }

  Widget shareButtonAction(String text, String imagePath, VoidCallback action){
    return ContainerCorner(
      marginBottom: 20,
      onTap: action,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SvgPicture.asset(imagePath,width:size.width/13,height:size.width/13,color:Colors.white),
          TextWithTap(text,color: kContentColorDarkTheme,fontSize: 15,marginLeft: size.width/24,),
        ],
      ),
    );
  }

  save() async {
    MainHelper.hideLoadingDialog(context);

    widget.currentUser!.setSaves = widget.video!.objectId!;
    await widget.currentUser!.save();

    MainHelper.showAppNotificationAdvanced(
      title:'video.save_message'.tr(),
      context: context,
      isError: false,
    );
  }

  checkPermission() async {
    if (MainHelper.isMobile()) {
      if (await Permission.storage.isGranted) {
        downloadFile();
      } else if (await Permission.storage.isDenied) {
        MainHelper.showDialogPermission(
            context: context,
            title: "permissions.download_access".tr(),
            confirmButtonText: "permissions.okay_".tr().toUpperCase(),
            message: "permissions.download_access_explain"
                .tr(namedArgs: {"app_name": Setup.appName}),
            onPressed: () async {
              MainHelper.hideLoadingDialog(context);

              // You can request multiple permissions at once.
              Map<Permission, PermissionStatus> statuses =
              await [Permission.storage].request();

              if (statuses[Permission.storage]!.isGranted) {
                downloadFile();
              } else {
                MainHelper.showAppNotificationAdvanced(
                    title: "permissions.download_access_denied".tr(),
                    message: "permissions.download_access_denied_explain"
                        .tr(namedArgs: {"app_name": Setup.appName}),
                    context: context,
                    isError: true);
              }
            });
      } else if (await Permission.storage.isPermanentlyDenied) {
        openAppSettings();
      }
    } else {
      downloadFile();
    }
  }

  downloadFile() async {
    var dir = await DownloadsPath.downloadsDirectory();

    if(dir != null){
      String randomNumbers = MainHelper.generateRandomNnumbers();
      String saveName = "deified_video_$randomNumbers.mp4";
      String savePath = "${dir.path}/$saveName";

      try {
        await Dio().download(
            widget.video!.getVideo != null
                ? '${widget.video!.getVideo!.url}'
                : '${widget.video!.getUrl}',
            savePath,
            onReceiveProgress: (received, total) {
              /*if (total != -1) {
                print((received / total * 100).toStringAsFixed(0) + "%");
                //you can build progressbar feature too
              }*/
            });
        // print("File is saved to download folder.");
      } on DioError {
        MainHelper.showAppNotificationAdvanced(
            title: "download_failed".tr(),
            message: "download_failed_explain".tr(),
            context: context,
            isError: true);
      }
    }
  }

  download() {
    MainHelper.hideLoadingDialog(context);
    checkPermission();
  }

  send() { // the url will be replaced by a dynamic link
    Share.share("settings_screen.share_app_url".tr(namedArgs: {
      "app_name": Config.appName,
      "url": shareUrl.toString(),
    }));
  }

  copyUrl() {
    FlutterClipboard.copy(
        widget.video!.getVideo != null
            ? '${widget.video!.getVideo!.url}'
            : '${widget.video!.getUrl}'
    ).then(( value ) {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title:'video.url_copied'.tr(),
        context: context,
        isError: false,
      );
    });
  }

  startChallenge() {
    MainHelper.showDialogLivEend(
      context: context,
      title: 'video.video'.tr(),
      confirmButtonText: 'yes'.tr(),
      message: 'video.start_challenge_message'.tr(),
      onPressed: () {
        reProposeChallenge();
      },
    );
  }

  reProposeChallenge(){
    ChallengeModel newChallenge = ChallengeModel();

    newChallenge.setAuthor = widget.currentUser!;
    newChallenge.setAuthorId = widget.currentUser!.objectId!;

    newChallenge.setChallenger = widget.video!.getAuthor!;
    newChallenge.setChallengerId = widget.video!.getAuthor!.objectId!;

    newChallenge.setChallengerVideo = widget.video!;
    newChallenge.setChallengerVideoId = widget.video!.objectId!;

    getOriginalChallenge(newChallenge);
  }

  getOriginalChallenge(ChallengeModel newChallenge) async {
    ChallengeModel originalChallenge = ChallengeModel();

    QueryBuilder<ChallengeModel> authorVideoQuery =
    QueryBuilder<ChallengeModel>(ChallengeModel());
    authorVideoQuery.whereEqualTo(
        ChallengeModel.keyAuthorVideoId, widget.video!.objectId);

    QueryBuilder<ChallengeModel> challengerVideoQuery =
    QueryBuilder<ChallengeModel>(ChallengeModel());
    challengerVideoQuery.whereEqualTo(
        ChallengeModel.keyChallengerVideoId, widget.video!.objectId);

    QueryBuilder<ParseObject>query = QueryBuilder.or(
      ChallengeModel(),
      [authorVideoQuery, challengerVideoQuery],
    );

    query.includeObject([
      ChallengeModel.keyAuthor,
      ChallengeModel.keyChallenger,
      ChallengeModel.keyLiveStreaming,
      ChallengeModel.keyAuthorVideo,
      ChallengeModel.keyChallengerVideo
    ]);
    ParseResponse response = await query.query();

    if(response.success){
      if(response.results != null){
         originalChallenge = response.results?.first! as ChallengeModel;

         newChallenge.setMode = originalChallenge.getMode!;

         if(originalChallenge.getMode == ChallengeModel.mode1VS1){
           newChallenge.setCategory = originalChallenge.getCategory!;
           newChallenge.setDuration = originalChallenge.getDuration!;
           newChallenge.setExpireDate = MainHelper.getUntilDateFromMinutes(originalChallenge.getDuration!);
         }

         Wakelock.disable();
         _controller.dispose();

         MainHelper.hideLoadingDialog(context);

         MainHelper.goToNavigatorScreen(
           context,
           UploadVideoPage(
             currentUser: widget.currentUser,
             originalChallenge: originalChallenge,
             challenge: newChallenge,
             isRePropose: true,
           ),
         );
      }
    }
  }

  report() {
    showModalBottomSheet(
      context: (context),
      isScrollControlled: true,
      backgroundColor: kTransparentColor,// Colors.black.withOpacity(0.4),
      enableDrag: true,
      isDismissible: true,
      builder: (context) {
        return _showPostOptionsAndReportAuthor();
      });
  }

  Widget _showPostOptionsAndReportAuthor() {
    List<dynamic> reportReason = [
      ReportModel.thisPosHasSexualContents,
      ReportModel.fakeProfileSpan,
      ReportModel.inappropriateMessage,
      ReportModel.someoneIsInDanger,
    ];

    return GestureDetector(
      onTap: () => MainHelper.goBackToPreviousPage(context),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        height: size.height,
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: size.height <= 570 ? 0.6 : 0.5,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                var size = MediaQuery.of(context).size;
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Stack(
                    children: [
                      ContainerCorner(
                        borderWidth: 0,
                        color: Colors.black.withOpacity(0.4),
                        width: size.width,
                        height: size.height,
                        radiusTopRight: 25,
                        radiusTopLeft: 25,
                        imageDecoration: "assets/images/app_bg.png",
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(25),
                          topLeft: Radius.circular(25),
                        ),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: ContainerCorner(
                              color: kTransparentColor,
                              height: size.height,
                              width: size.width),
                        ),
                      ),
                      Scaffold(
                        backgroundColor: kTransparentColor,
                        appBar: AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kTransparentColor,
                          centerTitle: true,
                          actions: [
                            IconButton(
                                onPressed: () =>
                                    MainHelper.goBackToPreviousPage(context),
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 25,
                                ))
                          ],
                          title: TextWithTap(
                            "video.report_reason_title".tr(),
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        body: ContainerCorner(
                          radiusTopRight: 20.0,
                          radiusTopLeft: 20.0,
                          color: kTransparentColor,
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: List.generate(
                                  reportReason.length,
                                  (index) => Column(
                                    children: [
                                      ButtonWithIcon(
                                        text: MainHelper.getReportMessage(reportReason[index]),
                                        iconColor: kPrimaryColor,
                                        height: 50,
                                        marginLeft: 10,
                                        marginRight: 10,
                                        backgroundColor: Colors.white.withOpacity(0.1),
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        textColor: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w500,
                                        onTap: () {
                                          createReport(MainHelper.getReportMessage(reportReason[index]));
                                        },
                                      ),
                                      const Divider(),
                                    ],
                                  )
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  createReport(String message) async {
    MainHelper.showLoadingDialog(context);

    ReportModel report = ReportModel();

    report.setAccuser = widget.currentUser!;
    report.setAccusedId = widget.currentUser!.objectId!;

    report.setAccused = widget.video!.getAuthor!;
    report.setAccuserId = widget.video!.getAuthor!.objectId!;

    report.setVideo = widget.video!;
    report.setVideoId = widget.video!.objectId!;

    report.setMessage = message;

    ParseResponse response = await report.save();

    if(response.success){
      widget.currentUser!.setReportedVideos = widget.video!.objectId!;
      widget.currentUser!.save();

      MainHelper.hideLoadingDialog(context);
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title:'report_message'.tr(),
        context: context,
        isError: false,
      );
    }else{
      MainHelper.hideLoadingDialog(context);
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title:'video.report_failed_title'.tr(),
        message: 'video.report_failed_message'.tr(),
        context: context,
        isError: true,
      );
    }
  }
}