// ignore_for_file: library_private_types_in_public_api

import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/livestreaming_pages/live_creation_page.dart';
import 'package:challenge/pages/home/livestreaming_pages/live_streaming_page.dart';
import 'package:challenge/pages/home/notifications_pages/notifications_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_edit_page.dart';
import 'package:challenge/pages/home/search_pages/search_user_challenge_page.dart';
import 'package:challenge/pages/home/video_pages/watch_video_page.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../configurations/global_setup.dart';
import '../../../models/NotificationsModel.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../../../widgets/custome_drawer.dart';
import '../audio_live_page/audio_live_page.dart';
import '../profile_pages/profile_page.dart';

class AllVideosPage extends StatefulWidget {
  static const String route = "/Video/Random";
  final UserModel? currentUser;
  const AllVideosPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _AllVideosPageState createState() => _AllVideosPageState();
}

class _AllVideosPageState extends State<AllVideosPage> with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;
  AnimationController? _animationController;
  List<dynamic> challengesList = [];

  int notifications = 0;
  LiveQuery liveQuery = LiveQuery();
  Subscription? subscription;

  late SharedPreferences sharedPreferences;

  _initPreferences() async {
    sharedPreferences = await SharedPreferences.getInstance();
  }

  @override
  void initState() {
    _animationController = AnimationController.unbounded(vsync: this);
    super.initState();

    checkUserNotifications();
    setupControlLiveQuery();
    _initPreferences();
  }

  checkUserNotifications() async {
    QueryBuilder<NotificationsModel> query = QueryBuilder<NotificationsModel>(NotificationsModel());
    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(NotificationsModel.keyRead, false);
    query.whereEqualTo(NotificationsModel.keyReceiverId, widget.currentUser!.objectId);

    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        setState((){
          notifications = parseResponse.results!.length;
        });
      }
    }
  }

  Future<void> checkPermissionAudio(bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) async {
    if (MainHelper.isAndroidPlatform()) {
      PermissionStatus status = await Permission.storage.status;
      PermissionStatus status2 = await Permission.camera.status;
      PermissionStatus status3 = await Permission.microphone.status;
      if (kDebugMode) {
        print('Permission android');
      }

      checkStatusAudio(status, status2, status3, isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    } else if (MainHelper.isIOSPlatform()) {
      PermissionStatus status = await Permission.photos.status;
      PermissionStatus status2 = await Permission.camera.status;
      PermissionStatus status3 = await Permission.microphone.status;
      if (kDebugMode) {
        print('Permission ios');
      }

      checkStatusAudio(status, status2, status3, isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    } else {
      if (kDebugMode) {
        print('Permission other device');
      }
      _gotoLiveScreenAudio(isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    }
  }

  void checkStatusAudio(PermissionStatus status, PermissionStatus status2,
      PermissionStatus status3, bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) {
    if (status.isDenied || status2.isDenied || status3.isDenied) {
      // We didn't ask for permission yet or the permission has been denied before but not permanently.

      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access".tr(),
          confirmButtonText: "permissions.okay_".tr().toUpperCase(),
          message: "permissions.photo_access_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () async {
            MainHelper.hideLoadingDialog(context);
            //if (await Permission.camera.request().isGranted) {
            // Either the permission was already granted before or the user just granted it.
            //}
            // You can request multiple permissions at once.
            Map<Permission, PermissionStatus> statuses = await [
              Permission.camera,
              Permission.photos,
              Permission.storage,
              Permission.microphone,
            ].request();

            if (statuses[Permission.camera]!.isGranted &&
                statuses[Permission.photos]!.isGranted ||
                statuses[Permission.storage]!.isGranted ||
                statuses[Permission.microphone]!.isGranted) {
              _gotoLiveScreenAudio(isBroadcaster,
                  channel: channel, liveStreamingModel: liveStreamingModel);
            }
          });
    } else if (status.isPermanentlyDenied ||
        status2.isPermanentlyDenied ||
        status3.isPermanentlyDenied) {
      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access_denied".tr(),
          confirmButtonText: "permissions.okay_settings".tr().toUpperCase(),
          message: "permissions.photo_access_denied_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () {
            MainHelper.hideLoadingDialog(context);

            openAppSettings();
          });
    } else if (status.isGranted && status2.isGranted && status3.isGranted) {
      //_uploadPhotos(ImageSource.gallery);
      _gotoLiveScreenAudio(isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    }

    if (kDebugMode) {
      print('Permission $status');
      print('Permission $status2');
      print('Permission $status3');
    }

  }

  _gotoLiveScreenAudio(bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) async {
    if (widget.currentUser!.getAvatar == null) {
      MainHelper.showDialogLivEend(
        context: context,
        dismiss: true,
        title: 'live_streaming.photo_needed'.tr(),
        confirmButtonText: 'live_streaming.add_photo'.tr(),
        message: 'live_streaming.photo_needed_explain'.tr(),
        onPressed: () {
          MainHelper.goBackToPreviousPage(context);
          MainHelper.goToNavigatorScreen(
              context,
              ProfileEditPage(
                currentUser: widget.currentUser,
              ));
        },
      );
    } else {
      if (isBroadcaster) {
        // createLiveAudio();
      } else {
        if (liveStreamingModel!.getPrivate!) {
          if (!liveStreamingModel.getPrivateViewersId!
              .contains(widget.currentUser!.objectId!)) {
            // openPayPrivateLiveSheet(liveStreamingModel);
          } else {
            MainHelper.goToNavigatorScreen(
                context,
                AudioLivePage(
                  channelName: channel!,
                  isBroadcaster: false,
                  currentUser: widget.currentUser!,
                  mUser: liveStreamingModel.getAuthor,
                  isUserInvited: liveStreamingModel.getInvitedPartyUid!
                      .contains(widget.currentUser!.getUid!),
                  mLiveStreamingModel: liveStreamingModel,
                  preferences: sharedPreferences,
                ));
          }
        } else {
          MainHelper.goToNavigatorScreen(
              context,
              AudioLivePage(
                channelName: channel!,
                isBroadcaster: false,
                currentUser: widget.currentUser!,
                mUser: liveStreamingModel.getAuthor,
                isUserInvited: liveStreamingModel.getInvitedPartyUid!
                    .contains(widget.currentUser!.getUid!),
                mLiveStreamingModel: liveStreamingModel,
                preferences: sharedPreferences,
              ));
        }
      }
    }
  }

  Future<void> checkPermission(bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) async {
    if (MainHelper.isAndroidPlatform()) {
      PermissionStatus status2 = await Permission.camera.status;
      PermissionStatus status3 = await Permission.microphone.status;

      checkStatus(status2, status3, isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    } else if (MainHelper.isIOSPlatform()) {
      PermissionStatus status2 = await Permission.camera.status;
      PermissionStatus status3 = await Permission.microphone.status;

      checkStatus(status2, status3, isBroadcaster,
          channel: channel, liveStreamingModel: liveStreamingModel);
    }else {
        _gotoLiveScreen(isBroadcaster,
            channel: channel, liveStreamingModel: liveStreamingModel);
    }
  }

  void checkStatus(PermissionStatus status2,
      PermissionStatus status3, bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) {
    if (status2.isDenied || status3.isDenied) {
      // We didn't ask for permission yet or the permission has been denied before but not permanently.

      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access".tr(),
          confirmButtonText: "permissions.okay_".tr().toUpperCase(),
          message: "permissions.photo_access_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () async {
            MainHelper.hideLoadingDialog(context);

            //if (await Permission.camera.request().isGranted) {
            // Either the permission was already granted before or the user just granted it.
            //}

            // You can request multiple permissions at once.
            Map<Permission, PermissionStatus> statuses = await [
              Permission.camera,
              Permission.microphone,
            ].request();

            if (statuses[Permission.camera]!.isGranted &&
                statuses[Permission.microphone]!.isGranted) {

                _gotoLiveScreen(isBroadcaster,
                    channel: channel, liveStreamingModel: liveStreamingModel);

            }
          });
    } else if (status2.isPermanentlyDenied ||
        status3.isPermanentlyDenied) {
      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access_denied".tr(),
          confirmButtonText: "permissions.okay_settings".tr().toUpperCase(),
          message: "permissions.photo_access_denied_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () {
            MainHelper.hideLoadingDialog(context);

            openAppSettings();
          });
    } else if (status2.isGranted && status3.isGranted) {

        _gotoLiveScreen(isBroadcaster,
            channel: channel, liveStreamingModel: liveStreamingModel);

    }
  }

  Future<List<dynamic>?> _getChallenges() async {
    List<dynamic> randomVideosList = [];
    List<dynamic> livesStreamingList = [];

    QueryBuilder<VideoModel> query1 = QueryBuilder<VideoModel>(VideoModel());
    query1.includeObject([
      VideoModel.keyAuthor,
    ]);

    query1.whereEqualTo(VideoModel.keyCurrentState, VideoModel.videoCurrentStatePublished);
    query1.whereNotContainedIn(VideoModel.keyObjectId, widget.currentUser!.getReportedVideos!);
    query1.whereNotContainedIn(VideoModel.keyObjectId, widget.currentUser!.getBlockedContentIDs!);
    query1.whereNotContainedIn(VideoModel.keyAuthorId, widget.currentUser!.getBlockedUsersIDs!);
    query1.orderByDescending(VideoModel.keyCreatedAt);

    ParseResponse parseResponse = await query1.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        for (VideoModel videoModel in parseResponse.results!) {
          if (!randomVideosList.contains(videoModel.objectId)) {
            randomVideosList.add(videoModel.objectId);
          }
        }
      }
    }

    QueryBuilder<LiveStreamingModel> queryBuilder =
    QueryBuilder<LiveStreamingModel>(LiveStreamingModel());

    queryBuilder.includeObject([
      LiveStreamingModel.keyAuthor,
      LiveStreamingModel.keyAuthorInvited,
      LiveStreamingModel.keyPrivateLiveGift
    ]);

    queryBuilder.whereEqualTo(LiveStreamingModel.keyStreaming, true);
    queryBuilder.whereNotEqualTo(
        LiveStreamingModel.keyAuthorUid, widget.currentUser!.getUid);
    queryBuilder.whereNotContainedIn(
        LiveStreamingModel.keyAuthorId, widget.currentUser!.getBlockedUsersIDs!);
    queryBuilder.whereValueExists(LiveStreamingModel.keyAuthor, true);

    ParseResponse parseResponse2 = await queryBuilder.query();

    if (parseResponse2.success) {
      if (parseResponse2.result != null) {
        for (LiveStreamingModel liveStreamingModel in parseResponse2.results!) {
          if (!livesStreamingList.contains(liveStreamingModel.objectId)) {
            livesStreamingList.add(liveStreamingModel.objectId);
          }
        }
      }
    }

    QueryBuilder<ChallengeModel> queryVideo = QueryBuilder<ChallengeModel>(ChallengeModel());
    queryVideo.includeObject([
      ChallengeModel.keyAuthor,
      ChallengeModel.keyAuthorVideo,
      ChallengeModel.keyLiveStreaming
    ]);
    queryVideo.whereContainedIn(ChallengeModel.keyAuthorVideoId, randomVideosList);

    QueryBuilder<ChallengeModel> queryLive = QueryBuilder<ChallengeModel>(ChallengeModel());
    queryLive.includeObject([
      ChallengeModel.keyAuthor,
      ChallengeModel.keyAuthorVideo,
      ChallengeModel.keyLiveStreaming
    ]);
    queryLive.whereContainedIn(ChallengeModel.keyLiveStreamingId  , livesStreamingList);

    QueryBuilder<ChallengeModel> query = QueryBuilder.or(
      ChallengeModel(),
      [queryVideo, queryLive],
    );
    query.includeObject([
      ChallengeModel.keyAuthor,
      ChallengeModel.keyAuthorVideo,
      ChallengeModel.keyLiveStreaming
    ]);
    query.orderByDescending(ChallengeModel.keyCreatedAt);

    ParseResponse apiResponse = await query.query();

    if (apiResponse.success) {
      if (apiResponse.results != null) {
        return apiResponse.results;
      } else {
        return const AsyncSnapshot.nothing() as List<dynamic>;
      }
    } else {
      return apiResponse.error as dynamic;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      endDrawer: CustomDrawer(currentUser: widget.currentUser),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: kTransparentColor,
        leading: ContainerCorner(
          onTap: () {
            MainHelper.goToNavigatorScreen(
              context,
              ProfilePage(
                currentUser: widget.currentUser!,
              ),
              back: true,
            );
          },
          width: size.width / 30,
          height: size.width / 30,
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, top: 4.5, bottom: 4.5),
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:widget.currentUser!,
                fontSize: 13),
          ),
        ),
        titleSpacing: 2.0,
        title: TextWithTap(
          widget.currentUser!.getUsername!,
          fontSize: 13,
          color: kContentColorDarkTheme,
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                onPressed: (){
                  MainHelper.goToNavigatorScreen(
                      context,
                      SearchPage(
                        currentUser: widget.currentUser,
                      ));
                },
                icon: SvgPicture.asset('assets/svg/ic_app_search.svg',
                  color: Colors.white,
                ),
              ),
            ],
          ),
          Stack(
            children: [
              IconButton(
                onPressed: (){
                  MainHelper.goToNavigatorScreen(
                    context,
                    NotificationsPage(currentUser: widget.currentUser!),
                  );
                },
                icon: SvgPicture.asset('assets/svg/ic_notifications.svg',
                  width: 22,
                  height: 22,
                  color:Colors.white,
                ),
              ),
              Visibility(
                visible: notifications != 0,
                child: const Positioned(
                    top: 11,
                    right: 13,
                    child: ContainerCorner(
                      width: 9.5,
                      height: 9.5,
                      borderRadius: 50,
                      color: Colors.red,
                    )),
              ),
            ],
          ),
          Builder(builder: (ctx) {
            return ContainerCorner(
              onTap: () => Scaffold.of(ctx).openEndDrawer(),
              imageDecoration: "assets/images/top_btn.png",
              width: size.width / 7,
              height: size.height / 5,
            );
          }),
        ],
      ),
      body:getBody(),
    );
  }

  Widget getBody(){
    return ContainerCorner(
      borderWidth: 0,
      height: size.height,
      width: size.width,
      imageDecoration: "assets/images/app_bg.png",
      child: SafeArea(child: showAllChallenges()),// _getRandomVideos(),
    );
  }

  Widget showAllChallenges(){
    return FutureBuilder(
      future: _getChallenges(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          Center(
            child: MainHelper.appLoading(),
          );
        } else if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasData) {
            challengesList = snapshot.data as List<dynamic>;

            return GridView.builder(
              itemCount:challengesList.length,
                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: size.width*0.5,
                  mainAxisExtent: size.height*0.35,
                  childAspectRatio: 1.0,
                  crossAxisSpacing: 0,
                  mainAxisSpacing: 0,
              ),
              itemBuilder: (context, index){

                ChallengeModel challenge = challengesList[index];

                if(challenge.getMode == ChallengeModel.modeLIVESTREAMING){

                  LiveStreamingModel liveStreaming = challenge.getLiveStreaming!;
                  return FutureBuilder(
                    future: getLiveStreaming(liveStreaming),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        Center(
                          child: MainHelper.appLoading(),
                        );
                      } else if (snapshot.connectionState == ConnectionState.done) {
                        if (snapshot.hasData) {
                          liveStreaming = snapshot.data as LiveStreamingModel;

                          return GestureDetector(
                            onTap: () {

                              if(liveStreaming.getLiveType
                                == LiveStreamingModel.liveVideo){
                                checkPermission(false,
                                    channel: liveStreaming.getStreamingChannel,
                                    liveStreamingModel: liveStreaming);
                              }else{
                                if (liveStreaming.getRemovedUserIds!
                                    .contains(widget.currentUser!.objectId)) {
                                  MainHelper.showAppNotificationAdvanced(
                                    title: "audio_chat.cannot_access_room_title".tr(),
                                    context: context,
                                    message: "audio_chat.cannot_access_room_explain".tr(),
                                  );
                                } else {
                                  checkPermissionAudio(false,
                                      channel: liveStreaming.getStreamingChannel,
                                      liveStreamingModel: liveStreaming);
                                }
                              }

                            },
                            child: Stack(children: [
                              ContainerCorner(
                                borderWidth: 0,
                                color: kTransparentColor,
                                child: ActionsHelper.photosWidget(liveStreaming.getImage!.url!,
                                    width:double.infinity, height:size.height*0.59,borderRadius: 0),
                              ),
                              Positioned(
                                top: 5,
                                left: 4,
                                child:Row(
                                  children: [
                                    ContainerCorner(
                                      width: 50,
                                      height: 25,
                                      color: kButtonTextColor,
                                      borderRadius: 5,
                                      marginRight: 5,
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          TextWithTap(
                                            MainHelper.getViewersNumberFormated(
                                                liveStreaming.getViewers!.length),
                                            color: Colors.white,
                                            fontSize: 12,
                                            marginRight: size.width / 70,
                                          ),
                                          SvgPicture.asset(
                                            "assets/svg/ic_live_viewer.svg",
                                            width: 12,
                                            height: 12,
                                          ),
                                        ],
                                      ),
                                    ),
                                    ContainerCorner(
                                      width: liveStreaming.getLiveType
                                          == LiveStreamingModel.liveVideo
                                          ? 60
                                          : 105,
                                      height: 25,
                                      color: kPrimaryColor,
                                      borderRadius: 5,
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          ContainerCorner(
                                            height: 8,
                                            width: 8,
                                            color: Colors.white,
                                            borderRadius: 50,
                                            marginRight: size.width / 70,
                                          ),
                                          TextWithTap(
                                              liveStreaming.getLiveType
                                                  == LiveStreamingModel.liveVideo
                                              ? "live_streaming.live_".tr().toUpperCase()
                                              : "live_streaming.audio_".tr().toUpperCase(),
                                            color: Colors.white,
                                            fontSize: 12,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ]),
                          );

                        } else if (snapshot.hasError) {
                          return noChallengeMessage();
                        } else {
                          return Center(
                            child: MainHelper.appLoading(),
                          );
                        }
                      } else {
                        return Center(
                          child: MainHelper.appLoading(),
                        );
                      }

                      return Center(
                        child: MainHelper.appLoading(),
                      );
                    },
                  );

                }else{

                  VideoModel video = challenge.getAuthorVideo!;
                  return FutureBuilder(
                    future: getVideo(video),
                    builder: (BuildContext context, AsyncSnapshot snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        Center(
                          child: MainHelper.appLoading(),
                        );
                      } else if (snapshot.connectionState == ConnectionState.done) {
                        if (snapshot.hasData) {
                          video = snapshot.data as VideoModel;

                          return GestureDetector(
                            onTap: () => MainHelper.goToNavigatorScreen(
                              context,
                              WatchVideoPage(
                                currentUser: widget.currentUser!,
                                video: video,
                              ),
                            ),
                            child: Stack(
                                children: [
                                  ActionsHelper.videoThumbnailWidget(video, double.infinity, size.height*0.6),
                                  Positioned(
                                    bottom: 0.0,
                                    child: ContainerCorner(
                                      height: 20.0,
                                      width: size.width*0.5,
                                      color: Colors.black.withOpacity(0.3),
                                      child: TextWithTap(
                                        '${video.getDuration}',
                                        color: kContentColorDarkTheme,
                                        textAlign: TextAlign.end,
                                        marginRight: 5.0,
                                      ),
                                    ),
                                  ),
                                ]
                            ),
                          );

                        } else if (snapshot.hasError) {
                          return noChallengeMessage();
                        } else {
                          return Center(
                            child: MainHelper.appLoading(),
                          );
                        }
                      } else {
                        return Center(
                          child: MainHelper.appLoading(),
                        );
                      }

                      return Center(
                        child: MainHelper.appLoading(),
                      );
                    },
                  );

                }
              }
            );

          } else if (snapshot.hasError) {
            return noChallengeMessage();
          } else {
            return noChallengeMessage();
          }
        } else {
          return noChallengeMessage();
        }

        return Center(
          child: MainHelper.appLoading(),
        );
      },
    );
  }

  _gotoLiveScreen(bool isBroadcaster,
      {String? channel, LiveStreamingModel? liveStreamingModel}) async {
    if (widget.currentUser!.getAvatar == null) {
      MainHelper.showDialogLivEend(
        context: context,
        dismiss: true,
        title: 'live_streaming.photo_needed'.tr(),
        confirmButtonText: 'live_streaming.add_photo'.tr(),
        message: 'live_streaming.photo_needed_explain'.tr(),
        onPressed: () {
          MainHelper.goBackToPreviousPage(context);
          MainHelper.goToNavigatorScreen(
              context,
              ProfileEditPage(
                currentUser: widget.currentUser!,
              ));
        },
      );
    } else {
      if (isBroadcaster) {
        MainHelper.goToNavigatorScreen(
            context, LiveCreationPage(currentUser: widget.currentUser!));
      } else {
        if (liveStreamingModel!.getPrivate!) {
          if (!liveStreamingModel.getPrivateViewersId!
              .contains(widget.currentUser!.objectId!)) {
            // openPayPrivateLiveSheet(liveStreamingModel);
          } else {
            MainHelper.goToNavigatorScreen(
                context,
                LiveStreamingPage(
                  channelName: channel!,
                  isBroadcaster: false,
                  currentUser: widget.currentUser!,
                  mUser: liveStreamingModel.getAuthor,
                  mLiveStreamingModel: liveStreamingModel,
                ));
          }
        } else {
          MainHelper.goToNavigatorScreen(
              context,
              LiveStreamingPage(
                channelName: channel!,
                isBroadcaster: false,
                currentUser: widget.currentUser!,
                mUser: liveStreamingModel.getAuthor,
                mLiveStreamingModel: liveStreamingModel,
              ));
        }
      }
    }
  }

  Widget noChallengeMessage(){
    return Center(
      child: TextWithTap(
        'video.no_challenge'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: Colors.white,
      ),
    );
  }

  Widget noConnectedMessage(){
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
      ),
    );
  }

  Future<VideoModel> getVideo(VideoModel video) async {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());
    query.includeObject([
      VideoModel.keyAuthor,
    ]);
    query.whereEqualTo(VideoModel.keyObjectId, video.objectId);

    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        return parseResponse.results?.first as VideoModel;
      }
    }else {
      return video;
    }

    return video;
  }

  Future<LiveStreamingModel> getLiveStreaming(LiveStreamingModel liveStreaming) async {
    QueryBuilder<LiveStreamingModel> query =
    QueryBuilder<LiveStreamingModel>(LiveStreamingModel());

    query.includeObject([
      LiveStreamingModel.keyAuthor,
      LiveStreamingModel.keyAuthorInvited,
      LiveStreamingModel.keyPrivateLiveGift
    ]);
    query.whereEqualTo(LiveStreamingModel.keyObjectId, liveStreaming.objectId);

    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        return parseResponse.results?.first as LiveStreamingModel;
      }
    } else {
      return liveStreaming;
    }

    return liveStreaming;
  }

  Widget initQuery() {
    var size = MediaQuery.of(context).size;

    QueryBuilder<LiveStreamingModel> queryBuilder =
    QueryBuilder<LiveStreamingModel>(LiveStreamingModel());

    queryBuilder.includeObject([
      LiveStreamingModel.keyAuthor,
      LiveStreamingModel.keyAuthorInvited,
      LiveStreamingModel.keyPrivateLiveGift
    ]);

    queryBuilder.whereEqualTo(LiveStreamingModel.keyStreaming, true);
    queryBuilder.whereNotEqualTo(
        LiveStreamingModel.keyAuthorUid, widget.currentUser!.getUid);
    queryBuilder.whereNotContainedIn(
        LiveStreamingModel.keyAuthor, widget.currentUser!.getBlockedUsers!);
    queryBuilder.whereValueExists(LiveStreamingModel.keyAuthor, true);

    return Padding(
      padding: EdgeInsets.only(right: size.width / 30, left: size.width / 30),
      child: ParseLiveGridWidget<LiveStreamingModel>(
        query: queryBuilder,
        crossAxisCount: 2,
        reverse: false,
        crossAxisSpacing: size.width / 30,
        mainAxisSpacing: size.width / 30,
        lazyLoading: false,
        childAspectRatio: .8,
        shrinkWrap: true,
        listenOnAllSubItems: true,
        listeningIncludes: [
          LiveStreamingModel.keyAuthor,
          LiveStreamingModel.keyAuthorInvited,
        ],
        duration: const Duration(milliseconds: 200),
        animationController: _animationController,
        childBuilder: (BuildContext context,
            ParseLiveListElementSnapshot<LiveStreamingModel> snapshot) {
          if (snapshot.hasData) {
            LiveStreamingModel liveStreaming = snapshot.loadedData!;

            return GestureDetector(
              onTap: () {
                checkPermission(false,
                    channel: liveStreaming.getStreamingChannel,
                    liveStreamingModel: liveStreaming);
              },
              child: Stack(children: [
                ContainerCorner(
                  borderWidth: 0,
                  color: kTransparentColor,
                  child: ActionsHelper.photosWidget(liveStreaming.getImage!.url!,
                      borderRadius: 5),
                ),
                Visibility(
                  visible: liveStreaming.getPrivate!,
                  child: const Center(
                    child: Icon(
                      Icons.vpn_key,
                      color: Colors.white,
                      size: 35,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                            bottomRight: Radius.circular(5),
                            bottomLeft: Radius.circular(5)),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                          child: SizedBox(
                            height: 60,
                            width: (size.width / 2) - 1.5 * (size.width / 30),
                          ),
                        ),
                      ),
                      Positioned(
                        top: -20,
                        child: ActionsHelper.avatarWidget(
                          liveStreaming.getAuthor!,
                          height: 40,
                          width: 40,
                          margin: const EdgeInsets.only(left: 5, bottom: 5),
                        ),
                      ),
                      Positioned(
                        top: 22,
                        child: ContainerCorner(
                          color: Colors.black.withOpacity(0.1),
                          width: (size.width / 2) - 1.5 * (size.width / 30),
                          child: TextWithTap(liveStreaming.getAuthor!.getFullName!,
                            color: Colors.white,
                            overflow: TextOverflow.ellipsis,
                            marginLeft: 10,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: -3,
                        child: Row(children: [
                          SvgPicture.asset(
                            "assets/svg/ic_small_viewers.svg",
                            height: 15,
                          ),
                          TextWithTap(MainHelper.convertToK(liveStreaming.getViewersCount!),
                            color: Colors.white,
                            fontSize: 14,
                            marginLeft: 5,
                            marginRight: 5,
                          ),
                        ],),
                      ),
                    ],
                  ),
                )
              ]),
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
        queryEmptyElement: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: ActionsHelper.noContentFound(
              "live_streaming.no_live_title".tr(),
              "live_streaming.no_live_explain".tr(),
              "assets/svg/ic_tab_live_default.svg",
            ),
          ),
        ),
        gridLoadingElement: const Center(
          child: CircularProgressIndicator(),
        ),
      ),
    );
  }

  Widget getRandomVideos() {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(VideoModel.keyCurrentState, VideoModel.videoCurrentStatePublished);
    query.orderByDescending(VideoModel.keyCreatedAt);

    return ParseLiveGridWidget<VideoModel>(
      query: query,
      crossAxisCount: 2,
      reverse: false,
      crossAxisSpacing: 0,
      mainAxisSpacing: 0,
      lazyLoading: false,
      childAspectRatio: .7,
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      animationController: _animationController,
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<VideoModel> snapshot) {
        if (snapshot.failed) {

          return noConnectedMessage();

        } else if (snapshot.hasData) {

          VideoModel video = snapshot.loadedData!;
          return GestureDetector(
            onTap: () => MainHelper.goToNavigatorScreen(
              context,
              WatchVideoPage(
                currentUser: widget.currentUser!,
                video: video,
              ),
            ),
            child: Stack(
                children: [
                  ActionsHelper.videoThumbnailWidget(video, double.infinity, size.height*0.6),
                  Positioned(
                    bottom: 0.0,
                    child: ContainerCorner(
                      height: 20.0,
                      width: size.width*0.5,
                      color: Colors.black.withOpacity(0.3),
                      child: TextWithTap(
                        '${video.getDuration}',
                        color: kContentColorDarkTheme,
                        textAlign: TextAlign.end,
                        marginRight: 5.0,
                      ),
                    ),
                  ),
                ]
            ),
          );

        } else {

          return Center(
            child: MainHelper.appLoading(),
          );

        }
      },
      queryEmptyElement: noChallengeMessage(),
      gridLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  setupControlLiveQuery() async {
    QueryBuilder<NotificationsModel> query = QueryBuilder<NotificationsModel>(NotificationsModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(NotificationsModel.keyRead, false);
    query.whereEqualTo(NotificationsModel.keyReceiverId, widget.currentUser!.objectId);

    subscription = await liveQuery.client.subscribe(query);

    subscription!.on(LiveQueryEvent.update, (List<NotificationsModel> value) async {
      if(value.isNotEmpty){
        setState(() {
          notifications = value.length;
        });
      }
    });

    subscription!.on(LiveQueryEvent.enter, (List<NotificationsModel> value) {
      setState(() {});
    });
  }

}
