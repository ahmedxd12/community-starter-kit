// ignore_for_file: must_be_immutable, use_build_context_synchronously
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_svg/svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/video_pages/watch_video_page.dart';
import 'package:challenge/models/CategoryModel.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/NotificationsModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/widgets/custome_drawer.dart';

import '../../../configurations/global_config.dart';
import '../../../models/ReportModel.dart';
import '../../../utilities/helper_classes/cloud_helper.dart';
import '../../../widgets/custom_widgets/button_with_icon.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../message_pages/message_page.dart';
import '../settings_pages/blocked_users_page.dart';
import 'followers_page.dart';
import 'followings_page.dart';

class UserProfilePage extends StatefulWidget {
  UserModel? currentUser, mUser;

  UserProfilePage({Key? key, this.currentUser, this.mUser}) : super(key: key);

  static String route = '/user/profile';

  @override
  // ignore: library_private_types_in_public_api
  _UserProfilePageState createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage>
    with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;
  AnimationController? _animationController;
  bool isFollowing = false;

  int followers = 0;
  int following = 0;
  int challenges = 0;

  List<dynamic> allCategories = [];

  getAllCategories() async {
    QueryBuilder<CategoryModel> query = QueryBuilder(CategoryModel());
    query.orderByAscending(CategoryModel.keyName);

    ParseResponse response = await query.query();

    if (response.success) {
      if (response.result != null) {
        setState(() {
          allCategories = response.results as List<dynamic>;
        });
      }
    }
  }

  @override
  void initState() {
    _animationController = AnimationController.unbounded(vsync: this);

    getAllCategories();
    _getUserChallenges();
    super.initState();
  }


  _getUserChallenges() async {
    QueryBuilder<ChallengeModel> query = QueryBuilder(ChallengeModel());
    query.whereEqualTo(ChallengeModel.keyAuthorId, widget.mUser!.objectId);
    ParseResponse result = await query.query();

    if (result.success) {
      if (result.results != null) {
        setState(() {
          challenges = result.results!.length;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    isFollowing =
        widget.currentUser!.getFollowing!.contains(widget.mUser!.objectId!);
    followers = widget.mUser!.getFollowers!.length;
    followers = widget.mUser!.getFollowing!.length;

    return DefaultTabController(
      length: widget.mUser!.getIsViewer! ? 1 : 2,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        endDrawer: CustomDrawer(currentUser: widget.currentUser),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: kTransparentColor,
          leading: ContainerCorner(
            onTap: () => MainHelper.goBackToPreviousPage(context),
            width: size.width / 15,
            height: size.width / 15,
            marginLeft: 16,
            marginRight: 16,
            marginTop: 16,
            marginBottom: 16,
            color: kPrimaryColor,
            borderRadius: 50,
            child: Center(
              child: Icon(
                Icons.close,
                size: size.width / 25,
              ),
            ),
          ),
          actions: [
            Builder(builder: (ctx) {
              return ContainerCorner(
                onTap: () => Scaffold.of(ctx).openEndDrawer(),
                imageDecoration: "assets/images/top_btn.png",
                width: size.width / 7,
                height: size.height / 5,
              );
            }),
          ],
        ),
        body: getBody(),
      ),
    );
  }

  Widget getBody() {
    return Container(
      height: size.height,
      width: size.width,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/images/app_bg.png"),
          fit: BoxFit.cover,
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            right: size.width / 20,
            left: size.width / 20,
          ),
          child: widget.mUser!.getIsViewer!
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(bottom: size.height / 35),
                      child: showUserInfos(),
                    ),
                    Flexible(
                      fit: FlexFit.loose,
                      child: displayViewerTabs(),
                    ),
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    showUserInfos(),
                    showProgressBar(),
                    // showMedalsAndTrophies(),
                    Flexible(
                      fit: FlexFit.loose,
                      child: displayTabs(),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget line() {
    return ContainerCorner(
      borderWidth: 0.5,
      marginBottom: 7.0,
      marginTop: 7.0,
      borderColor: Colors.white,
      width: size.width,
    );
  }

  Widget button(String label, {double? fontSize, FontWeight? fontWeight}) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/images/white_btn.png'),
          fit: BoxFit.cover,
        ),
      ),
      height: size.height / 30,
      width: double.infinity,
      child: SizedBox(
        width: double.infinity,
        height: size.height / 30,
        child: TextWithTap(
          label,
          fontSize: fontSize ?? 10,
          fontWeight: fontWeight ?? FontWeight.w600,
          textAlign: TextAlign.center,
          marginTop: 7,
          color: kButtonTextColor,
        ),
      ),
    );
  }

  double getProgressPercentage(int? amount) {
    if(amount! > Config.progressBarLimit){
      return double.parse(Config.progressBarLimit.toString());
    }else{
      var coin = amount;
      return (size.width - (size.width / 10 * 2)) * coin / Config.progressBarLimit;
    }
  }

  Widget showUserInfos() {
    return Row(
      children: [
        Flexible(
          flex: 1,
          child: Padding(
            padding: const EdgeInsets.only(right: 4.0),
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:widget.mUser!),
          ),
        ),
        Flexible(
          flex: 2,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextWithTap(
                widget.mUser!.username!,
                fontSize: 19,
                color: kContentColorDarkTheme,
              ),
              Padding(
                padding:
                    EdgeInsets.only(right: size.width / 25, top: 6, bottom: 5),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWithTap(
                      'profile_screen.follower'.tr(namedArgs: {
                        'number': MainHelper.formatNumber(
                            widget.mUser!.getFollowers!.length),
                      }),
                      fontSize: 7.8,
                      color: kContentColorDarkTheme,
                      onTap: () => MainHelper.goToNavigatorScreen(context,
                          FollowersPage(currentUser: widget.currentUser,
                            user: widget.mUser,
                          )),
                    ),
                    TextWithTap(
                      'profile_screen.following'.tr(namedArgs: {
                        'number': MainHelper.formatNumber(
                            widget.mUser!.getFollowing!.length),
                      }),
                      fontSize: 7.8,
                      color: kContentColorDarkTheme,
                      onTap: () => MainHelper.goToNavigatorScreen(context,
                          FollowingsPage(currentUser: widget.currentUser,
                            user: widget.mUser,
                          )),
                    ),
                    TextWithTap(
                      'profile_screen.challenge'.tr(namedArgs: {
                        'number': MainHelper.formatNumber(challenges)
                      }),
                      fontSize: 7.8,
                      color: kContentColorDarkTheme,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 5.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    widget.mUser!.getIsViewer!
                        ? const SizedBox()
                        : TextWithTap(
                            'profile_screen.point'.tr(namedArgs: {
                              'number': widget.mUser!.getPoints.toString()
                            }),
                            fontSize: 10,
                            color: kContentColorDarkTheme,
                          ),
                    IconButton(
                      onPressed: () => openSheet(widget.mUser!),
                      icon: const Icon(
                        Icons.more_horiz,
                        color: kContentColorDarkTheme,
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget showProgressBar() {
    return Padding(
      padding: const EdgeInsets.only(top: 13),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(right: size.width / 52, bottom: 4.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const TextWithTap(
                  '0',
                  fontSize: 7.8,
                  color: kContentColorDarkTheme,
                ),
                TextWithTap(
                  'profile_screen.classe'.tr(),
                  fontSize: 7.8,
                  color: kContentColorDarkTheme,
                ),
                TextWithTap(
                  Config.progressBarLimit.toString(),
                  fontSize: 7.8,
                  color: kContentColorDarkTheme,
                ),
              ],
            ),
          ),
          ContainerCorner(
            borderColor: kPrimaryColor,
            borderWidth: 2,
            color: kTransparentColor,
            height: size.width / 17,
            child: Row(
              children: [
                ContainerCorner(
                  alignment: Alignment.centerLeft,
                  color: kPrimaryColor,
                  height: size.width / 17,
                  width: getProgressPercentage(widget.mUser!.getPoints),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget showMedalsAndTrophies() {
    return Padding(
      padding: const EdgeInsets.only(top: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextWithTap(
                'profile_screen.medals'.tr(),
                fontSize: 13,
                marginRight: size.width / 15,
                fontWeight: FontWeight.bold,
                color: kContentColorDarkTheme,
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: size.width * 0.64,
                      height: size.height / 20,
                      child: ListView.builder(
                        itemCount: widget.currentUser!.getMedals ?? 0,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: EdgeInsets.only(right: size.width / 25),
                            child: SvgPicture.asset(
                              'assets/svg/medal.svg',
                              width: size.width / 16,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 4.0,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextWithTap(
                'profile_screen.trophy'.tr(),
                fontSize: 13,
                marginRight: size.width / 15,
                fontWeight: FontWeight.bold,
                color: kContentColorDarkTheme,
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: size.width * 0.64,
                      height: size.height / 20,
                      child: ListView.builder(
                        itemCount: widget.currentUser!.getTrophy ?? 0,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: EdgeInsets.only(right: size.width / 25),
                            child: SvgPicture.asset(
                              'assets/svg/trophy.svg',
                              width: size.width / 16,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget displayTabs() {
    return Padding(
      padding: EdgeInsets.only(
        right: size.width / 44,
        left: size.width / 44,
      ),
      child: Column(
        children: [
          line(),
          TabBar(indicatorColor: Colors.transparent, tabs: [
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-1.png',
            ),
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-2.png',
            ),
          ]),
          line(),
          Flexible(
            child: TabBarView(children: [
              allUserVideos(),
              moreUserInfo(),
              // const TextWithTap(''),
              // allSavedVideos(),
            ]),
          )
        ],
      ),
    );
  }

  Widget displayViewerTabs() {
    return Padding(
      padding: EdgeInsets.only(
        right: size.width / 44,
        left: size.width / 44,
      ),
      child: Column(
        children: [
          line(),
          TabBar(indicatorColor: Colors.transparent, tabs: [
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-2.png',
            ),
          ]),
          line(),
          Flexible(
            child: TabBarView(children: [
              moreUserInfo(),
            ]),
          )
        ],
      ),
    );
  }

  Widget allSavedVideos() {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereContainedIn(VideoModel.keyObjectId, widget.mUser!.getSaves!);
    query.orderByDescending(VideoModel.keyCreatedAt);

    return ParseLiveGridWidget<VideoModel>(
      query: query,
      crossAxisCount: 3,
      reverse: false,
      crossAxisSpacing: 2,
      mainAxisSpacing: 2,
      lazyLoading: false,
      childAspectRatio: .7,
      scrollPhysics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      animationController: _animationController,
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<VideoModel> snapshot) {
        if (snapshot.failed) {
          return noConnectedMessage();
        } else if (snapshot.hasData) {
          VideoModel video = snapshot.loadedData!;
          return GestureDetector(
            onTap: () => MainHelper.goToNavigatorScreen(
              context,
              WatchVideoPage(
                currentUser: widget.currentUser!,
                video: video,
              ),
            ),
            child: Stack(children: [
              ActionsHelper.videoThumbnailWidget(
                  video, size.width * 0.5, size.height * 0.6),
              ContainerCorner(
                height: size.height * 0.6,
                width: size.width * 0.5,
                color: Colors.black.withOpacity(0.5),
              ),
              Center(
                child: SvgPicture.asset(
                  'assets/svg/ic_video_play.svg',
                  width: size.width / 4.5,
                  height: size.width / 4.5,
                  color:Colors.white,
                ),
              ),
              Positioned(
                bottom: 2.0,
                left: 5.0,
                right: 5.0,
                child: Row(
                  children: [
                    TextWithTap(
                      '@${video.getAuthor!.getUsername!}',
                      fontSize: 12,
                      overflow: TextOverflow.ellipsis,
                      color: kButtonTextColor,
                      fontWeight: FontWeight.bold,
                    ),
                    Row(
                      children: [
                        TextWithTap(
                          '${video.getViewsCount}',
                          marginRight: 2,
                        ),
                        const Icon(
                          Icons.play_arrow,
                          size: 10,
                        )
                      ]
                    ),
                  ],
                ),
              ),
            ]),
          );
        } else {
          return Center(
            child: MainHelper.appLoading(),
          );
        }
      },
      queryEmptyElement: noVideosMessage(),
      gridLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  Widget allUserVideos() {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(
        VideoModel.keyCurrentState, VideoModel.videoCurrentStatePublished);
    query.whereEqualTo(VideoModel.keyAuthor, widget.mUser);
    query.orderByDescending(VideoModel.keyCreatedAt);

    return ParseLiveGridWidget<VideoModel>(
      query: query,
      crossAxisCount: 3,
      reverse: false,
      /*crossAxisSpacing: 10,
      mainAxisSpacing: 10,*/
      lazyLoading: false,
      childAspectRatio: .7,
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      animationController: _animationController,
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<VideoModel> snapshot) {
        if (snapshot.failed) {
          return noConnectedMessage();
        } else if (snapshot.hasData) {
          VideoModel video = snapshot.loadedData!;
          return GestureDetector(
            onTap: () => MainHelper.goToNavigatorScreen(
              context,
              WatchVideoPage(
                currentUser: widget.currentUser!,
                video: video,
              ),
            ),
            child: Stack(children: [
              ActionsHelper.videoThumbnailWidget(
                  video, size.width * 0.5, size.height * 0.6),
              ContainerCorner(
                height: size.height * 0.6,
                width: size.width * 0.5,
                color: Colors.black.withOpacity(0.5),
              ),
              Center(
                child: SvgPicture.asset(
                  'assets/svg/ic_video_play.svg',
                  width: size.width / 4.5,
                  height: size.width / 4.5,
                  color:Colors.white,
                ),
              ),
              Positioned(
                bottom: 2.0,
                left: 5.0,
                right: 5.0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      TextWithTap(
                        MainHelper.formatNumber(video.getViewsCount ?? 0),
                        color:Colors.white,
                        fontSize: 14,
                        marginRight: 0,
                      ),
                      const Icon(
                        Icons.play_arrow_outlined,
                        size: 18,
                        color:Colors.white,
                      )
                    ]
                ),
              ),
            ]),
          );
        } else {
          return Center(
            child: MainHelper.appLoading(),
          );
        }
      },
      queryEmptyElement: noVideosMessage(),
      gridLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  Widget noVideosMessage() {
    return Center(
      child: TextWithTap(
        'profile_screen.no_videos'.tr(),
        fontSize: 17,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget noConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget moreUserInfo() {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWithTap(
            widget.mUser!.getAboutYou == ''
                ? widget.mUser!.getBio.toString()
                : widget.mUser!.getAboutYou.toString(),
            color: kContentColorDarkTheme,
            fontSize: 17,
            fontWeight: FontWeight.bold,
            marginBottom: 30,
          ),
          TextWithTap(
            widget.mUser!.getFullName.toString(),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginBottom: 10,
          ),
          Visibility(
            visible: allCategories.isNotEmpty,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: List.generate(allCategories.length, (index) {
                  CategoryModel category = allCategories[index];
                  return TextWithTap(
                    widget.mUser!.getCategories!.contains(category.objectId) ||
                            widget.mUser!.getCategories!
                                .contains(category.getCode)
                        ? '${category.getName!} '
                        : '',
                    color: kContentColorDarkTheme,
                    fontSize: 15,
                  );
                }),
              ),
            ),
          ),
          TextWithTap(
            MainHelper.getFilmList(widget.mUser!.getFavoriteFilm!),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginTop: 10,
          ),
          TextWithTap(
            MainHelper.getHobbyList(widget.mUser!.getHobby!),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginTop: 10,
          ),
          TextWithTap(
            widget.mUser!.getJobTitle.toString(),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginTop: 10,
          ),
        ],
      ),
    );
  }

  void openSheet(UserModel mUser) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showOptions(mUser);
        });
  }

  Widget _showOptions(UserModel mUser) {
    var allSize = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: allSize.height <= 570 ? 0.6 : 0.55,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                var size = MediaQuery.of(context).size;
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Stack(
                    children: [
                      ContainerCorner(
                        borderWidth: 0,
                        color: Colors.black.withOpacity(0.4),
                        width: size.width,
                        height: size.height,
                        radiusTopRight: 25,
                        radiusTopLeft: 25,
                        imageDecoration: "assets/images/app_bg.png",
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(25),
                          topLeft: Radius.circular(25),
                        ),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: ContainerCorner(
                              color: kTransparentColor,
                              height: size.height,
                              width: size.width),
                        ),
                      ),
                      Scaffold(
                        backgroundColor: kTransparentColor,
                        appBar: AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kTransparentColor,
                          centerTitle: true,
                          title: TextWithTap(
                            "more_options".tr(),
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                          actions: [
                            IconButton(
                                onPressed: () =>
                                    MainHelper.goBackToPreviousPage(context),
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 25,
                                ))
                          ],
                        ),
                        body: ContainerCorner(
                          radiusTopRight: 20.0,
                          radiusTopLeft: 20.0,
                          color: kTransparentColor,
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                ButtonWithIcon(
                                  text: "profile_screen.report_user".tr(),
                                  icon: Icons.flag,
                                  iconColor: Colors.white,
                                  height: 60,
                                  backgroundColor: Colors.white.withOpacity(0.1),
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  textColor: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w500,
                                  onTap: () {
                                    MainHelper.goBackToPreviousPage(context);
                                    openSheetReport();
                                  },
                                ),
                                const Divider(),
                                ButtonWithIcon(
                                  text: !widget.currentUser!.getBlockedUsersIDs!.contains(
                                    widget.mUser!.objectId)
                                      ? "profile_screen.block_this_user".tr()
                                      : "profile_screen.unblock_user".tr(),
                                  icon: Icons.block,
                                  iconColor: Colors.white,
                                  height: 60,
                                  backgroundColor: Colors.white.withOpacity(0.1),
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  textColor: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w500,
                                  onTap: () {
                                    if(widget.currentUser!.getBlockedUsersIDs!
                                        .contains(widget.mUser!.objectId)){
                                      MainHelper.hideLoadingDialog(context);

                                      MainHelper.goToNavigatorScreen(
                                        context,
                                        BlockedUsersPage(
                                          currentUser: widget.currentUser,
                                        ),
                                      );
                                    }else{
                                      showBlockUserAlert(mUser);
                                    }
                                  },
                                ),
                                const Divider(),
                                Visibility(
                                  visible: verifyBlockedUser(),
                                  child: Column(
                                    children: [
                                      ButtonWithIcon(
                                        text: "profile_screen.chat_with".tr(namedArgs: {
                                          "name": widget.mUser!.getFullName!
                                        }),
                                        icon: Icons.mark_unread_chat_alt,
                                        iconColor: Colors.white,
                                        height: 60,
                                        urlIconColor: Colors.white.withOpacity(0.5),
                                        backgroundColor: Colors.white.withOpacity(0.1),
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        textColor: Colors.white,
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500,
                                        onTap: () {
                                          _gotToChat(
                                              widget.currentUser!, widget.mUser!);
                                        },
                                      ),
                                      const Divider(),
                                    ],
                                  ),
                                ),
                                ButtonWithIcon(
                                  text: isFollowing
                                      ? "live_streaming.live_unfollow".tr()
                                      : "live_streaming.live_follow".tr(),
                                  icon: isFollowing ? Icons.exposure_minus_1 : Icons.add,
                                  iconColor: Colors.white,
                                  height: 60,
                                  backgroundColor: Colors.white.withOpacity(0.1),
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  textColor: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w500,
                                  onTap: () {
                                    MainHelper.goBackToPreviousPage(context);
                                    followOrUnfollow(isFollowing);
                                  },
                                ),
                                const Divider(),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  _confirmBlockUser(UserModel mUser) async {
    MainHelper.goBackToPreviousPage(context);

    MainHelper.showLoadingDialog(context);

    // widget.currentUser!.setBlockedUser = mUser;
    widget.currentUser!.setBlockedUserIds = mUser.objectId!;

    ParseResponse response = await widget.currentUser!.save();
    if (response.success) {
      MainHelper.goBackToPreviousPage(context);
      MainHelper.goBackToPreviousPage(context);

      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "blocked".tr(),
        message: "profile_screen.user_blocked"
            .tr(namedArgs: {"name": mUser.getFullName!}),
        user: widget.mUser,
        isError: null,
      );


    } else {
      MainHelper.goBackToPreviousPage(context);
      MainHelper.goBackToPreviousPage(context);

      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "profile_screen.user_not_blocked"
            .tr(namedArgs: {"name": mUser.getFullName!}),
        user: widget.mUser,
        isError: true,
      );
    }
  }

  void openSheetFollow(bool following, List<dynamic> usersIds) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showFollow(following, usersIds);
        });
  }

  Widget _showFollow(bool following, List<dynamic> usersIds) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.8,
            minChildSize: 0.1,
            maxChildSize: 0.9,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: ContainerCorner(
                    radiusTopRight: 20.0,
                    radiusTopLeft: 20.0,
                    color: MainHelper.isDarkMode(context)
                        ? kContentColorLightTheme
                        : Colors.white,
                    child: showFollowersAndFollowingWidget(usersIds),
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  ParseLiveListWidget showFollowersAndFollowingWidget(List<dynamic> usersIds) {
    QueryBuilder<UserModel> queryBuilder =
        QueryBuilder<UserModel>(UserModel.forQuery());
    queryBuilder.whereContainedIn(UserModel.keyId, usersIds);

    return ParseLiveListWidget<UserModel>(
      query: queryBuilder,
      reverse: false,
      lazyLoading: false,
      shrinkWrap: true,
      duration: const Duration(seconds: 0),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<UserModel> snapshot) {
        if (snapshot.hasData) {
          UserModel user = snapshot.loadedData as UserModel;
          return Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () => ActionsHelper.showUserProfile(
                      context, widget.currentUser!, user),
                  child: ActionsHelper.avatarWidget(
                    user,
                    width: 50,
                    height: 50,
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => ActionsHelper.showUserProfile(
                        context, widget.currentUser!, user),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            TextWithTap(
                              user.getFullName!,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              marginLeft: 10,
                              color: MainHelper.isDarkMode(context)
                                  ? Colors.white
                                  : Colors.black,
                              marginTop: 5,
                              marginRight: 5,
                            ),
                            ContainerCorner(
                              color: kTransparentColor,
                              marginLeft: 10,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ContainerCorner(
                                    marginRight: 10,
                                    child: Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/svg/ic_diamond.svg",
                                          height: 24,
                                        ),
                                        TextWithTap(
                                          user.getPoints.toString(),
                                          fontSize: 14,
                                          marginLeft: 3,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ],
                                    ),
                                  ),
                                  ContainerCorner(
                                    marginLeft: 10,
                                    child: Row(
                                      children: [
                                        SvgPicture.asset(
                                          "assets/svg/ic_tab_following_default.svg",
                                          color: kRedColor1,
                                          height: 18,
                                        ),
                                        TextWithTap(
                                          user.getFollowers!.length.toString(),
                                          fontSize: 12,
                                          marginRight: 15,
                                          marginLeft: 5,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        )),
                      ],
                    ),
                  ),
                ),
                Visibility(
                  visible: widget.currentUser!.objectId != user.objectId,
                  child: ContainerCorner(
                    borderRadius: 50,
                    height: 40,
                    width: 40,
                    color: widget.currentUser!.getFollowing!
                            .contains(user.objectId)
                        ? kTicketBlueColor
                        : kRedColor1,
                    child: Icon(
                      widget.currentUser!.getFollowing!.contains(user.objectId)
                          ? Icons.chat_outlined
                          : Icons.add,
                      color: Colors.white,
                    ),
                    onTap: () {
                      if (!widget.currentUser!.getFollowing!
                          .contains(user.objectId)) {
                        follow(user);
                      } else {
                        _gotToChat(widget.currentUser!, user);
                      }
                    },
                  ),
                )
              ],
            ),
          );
        } else {
          return Container();
        }
      },
      listLoadingElement: const Center(
        child: CircularProgressIndicator.adaptive(),
      ),
    );
  }

  void follow(UserModel mUser) async {
    MainHelper.showLoadingDialog(context);

    ParseResponse parseResponseUser;

    widget.currentUser!.setFollowing = mUser.objectId!;
    parseResponseUser = await widget.currentUser!.save();

    if (parseResponseUser.success) {
      if (parseResponseUser.results != null) {
        MainHelper.hideLoadingDialog(context);
        setState(() {
          widget.currentUser = parseResponseUser.results!.first as UserModel;
        });
      }
    }

    ParseResponse parseResponse;
    parseResponse = await CloudCodeHelper.followUser(
        isFollowing: false, author: widget.currentUser!, receiver: mUser);

    if (parseResponse.success) {
      ActionsHelper.createOrDeleteNotification(widget.currentUser!, mUser,
          NotificationsModel.notificationTypeFollowers);
    }
  }

  void followOrUnfollow(bool follow) async {
    MainHelper.showLoadingDialog(context);

    if (follow) {
      widget.currentUser!.removeFollowing = widget.mUser!.objectId!;
    } else {
      widget.currentUser!.setFollowing = widget.mUser!.objectId!;
    }

    await widget.currentUser!.save();

    ParseResponse parseResponse;

    parseResponse = await CloudCodeHelper.followUser(
        isFollowing: follow,
        author: widget.currentUser!,
        receiver: widget.mUser!);

    if (parseResponse.success) {
      MainHelper.hideLoadingDialog(context);

      ActionsHelper.createOrDeleteNotification(widget.currentUser!,
          widget.mUser!, NotificationsModel.notificationTypeFollowers);

      QueryBuilder<UserModel> query = QueryBuilder(UserModel.forQuery());
      query.whereEqualTo(UserModel.keyObjectId, widget.mUser!.objectId);
      ParseResponse result = await query.query();

      if (result.success) {
        widget.mUser = result.results!.first as UserModel;
      }

      setState(() {
        followers = widget.mUser!.getFollowers!.length;
        followers = widget.mUser!.getFollowing!.length;
      });
    }

    setState(() {
      follow = !follow;
    });
  }

  _gotToChat(UserModel currentUser, UserModel mUser) {
    MainHelper.goToNavigatorScreen(
        context,
        MessagePage(
          currentUser: widget.currentUser,
          mUser: widget.mUser,
        ));
  }

  showBlockUserAlert(UserModel user){
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      top: 15.0, bottom: 10.0),
                  child: ContainerCorner(
                    width: 130,
                    height: 130,
                    child: ActionsHelper.polygonAvatarWidget(
                        currentUser:user, fontSize: 20
                    ),
                  ),
                ),
                TextWithTap(
                  user.getFullName!,
                  textAlign: TextAlign.center,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  marginBottom:4,
                ),
                TextWithTap(
                  "feed.block_user_confirm".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "confirm_"
                              .tr()
                              .toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => _confirmBlockUser(user),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  void openSheetReport() async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showPostOptionsAndReportAuthor();
        });
  }

  Widget _showPostOptionsAndReportAuthor() {
    List<dynamic> reportReason = [
      ReportModel.thisPosHasSexualContents,
      ReportModel.fakeProfileSpan,
      ReportModel.inappropriateMessage,
      ReportModel.someoneIsInDanger,
    ];

    return GestureDetector(
      onTap: () => MainHelper.goBackToPreviousPage(context),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        height: size.height,
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: size.height <= 570 ? 0.6 : 0.5,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                var size = MediaQuery.of(context).size;
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Stack(
                    children: [
                      ContainerCorner(
                        borderWidth: 0,
                        color: Colors.black.withOpacity(0.4),
                        width: size.width,
                        height: size.height,
                        radiusTopRight: 25,
                        radiusTopLeft: 25,
                        imageDecoration: "assets/images/app_bg.png",
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(25),
                          topLeft: Radius.circular(25),
                        ),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: ContainerCorner(
                              color: kTransparentColor,
                              height: size.height,
                              width: size.width),
                        ),
                      ),
                      Scaffold(
                        backgroundColor: kTransparentColor,
                        appBar: AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kTransparentColor,
                          centerTitle: true,
                          actions: [
                            IconButton(
                                onPressed: () =>
                                    MainHelper.goBackToPreviousPage(context),
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 25,
                                ))
                          ],
                          title: TextWithTap(
                            "video.report_reason_title".tr(),
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        body: ContainerCorner(
                          radiusTopRight: 20.0,
                          radiusTopLeft: 20.0,
                          color: kTransparentColor,
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: List.generate(
                                  reportReason.length,
                                      (index) => Column(
                                    children: [
                                      ButtonWithIcon(
                                        text: MainHelper.getReportMessage(reportReason[index]),
                                        iconColor: kPrimaryColor,
                                        height: 50,
                                        marginLeft: 10,
                                        marginRight: 10,
                                        backgroundColor: Colors.white.withOpacity(0.1),
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        textColor: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w500,
                                        onTap: () {
                                          createReport(MainHelper.getReportMessage(reportReason[index]));
                                        },
                                      ),
                                      const Divider(),
                                    ],
                                  )
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  createReport(String message) async {
    MainHelper.showLoadingDialog(context);

    ReportModel report = ReportModel();

    report.setAccuser = widget.currentUser!;
    report.setAccusedId = widget.currentUser!.objectId!;

    report.setAccused = widget.mUser!;
    report.setAccuserId = widget.mUser!.objectId!;

    report.setMessage = message;

    ParseResponse response = await report.save();

    if(response.success){
      widget.currentUser!.save();

      MainHelper.hideLoadingDialog(context);
      MainHelper.hideLoadingDialog(context);

      MainHelper.showAppNotificationAdvanced(
        title:'report_message'.tr(),
        context: context,
        isError: false,
      );
    }else{
      MainHelper.hideLoadingDialog(context);
      MainHelper.hideLoadingDialog(context);

      MainHelper.showAppNotificationAdvanced(
        title:'video.report_failed_title'.tr(),
        message: 'video.report_failed_message'.tr(),
        context: context,
        isError: true,
      );
    }
  }

  bool verifyBlockedUser(){
    return !widget.currentUser!.getBlockedUsersIDs!.contains(
      widget.mUser!.objectId
    ) && !widget.mUser!.getBlockedUsersIDs!.contains(
        widget.currentUser!.objectId
    );
  }
}
