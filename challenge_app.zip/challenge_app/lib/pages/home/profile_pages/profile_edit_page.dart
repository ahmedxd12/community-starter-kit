// ignore_for_file: must_be_immutable, use_build_context_synchronously
import 'dart:io';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:challenge/widgets/components_widgets/DateTextFormatter.dart';
import 'package:challenge/widgets/components_widgets/FirstUpperCaseTextFormatter.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../configurations/global_setup.dart';
import '../../../widgets/custom_widgets/button_rounded_outline.dart';
import '../../../widgets/custom_widgets/rounded_input_field.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../home_page.dart';

class ProfileEditPage extends StatefulWidget {
  static String route = "/ProfileEditPage";

  UserModel? currentUser;

  ProfileEditPage({Key? key, this.currentUser}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _ProfileEditPageState createState() => _ProfileEditPageState();
}

class _ProfileEditPageState extends State<ProfileEditPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController fullNameEditingController = TextEditingController();
  TextEditingController aboutYouTitleEditingController =
      TextEditingController();
  TextEditingController birthdayEditingController = TextEditingController();

  String typeName = "name";
  String typeBirthday = "birthday";
  String typeGender = "gender";

  bool isValidBirthday = false;
  bool isValidGender = false;
  String myBirthday = "";
  String mySelectedGender = "";
  String userBirthday = "";
  String userGender = "";

  String userAvatar = "";
  String userCover = "";

  //String? _genderSelection = UserModel.keyGender;

  ParseFileBase? parseFile;

  @override
  void dispose() {
    fullNameEditingController.dispose();
    aboutYouTitleEditingController.dispose();
    birthdayEditingController.dispose();
    super.dispose();
  }

  _getUser() async {
    fullNameEditingController.text = widget.currentUser!.getFullName!;
    aboutYouTitleEditingController.text = widget.currentUser!.getAboutYou!;
    userBirthday = widget.currentUser!.getBirthday != null
        ? MainHelper.getBirthdayFromDate(widget.currentUser!.getBirthday!)
        : "profile_screen.invalid_date".tr();

    if (widget.currentUser!.getBirthday != null) {
      isValidBirthday = true;
      birthdayEditingController.text =
          MainHelper.getBirthdayFromDate(widget.currentUser!.getBirthday!);
    }

    if (widget.currentUser!.getGender != null) {
      isValidGender = true;

      mySelectedGender = widget.currentUser!.getGender!;
    }

    userGender = widget.currentUser!.getGender != null
        ? MainHelper.getGender(widget.currentUser!)
        : "profile_screen.gender_invalid".tr();

    setState(() {
      userAvatar = widget.currentUser!.getAvatar != null
          ? widget.currentUser!.getAvatar!.url!
          : "";
      userCover = widget.currentUser!.getCover != null
          ? widget.currentUser!.getCover!.url!
          : "";
    });
  }

  @override
  void initState() {
    _getUser();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () {
        FocusScopeNode focusScopeNode = FocusScope.of(context);
        if (!focusScopeNode.hasPrimaryFocus &&
            focusScopeNode.focusedChild != null) {
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: kTransparentColor,
          automaticallyImplyLeading: false,
          leading: const BackButton(
            color: Colors.white,
          ),
        ),
        body: Stack(
          //alignment: AlignmentDirectional.bottomCenter,
          children: [
            ContainerCorner(
              imageDecoration: "assets/images/app_bg.png",
              width: size.width,
              height: size.height,
              borderWidth: 0,
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Align(
                        child: Padding(
                          padding: EdgeInsets.only(top: size.width / 4),
                          child: GestureDetector(
                            child: Column(
                              children: [
                                ContainerCorner(
                                  width: size.width / 2.7,
                                  height: size.width / 2.7,
                                  child:ActionsHelper.polygonAvatarWidget(
                                      currentUser:widget.currentUser!),
                                ),
                                ContainerCorner(
                                  color: Colors.white.withOpacity(0.07),
                                  marginTop: 20,
                                  borderRadius: 4,
                                  height: 50,
                                  marginLeft: size.width / 4,
                                  marginRight: size.width / 4,
                                  onTap: () => checkPermission(true),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      TextWithTap(
                                        "profile_screen.edit_avatar".tr(),
                                        color: Colors.white.withOpacity(0.5),
                                        fontWeight: FontWeight.w600,
                                        fontSize: size.width / 25,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  ContainerCorner(
                    marginTop: 30,
                    color: kTransparentColor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWithTap(
                          "profile_screen.name_".tr(),
                          marginLeft: 10,
                          marginBottom: 5,
                          color: Colors.white,
                        ),
                        TextWithTap(
                          widget.currentUser!.getFullName!,
                          marginRight: 5,
                          marginLeft: 10,
                          color: kGrayColor,
                        ),
                        const ContainerCorner(
                          marginTop: 20,
                          height: 1,
                        )
                      ],
                    ),
                    onTap: () => _changeName(),
                  ),
                  ContainerCorner(
                    onTap: () => _changeName(),
                    marginTop: 10,
                    color: kTransparentColor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWithTap(
                          "profile_screen.about_me".tr(),
                          marginLeft: 10,
                          marginBottom: 5,
                          color: Colors.white,
                        ),
                        ContainerCorner(
                          marginLeft: 10,
                          marginRight: 10,
                          width: MediaQuery.of(context).size.width - 20,
                          borderRadius: 10,
                          color: kTransparentColor,
                          child: TextWithTap(
                            widget.currentUser!.getAboutYou!.isNotEmpty
                                ? widget.currentUser!.getAboutYou!
                                : "profile_screen.profile_desc_hint".tr(),
                            marginRight: 10,
                            marginBottom: 10,
                            marginTop: 10,
                            marginLeft: 10,
                            color: kGrayColor,
                          ),
                        ),
                        const ContainerCorner(
                          marginTop: 20,
                          height: 1,
                        )
                      ],
                    ),
                  ),
                  ContainerCorner(
                    marginTop: 10,
                    color: kTransparentColor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWithTap(
                          "profile_screen.birthday_".tr(),
                          marginLeft: 10,
                          marginBottom: 5,
                          color: Colors.white,
                        ),
                        TextWithTap(
                          userBirthday,
                          color: kGrayColor,
                          marginLeft: 10,
                          marginBottom: 5,
                          fontSize: 12,
                        ),
                        const ContainerCorner(
                          marginTop: 10,
                          height: 1,
                        )
                      ],
                    ),
                    onTap: () => _changeName(),
                  ),
                  ContainerCorner(
                    marginTop: 10,
                    color: kTransparentColor,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextWithTap(
                          "profile_screen.gender_".tr(),
                          marginLeft: 10,
                          marginBottom: 5,
                          color: Colors.white,
                        ),
                        TextWithTap(
                          userGender,
                          color: kGrayColor,
                          marginLeft: 10,
                          marginBottom: 5,
                          fontSize: 12,
                        ),
                        const ContainerCorner(
                          marginTop: 10,
                          height: 1,
                        )
                      ],
                    ),
                    onTap: () => _changeName(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  _changeName() {
    showModalBottomSheet(
      backgroundColor: kTransparentColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(25.0),
          topRight: Radius.circular(25.0),
        ),
      ),
      isScrollControlled: true,
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          var size = MediaQuery.of(context).size;
          return GestureDetector(
            onTap: () {
              FocusScopeNode focusScopeNode = FocusScope.of(context);
              if (!focusScopeNode.hasPrimaryFocus &&
                  focusScopeNode.focusedChild != null) {
                FocusManager.instance.primaryFocus?.unfocus();
              }
            },
            child: ContainerCorner(
              child: Stack(children: [
                ContainerCorner(
                  height: size.height,
                  width: size.width,
                  borderWidth: 0,
                  imageDecoration: "assets/images/app_bg.png",
                ),
                ClipRRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                    child: SizedBox(
                      height: size.height,
                      width: size.width,
                    ),
                  ),
                ),
                Padding(
                  padding: MediaQuery.of(context).viewInsets,
                  child: SingleChildScrollView(
                    child: SafeArea(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Align(
                            alignment: Alignment.topRight,
                            child: ContainerCorner(
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                              width: size.width / 18,
                              height: size.width / 18,
                              marginLeft: 12,
                              marginRight: 12,
                              marginBottom: 15,
                              marginTop: size.height * 0.07,
                              color: kPrimaryColor,
                              borderRadius: 50,
                              child: Center(
                                child: Icon(
                                  Icons.close,
                                  size: size.width / 25,
                                  color: kContentColorDarkTheme,
                                ),
                              ),
                            ),
                          ),
                          Column(
                            children: [
                              Stack(
                                alignment: Alignment.center,
                                children: [
                                  ContainerCorner(
                                    width: 130,
                                    height: 130,
                                    child:ActionsHelper.polygonAvatarWidget(
                                        currentUser:widget.currentUser!),
                                  ),
                                ],
                              ),
                              TextWithTap(
                                widget.currentUser!.getFullName!,
                                fontSize: size.width / 23,
                                marginBottom: 5,
                                marginTop: 5,
                                fontWeight: FontWeight.bold,
                                color: Colors.white.withOpacity(0.5),
                              ),
                              TextWithTap(
                                "profile_screen.update_your_profile".tr(),
                                fontSize: size.width / 26,
                                marginBottom: 5,
                                marginRight: 20,
                                marginLeft: 20,
                                textAlign: TextAlign.center,
                                color: Colors.white.withOpacity(0.5),
                                marginTop: 5,
                              ),
                              builderTextField(setState),
                            ],
                          ),
                          ContainerCorner(
                            radiusBottomRight: 20,
                            borderWidth: 2,
                            imageDecoration: "assets/images/btn_design.png",
                            radiusTopLeft: 20,
                            marginTop: size.width / 15,
                            height: size.width / 6,
                            marginLeft: size.width / 7,
                            marginRight: size.width / 7,
                            width: size.width,
                            onTap: () {
                              if (_formKey.currentState!.validate()) {
                                _updateNow();
                              } else if (!isValidBirthday) {
                                MainHelper.showAppNotificationAdvanced(
                                  title: "profile_screen.choose_birthday".tr(),
                                  context: context,
                                  isError:true,
                                );
                              } else if (!isValidGender) {
                                MainHelper.showAppNotificationAdvanced(
                                  title: "profile_screen.gender_invalid_select".tr(),
                                  context: context,
                                  isError:true,
                                );
                              }
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  TextWithTap(
                                    "update_".tr(),
                                    color: Colors.white,
                                    marginLeft: 10,
                                    fontSize: 23,
                                    fontWeight: FontWeight.w700,
                                  )
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ]),
            ),
          );
        });
      },
    );
  }

  Widget builderTextField(StateSetter setState) {
    // ignore: no_leading_underscores_for_local_identifiers
    String? _validateFullName(String value) {
      //int firstSpace = value.indexOf(" ");

      if (value.isEmpty) {
        return "profile_screen.no_full_name".tr();
      }
      else {
        return null;
      }
    }

    // ignore: no_leading_underscores_for_local_identifiers
    String? _validateBirthday(String value) {
      isValidBirthday = false;
      if (value.isEmpty) {
        return "profile_screen.choose_birthday".tr();
      } else if (!MainHelper.isValidDateBirth(value, MainHelper.dateFormatDmy)) {
        return "profile_screen.invalid_date".tr();
      } else if (!MainHelper.minimumAgeAllowed(value, MainHelper.dateFormatDmy)) {
        return "profile_screen.mim_age_required"
            .tr(namedArgs: {'age': Setup.minimumAgeToRegister.toString()});
      } else {
        isValidBirthday = true;
        myBirthday = value;
        return null;
      }
    }

    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          RoundedInputField(
            // Full name
            inputFormatters: [FirstUpperCaseTextFormatter()],
            isNodeNext: false,
            textInputAction: TextInputAction.done,
            hintText: "auth.full_name_hint".tr(),
            textColor: Colors.white.withOpacity(0.5),
            controller: fullNameEditingController,
            autoValidateMode: AutovalidateMode.onUserInteraction,
            validator: (value) {
              return _validateFullName(value!);
            },
          ),
          ContainerCorner(
            marginLeft: 25,
            marginRight: 25,
            width: MediaQuery.of(context).size.width - 20,
            borderRadius: 10,
            color: Colors.white.withOpacity(0.1),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: aboutYouTitleEditingController,
                maxLength: 500,
                minLines: 1,
                maxLines: 100,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
                keyboardType: TextInputType.multiline,
                validator: (value) {
                  return null;
                },
                decoration: InputDecoration(
                  hintText: "profile_screen.hint_about_you".tr(),
                  focusedBorder: InputBorder.none,
                  border: InputBorder.none,
                  hintStyle: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
          RoundedInputField(
            // Birthday
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp("[0-9/]")),
              LengthLimitingTextInputFormatter(10),
              DateFormatter(),
            ],
            textInputType: TextInputType.datetime,
            isNodeNext: false,
            textInputAction: TextInputAction.done,
            hintText: "profile_screen.birthday_hint".tr(),
            textColor: Colors.white.withOpacity(0.5),
            onChanged: (value) {
              setState(() {
                _validateBirthday(value);
              });
            },
            controller: birthdayEditingController,
            autoValidateMode: AutovalidateMode.onUserInteraction,
            validator: (value) {
              return _validateBirthday(value!);
            },
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ButtonRoundedOutline(
                text: "female_".tr().toUpperCase(),
                borderRadius: 60,
                //width: 250,
                height: 46,
                fontSize: 17,
                borderWidth: 1,
                marginRight: 10,
                marginLeft: 10,
                borderColor: mySelectedGender == UserModel.keyGenderFemale
                    ? kPrimaryColor
                    : kPrimacyGrayColor,
                textColor: mySelectedGender == UserModel.keyGenderFemale
                    ? kPrimaryColor
                    : kPrimacyGrayColor,
                onTap: () {
                  setState(() {
                    isValidGender = true;
                    mySelectedGender = UserModel.keyGenderFemale;
                  });
                },
              ),
              ButtonRoundedOutline(
                text: "male_".tr().toUpperCase(),
                borderRadius: 60,
                height: 46,
                fontSize: 17,
                borderWidth: 1,
                marginRight: 10,
                marginLeft: 10,
                borderColor: mySelectedGender == UserModel.keyGenderMale
                    ? kPrimaryColor
                    : kPrimacyGrayColor,
                textColor: mySelectedGender == UserModel.keyGenderMale
                    ? kPrimaryColor
                    : kPrimacyGrayColor,
                onTap: () {
                  setState(() {
                    isValidGender = true;
                    mySelectedGender = UserModel.keyGenderMale;
                  });
                },
              ),
            ],
          )
        ],
      ),
    );
  }

  Future<void> _updateNow() async {
    MainHelper.showLoadingDialog(context);

    String fullName = fullNameEditingController.text.trim();
    String firstName = "";
    String lastName = "";

    if (fullName.contains(" ")) {
      int firstSpace = fullName.indexOf(" ");
      firstName = fullName.substring(0, firstSpace);
      lastName = fullName.substring(firstSpace).trim();
    } else {
      firstName = fullName;
    }

    // String username = fullName.replaceAll(" ", "");

    if (widget.currentUser!.getFullName! !=
        fullNameEditingController.text.trim()) {
      widget.currentUser!.setNeedsChangeName = false;
    }

    widget.currentUser!.setFullName = fullName;
    widget.currentUser!.setFirstName = firstName;
    widget.currentUser!.setLastName = lastName;
    widget.currentUser!.setGender = mySelectedGender;
    // widget.currentUser!.username = username.toLowerCase();
    widget.currentUser!.setBirthday =
        MainHelper.getDate(birthdayEditingController.text);

    if (aboutYouTitleEditingController.text.isNotEmpty) {
      widget.currentUser!.setAboutYou = aboutYouTitleEditingController.text;
    }

    ParseResponse userResult = await widget.currentUser!.save();

    if (userResult.success) {
      MainHelper.hideLoadingDialog(context,
          result: userResult.results!.first as UserModel);
      MainHelper.hideLoadingDialog(context,
          result: userResult.results!.first as UserModel);

      widget.currentUser = userResult.results!.first as UserModel;

      _getUser();
    } else if (userResult.error!.code == 100) {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context, title: "error".tr(), message: "not_connected".tr());
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "try_again_later".tr());
    }
  }

  Future<void> checkPermission(bool isAvatar) async {
    if (MainHelper.isAndroidPlatform()) {
      PermissionStatus status = await Permission.storage.status;
      PermissionStatus status3 = await Permission.photos.status;
      PermissionStatus status2 = await Permission.camera.status;

      checkStatus(status, status2, status3, isAvatar);
    } else if (MainHelper.isIOSPlatform()) {
      PermissionStatus status3 = await Permission.storage.status;
      PermissionStatus status = await Permission.photos.status;
      PermissionStatus status2 = await Permission.camera.status;

      checkStatus(status, status2, status3, isAvatar);
    } else {
      _choosePhoto(isAvatar);
    }
  }

  void checkStatus(
      PermissionStatus status, PermissionStatus status2,
      PermissionStatus status3, bool isAvatar) {
    if ((status.isDenied && status3.isDenied) || status2.isDenied){
      // We didn't ask for permission yet or the permission has been denied before but not permanently.

      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access".tr(),
          confirmButtonText: "permissions.okay_".tr().toUpperCase(),
          message: "permissions.photo_access_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () async {
            MainHelper.hideLoadingDialog(context);

            if(MainHelper.isAndroidPlatform()){
              // You can request multiple permissions at once.
              Map<Permission, PermissionStatus> statuses = await [
                Permission.camera,
                Permission.storage,
                Permission.photos
              ].request();

              if (statuses[Permission.camera]!.isGranted
                || statuses[Permission.storage]!.isGranted
                || statuses[Permission.photos]!.isGranted
              ) {
                _choosePhoto(isAvatar);
              }
            } else{
              // You can request multiple permissions at once.
              Map<Permission, PermissionStatus> statuses = await [
                Permission.camera,
                Permission.photos,
                Permission.storage,
              ].request();

              if (statuses[Permission.camera]!.isGranted ||
                  statuses[Permission.photos]!.isGranted ||
                  statuses[Permission.storage]!.isGranted) {
                _choosePhoto(isAvatar);
              }
            }
          });
    } else if ((status.isPermanentlyDenied && status3.isPermanentlyDenied)
        || status2.isPermanentlyDenied) {
      MainHelper.showDialogPermission(
          context: context,
          title: "permissions.photo_access_denied".tr(),
          confirmButtonText: "permissions.okay_settings".tr().toUpperCase(),
          message: "permissions.photo_access_denied_explain"
              .tr(namedArgs: {"app_name": Setup.appName}),
          onPressed: () {
            MainHelper.hideLoadingDialog(context);

            openAppSettings();
          });
    } else if (status2.isGranted && (status.isGranted || status3.isGranted)) {
      //_uploadPhotos(ImageSource.gallery);
      _choosePhoto(isAvatar);
    }
  }

  _choosePhoto(bool isAvatar) async {
    final ImagePicker picker = ImagePicker();

    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      try{
        cropPhoto(image.path, isAvatar);
      }catch(e){
        if(Setup.isDebug){
          if (kDebugMode) {
            print('Error:$e');
          }
        }
      }
    }
  }

  void cropPhoto(String path, bool isAvatar) async {
    MainHelper.showLoadingDialog(context);

    CroppedFile? croppedFile = (await ImageCropper().cropImage(
      sourcePath: path,
      aspectRatioPresets: [
        isAvatar == true
            ? CropAspectRatioPreset.square
            : CropAspectRatioPreset.ratio16x9,
      ],
      //maxHeight: 480,
      //maxWidth: 740,
      aspectRatio: isAvatar == true
          ? const CropAspectRatio(ratioX: 4, ratioY: 4)
          : const CropAspectRatio(ratioX: 16, ratioY: 9),
      uiSettings: [
        AndroidUiSettings(
            toolbarTitle: "edit_photo".tr(),
            toolbarColor: kButtonTextColor,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: isAvatar == true
                ? CropAspectRatioPreset.square
                : CropAspectRatioPreset.ratio16x9,
            lockAspectRatio: false),
        IOSUiSettings(
          minimumAspectRatio: 1.0,
        )
      ],
    )) ; // as File;

    if (croppedFile != null) {
      if (MainHelper.isWebPlatform()) {
        //Seems weird, but this lets you get the data from the selected file as an Uint8List very easily.
        ParseWebFile file =
            ParseWebFile(null, name: "avatar.jpg", url: croppedFile.path);
        await file.download();
        parseFile = ParseWebFile(file.file, name: file.name);
      } else {
        parseFile = ParseFile(File(croppedFile.path), name: "avatar.jpg");
      }

      if (isAvatar == true) {
        widget.currentUser!.setAvatar = parseFile!;
      } else {
        widget.currentUser!.setCover = parseFile!;
      }

      ParseResponse parseResponse = await widget.currentUser!.save();

      if (parseResponse.success) {
        widget.currentUser = parseResponse.results!.first as UserModel;
        MainHelper.hideLoadingDialog(context);

        _getUser();

        MainHelper.goToNavigatorScreen(
          context,
          HomePage(
            currentUser: widget.currentUser,
          ),
          finish: true,
          back: false,
        );
      }
    } else {
      MainHelper.hideLoadingDialog(context);
      return;
    }
  }
}
