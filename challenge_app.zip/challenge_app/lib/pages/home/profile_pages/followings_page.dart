// ignore_for_file: must_be_immutable

import 'dart:ui';

import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:fade_shimmer/fade_shimmer.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../../../models/UserModel.dart';
import '../../../utilities/helper_classes/actions_helper.dart';
import '../../../utilities/helper_classes/main_helper.dart';
import '../../../utilities/main_utilities/colors.dart';
import '../../../widgets/custom_widgets/app_bar.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class FollowingsPage extends StatefulWidget {
  static String route = '/profile';
  UserModel? currentUser;
  UserModel? user;

  FollowingsPage({Key? key, this.currentUser, this.user}) : super(key: key);

  @override
  State<FollowingsPage> createState() => _FollowingsPageState();
}

class _FollowingsPageState extends State<FollowingsPage> {
  get size => MediaQuery.of(context).size;

  Future<List<dynamic>?> _loadFollowing() async {
    QueryBuilder<UserModel> queryBuilder =
    QueryBuilder<UserModel>(UserModel.forQuery());
    queryBuilder.whereContainedIn(UserModel.keyId,
        widget.user!.getFollowing!);

    ParseResponse apiResponse = await queryBuilder.query();

    if (apiResponse.success) {
      if (apiResponse.results != null) {
        return apiResponse.results;
      } else {
        return const AsyncSnapshot.nothing() as dynamic;
      }
    } else {
      return apiResponse.error as dynamic;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ToolBar(
        extendBodyBehindAppBar: true,
        backgroundColor: kTransparentColor,
        titleChild: TextWithTap(
          "page_title.following_title".tr(),
          color:Colors.white,
        ),
        centerTitle: MainHelper.isAndroidPlatform() ? false : true,
        leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            ContainerCorner(
              width: size.width,
              height: size.height,
              child: SafeArea(
                child: _showAllFollowings(),
              ),
            ),
          ],
        ));
  }

  Widget _showAllFollowings(){
    return FutureBuilder(
        future: _loadFollowing(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return ListView.builder(
              itemCount: 20,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: FadeShimmer(
                    height: 60,
                    width: 60,
                    radius: 4,
                    highlightColor: const Color(0xff000000).withOpacity(0.4),
                    baseColor: const Color(0xff000000).withOpacity(0.3),
                  ),
                );
              },
            );
          }
          if (snapshot.hasData) {
            var results = snapshot.data as List<dynamic>;
            return ListView.builder(
              itemCount: results.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      GestureDetector(
                        onTap: () => MainHelper.goToNavigatorScreen(context,
                            widget.currentUser!.objectId ==
                                results[index].objectId
                                ? ProfilePage(currentUser: widget.currentUser,)
                                : UserProfilePage(currentUser: widget.currentUser,
                              mUser: results[index],
                            )),
                        child: Row(
                          children: [
                            ContainerCorner(
                              height: 60,
                              width: 60,
                              child: ActionsHelper.polygonAvatarWidget(
                                  currentUser:results[index], fontSize: 13),
                            ),
                            Expanded(
                                child: TextWithTap(
                                  results[index].getFullName!,
                                  fontSize: 16,
                                  marginLeft: 10,
                                  color: Colors.white,
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          } else {
            return noMessage();
          }
        });
  }

  Widget noMessage() {
    return ContainerCorner(
      width: size.width,
      height: size.height * 0.7,
      child: Center(
        child: TextWithTap(
          'no_following'.tr(),
          fontSize: size.width / 22,
          textAlign: TextAlign.center,
          marginTop: size.height * 0.17,
          color:Colors.white,
        ),
      ),
    );
  }
}
