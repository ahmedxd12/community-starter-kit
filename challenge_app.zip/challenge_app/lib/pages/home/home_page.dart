// ignore_for_file: must_be_immutable, library_private_types_in_public_api
import 'package:challenge/pages/home/challenge_pages/start_challenge_page.dart';
import 'package:challenge/pages/home/message_pages/message_list_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_edit_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/pages/home/video_pages/all_video_page.dart';
import 'package:challenge/pages/home/video_pages/friends_videos_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/button_widget.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../../widgets/custom_widgets/text_with_tap.dart';

class HomePage extends StatefulWidget {
  static const String route = '/home';

  UserModel? currentUser;
  int? showPageWithIndex;

  HomePage({Key? key, this.currentUser, this.showPageWithIndex}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  TextEditingController inviteTextController = TextEditingController();
  bool hasNotification = false;
  int _selectedIndex = 0;

  @override
  void initState() {
    _selectedIndex = widget.showPageWithIndex ?? _selectedIndex;

    super.initState();

    Future.delayed(const Duration(seconds: 1), (){

      if (widget.currentUser!.getNeedsChangeName! || widget.currentUser!.getFullName == widget.currentUser!.getPhoneNumberFull) {
        showNameModal();
      }

    });
  }

  double iconSize = 30;

  double _getElevation() {
    if (_selectedIndex == 0) {
      return 0;
    } else {
      return 8;
    }
  }

  void onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    getUser(updateLocation: false);
  }

  List<Widget> _widgetOptions() {
    //_checkNotifications();

    List<Widget> widgets = [
      AllVideosPage(currentUser: widget.currentUser,),
      FriendsVideoPage(currentUser: widget.currentUser,),
      StartChallengePage(currentUser: widget.currentUser,),
      MessagesListPage(currentUser: widget.currentUser,),
      ProfilePage(currentUser: widget.currentUser,)
    ];

    return widgets;
  }

  Widget bottomNavBar() {
    var size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      physics: const NeverScrollableScrollPhysics(),
      child: Stack(
        alignment: AlignmentDirectional.center,
        clipBehavior: Clip.none,
        children: [
          ContainerCorner(
            imageDecoration: "assets/images/app_bg.png",
            child: BottomNavigationBar(
              showSelectedLabels: false,
              showUnselectedLabels: false,
              backgroundColor: kTransparentColor,
              items: [
                BottomNavigationBarItem(
                  backgroundColor: kTransparentColor,
                  label: "bottom_menu.menu_feed".tr(),
                  icon: Image.asset(
                    "assets/images/ic_tab_home.png",
                    width:size.width/6.5,
                    height:size.width/6.5,
                  ),
                ),
                BottomNavigationBarItem(
                    backgroundColor: kTransparentColor,
                    icon: Image.asset(
                      "assets/images/ic_tab_home2.png",
                      width:size.width/6.5,
                      height:size.width/6.5,
                    ),
                    label: "stories.tab_states".tr(),
                ),
                BottomNavigationBarItem(
                    backgroundColor: kTransparentColor,
                    icon: Container(),
                    label: "bottom_menu.menu_live".tr(),
                ),
                BottomNavigationBarItem(
                    backgroundColor: kTransparentColor,
                    icon: Image.asset(
                      "assets/images/ic_tab_messa.png",
                      width:size.width/6.5,
                      height:size.width/6.5,
                    ),
                    label: "bottom_menu.menu_coins".tr(),
                ),
                BottomNavigationBarItem(
                  backgroundColor: kButtonTextColor,//Colors.amber,
                  icon: Image.asset(
                    "assets/images/ic_tab_profile.png",
                    width:size.width/6.5,
                    height:size.width/6.5,
                  ),
                  label: "bottom_menu.menu_chat".tr(),
                ),
              ],
              type: BottomNavigationBarType.fixed,
              elevation: _getElevation(),
              currentIndex: _selectedIndex,
              onTap: (index) => onItemTapped(index),
            ),
          ),
          /*!widget.currentUser!.getIsViewer! && _selectedIndex == 2
           ?const SizedBox()
           : */Positioned(
            bottom: -38,
            child: ContainerCorner(
              width: size.width / 2.4,
              height: size.width / 2.4,
              marginBottom: 50,
              onTap: () {
                onItemTapped(2);
                if(widget.currentUser!.getIsViewer!){

                }else{
                  onItemTapped(2);
                }
              },
              child: widget.currentUser!.getIsViewer!

                ? Stack(
                  alignment: AlignmentDirectional.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(25.0),
                      child: Image.asset("assets/images/challene_bg.png"),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(25.0),
                      child: Image.asset("assets/images/ic_start_elimination.png"),
                    ),
                  ])

                : Stack(
                alignment: AlignmentDirectional.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(25.0),
                    child: Image.asset( _selectedIndex == 2 ? "assets/images/tab_challenge_selected.png" : "assets/images/challene_bg.png"),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(50.0),
                    child: Image.asset(_selectedIndex == 2 ? "assets/images/ic_tab_challenge_selected.png" : "assets/images/ic_tab_challenge.png"),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  getUser({bool? updateLocation}) async {
    widget.currentUser!.clearUnsavedChanges();

    ParseResponse? parseResponse = await ParseUser.getCurrentUserFromServer(
        widget.currentUser!.getSessionToken!);
    if (parseResponse != null &&
        parseResponse.success &&
        parseResponse.results != null) {
      widget.currentUser = parseResponse.results!.first! as UserModel;
      widget.currentUser = parseResponse.results!.first! as UserModel;
    }

    if (updateLocation != null && updateLocation == true) {
      if (widget.currentUser!.getBirthday != null) {
        widget.currentUser!.setAge =
            MainHelper.getAgeFromDate(widget.currentUser!.getBirthday!);
        await widget.currentUser!.save();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _widgetOptions().elementAt(_selectedIndex),
      bottomNavigationBar: ContainerCorner(
        marginBottom: 0,
          borderWidth: 0,
          child: bottomNavBar(),
      ),
    );

  }

  void showNameModal() {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: false,
        isDismissible: false,
        builder: (context) {
          return _showBottomSheetUpdateName();
        });
  }

  Widget _showBottomSheetUpdateName() {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.3,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(
                builder: (context, setState) {
                  return Container(
                    decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(25.0),
                        topRight: Radius.circular(25.0),
                      ),
                    ),
                    child: ContainerCorner(
                      radiusTopRight: 25.0,
                      radiusTopLeft: 25.0,
                      color: MainHelper.isDarkMode(context)
                          ? kContentColorLightTheme
                          : Colors.white,
                      child: SafeArea(
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                children: [
                                  TextWithTap(
                                    "profile_screen.change_name_title".tr(),
                                    marginTop: 10,
                                    marginBottom: 20,
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  TextWithTap(
                                    "profile_screen.change_name_explain".tr(),
                                    fontSize: 16,
                                    textAlign: TextAlign.center,
                                    marginLeft: 20,
                                    marginRight: 20,
                                  ),
                                ],
                              ),
                              ButtonWidget(
                                width: 100,
                                height: 30,
                                padding: const EdgeInsets.only(left: 10, right: 10),
                                marginBottom: 20,
                                borderRadiusAll: 30,
                                color: kPrimaryColor,
                                child: TextWithTap(
                                  "profile_screen.change_btn".tr(),
                                  color: Colors.white,
                                ),
                                onTap: () async {
                                  MainHelper.hideLoadingDialog(context);

                                  UserModel? user = await MainHelper.goToNavigatorScreenForResult(
                                      context,
                                      ProfileEditPage(
                                        currentUser: widget.currentUser,
                                      ), route: ProfileEditPage.route);

                                  if(user != null){
                                    widget.currentUser = user;
                                  }
                                },
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  showError(int code){
    MainHelper.hideLoadingDialog(context);
    MainHelper.showErrorResult(context, code);
  }
}