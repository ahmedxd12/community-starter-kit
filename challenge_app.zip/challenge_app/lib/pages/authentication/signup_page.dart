// ignore_for_file: use_build_context_synchronously

import 'dart:io';
import 'dart:ui';

import 'package:challenge/utilities/main_utilities/shared_manager.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:faker/faker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/pages/global/global_loading_page.dart';
import 'package:challenge/pages/authentication/signin_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/CategoryModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../configurations/global_setup.dart';
import '../../services/analytics_service.dart';
import '../../widgets/custom_widgets/text_with_tap.dart';

class SignUpPage extends StatefulWidget {
  static const String route = '/signup';

  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final Future<SharedPreferences> prefs = SharedPreferences.getInstance();

  bool isViewer = true;
  bool showTopButton = false;
  int index = 0;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final GlobalKey<FormState> _formKey1 = GlobalKey<FormState>();

  var categoriesIcons = [
    "assets/svg/ic_cat_dance.svg",
    "assets/svg/ic_cat_art.svg",
    "assets/svg/ic_cat_jokes.svg",
    "assets/svg/ic_cat_sport.svg",
    "assets/svg/ic_cat_logic.svg",
    "assets/svg/ic_cat_fun.svg",
    "assets/svg/ic_cat_cook.svg",
    "assets/svg/ic_cat_sing.svg",
    "assets/svg/ic_cat_inventive.svg",
    "assets/svg/ic_cat_family.svg",
    "assets/svg/ic_cat_jokes.svg",
    "assets/svg/ic_cat_sport.svg"
  ];

  var categoriesLabels = [
    UserModel.categoryDance,
    UserModel.categoryART,
    UserModel.categoryJOKES,
    UserModel.categorySPORT,
    UserModel.categoryLOGIC,
    UserModel.categoryFUN,
    UserModel.categoryCOOK,
    UserModel.categorySING,
    UserModel.categoryINVENTIVE,
    UserModel.categoryFAMILY,
    UserModel.categorySNERVATING,
    UserModel.categoryPENANCE,
  ];

  var genders = [
    UserModel.genderMALE,
    UserModel.genderFEMALE,
    UserModel.genderOTHER,
  ];

  var schools = [
    UserModel.schoolHIGHSCHOOL,
    UserModel.schoolUNIVERSITY,
  ];

  var films = [
    UserModel.filmHORROR,
    UserModel.filmCOMEDY,
    UserModel.filmDRAMATIC,
  ];

  var hobby = [
    UserModel.hobbyDANCE,
    UserModel.hobbyCOOK,
    UserModel.hobbySPORT,
  ];

  var status = [
    UserModel.statusSINGLE,
    UserModel.statusRELATIONSHP,
  ];

  var selectedCategories = [];
  var selectedGender = [];
  var selectedFavoriteFilm = [];
  var selectedHobby = [];
  var selectedStatus = [];
  var selectedSchool = [];

  List<dynamic> allCategories = [];

  selectGender(String code) {
    selectedGender.clear();
    selectedGender.add(code);
    setState(() {});
  }

  selectSchool(String code) {
    selectedSchool.clear();
    selectedSchool.add(code);
    setState(() {});
  }

  selectFilm(String code) {
    selectedFavoriteFilm.clear();
    selectedFavoriteFilm.add(code);
    setState(() {});
  }

  selectHobby(String code) {
    selectedHobby.clear();
    selectedHobby.add(code);
    setState(() {});
  }

  selectStatus(String code) {
    selectedStatus.clear();
    selectedStatus.add(code);
    setState(() {});
  }

  TextEditingController nameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController nickNameController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController nationalityController = TextEditingController();
  TextEditingController jobController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController passwordConfirmController = TextEditingController();
  TextEditingController emailController = TextEditingController();

  getAllCategories() async {
    QueryBuilder<CategoryModel> query = QueryBuilder(CategoryModel());
    query.orderByAscending(CategoryModel.keyName);

    ParseResponse response = await query.query();

    if(response.success){
      if(response.result != null){
        setState((){
          allCategories = response.results as List<dynamic>;
        });
      }
    }
  }

  @override
  void initState() {
    getAllCategories();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return GestureDetector(
        onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        child: Scaffold(
          extendBodyBehindAppBar: true,
          backgroundColor:
              MainHelper.isDarkMode(context) ? kWelcomeDarkMode : Colors.white,
          resizeToAvoidBottomInset: false,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: kTransparentColor,
            actions: [
              Visibility(
                visible: true,
                child: ContainerCorner(
                  onTap: () => MainHelper.goToNavigatorScreen(
                      context, const SignInPage()),
                  width:size.width/15,
                  height:size.width/50,
                  marginLeft: 12,
                  marginRight: 12,
                  marginBottom: 15,
                  marginTop: 15,
                  color: kPrimaryColor,
                  borderRadius: 50,
                  child: Center(
                    child: Icon(Icons.close, size: size.width/25,color: kContentColorDarkTheme,),
                  ),
                ),
              ),
            ],
          ),
          body: Stack(
            children: [
              ContainerCorner(
                borderWidth: 0,
                color: kTransparentColor,
                width: size.width,
                height: size.height,
                imageDecoration: "assets/images/app_bg.png",
              ),
              ClipRRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                  child: ContainerCorner(
                    width: size.width,
                    height: size.height,
                  ),
                ),
              ),
              ContainerCorner(
                borderWidth: 0,
                height: size.height,
                width: size.width,
                child: Stack(
                  children: [
                    ContainerCorner(
                      borderWidth: 0,
                      height: size.height,
                      width: size.width,
                      color: Colors.black.withOpacity(0.4),
                      child: ListView(
                        shrinkWrap: true,
                        children: [
                          IndexedStack(
                            index: index,
                            children: [
                              chooseMode(size),
                              fistStep(size),
                              secondStep(size)
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  Widget fistStep(var size) {
    return Center(
      child: Padding(
        padding: EdgeInsets.only(left: size.width / 20, right: size.width / 20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              TextWithTap(
                "auth.sign_up".tr().toUpperCase(),
                color: Colors.white,
                fontSize: size.width / 15,
                fontWeight: FontWeight.w900,
              ),
              textField(
                size: size,
                controller: nameController,
                text: "auth.name_",
                errorMessage: "auth.name_required",
              ),
              textField(
                size: size,
                controller: lastNameController,
                text: "auth.last_name",
                errorMessage: "auth.lastname_required",
              ),
              textField(
                size: size,
                controller: nickNameController,
                text: "auth.nickname_",
                errorMessage: "auth.nickname_required",
              ),
              textField(
                size: size,
                controller: phoneNumberController,
                text: "auth.number_phone",
                errorMessage: "auth.phone_required",
              ),
              textField(
                size: size,
                controller: passwordController,
                text: "auth.password_",
                errorMessage: "auth.password_error_explain",
                isPassword: true,
              ),
              textField(
                size: size,
                controller: passwordConfirmController,
                text: "auth.password_confirm",
                errorMessage: "auth.password_confirm_error_title",
                isPassword: true,
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextWithTap(
                  "auth.favorite_cat".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 20,
                  marginTop: size.width / 20,
                  marginBottom: size.width / 20,
                ),
              ),
              Visibility(
                visible: allCategories.isNotEmpty,
                child:GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 4,
                  mainAxisSpacing: 10.0,
                  crossAxisSpacing: 10.0,
                  physics: const NeverScrollableScrollPhysics(),
                  children: List.generate(
                    allCategories.length,
                        (index) {
                          CategoryModel category = allCategories[index];

                          return ContainerCorner(
                            borderWidth: 2,
                            borderRadius: 4,
                            borderColor:
                            selectedCategories.contains(category.objectId)
                                ? kPrimaryColor
                                : kTransparentColor,
                            onTap: () {
                              selectCategories(category.objectId!);
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SvgPicture.network(
                                  category.getImage!.url!,
                                  height: 25,
                                  width: 25,
                                ),
                                TextWithTap(
                                  category.getName!.toUpperCase(),
                                  color: Colors.white,
                                  fontSize: size.width / 35,
                                  marginTop: 5,
                                ),
                              ],
                            ),
                          );
                        },
                  ),
                ),
              ),
              ContainerCorner(
                radiusBottomRight: 20,
                borderWidth: 2,
                imageDecoration: "assets/images/white_btn.png",
                radiusTopLeft: 20,
                marginTop: size.width / 15,
                height: size.width / 9,
                marginLeft: size.width / 10,
                marginRight: size.width / 10,
                width: size.width,
                onTap: () {
                  if (_formKey.currentState!.validate()) {
                    _next();
                  }
                },
                child: Center(
                  child: TextWithTap(
                    "auth.next_".tr().toUpperCase(),
                    color: kPrimaryColor,
                    fontWeight: FontWeight.w900,
                    fontSize: size.width / 20,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _next(){

    if(passwordController.text.length < 8){
      MainHelper.showAppNotificationAdvanced(
        title: "auth.password_error".tr(),
        context: context,
        isError: true,
        message: "auth.password_length".tr(),
      );
      return;
    }

    if(passwordController.text != passwordConfirmController.text){
      MainHelper.showAppNotificationAdvanced(
        title: "auth.password_error".tr(),
        context: context,
        isError: true,
        message: "auth.password_match".tr(),
      );
      return;
    }

    if(selectedCategories.isEmpty){
      MainHelper.showAppNotificationAdvanced(
        title: "auth.empty_cat_title".tr(),
        context: context,
        isError: true,
        message: "auth.empty_cat".tr(),
      );
      return;
    }

    setState(() {
      index = 2;
    });

  }

  Widget secondStep(var size) {
    return Center(
      child: Padding(
        padding: EdgeInsets.only(left: size.width / 20, right: size.width / 20),
        child: Form(
          key: _formKey1,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: TextWithTap(
                  "auth.gender".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 20,
                  marginTop: size.width / 20,
                  marginBottom: size.width / 20,
                ),
              ),
              Row(
                children: List.generate(
                  genders.length,
                  (index) => ContainerCorner(
                    color: selectedGender.contains(genders[index])
                        ? kPrimaryColor
                        : Colors.white,
                    marginRight: size.width / 30,
                    onTap: () => selectGender(genders[index]),
                    child: TextWithTap(
                      MainHelper.getGenderList(genders[index])
                          .tr()
                          .toUpperCase(),
                      marginLeft: 3,
                      marginTop: 3,
                      marginRight: 3,
                      marginBottom: 3,
                      color: selectedGender.contains(genders[index])
                          ? Colors.white
                          : kPrimaryColor,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: size.width / 20,
              ),
              textField(
                size: size,
                controller: nationalityController,
                text: "auth.nationality_",
                errorMessage: "auth.nationality_required",
              ),
              textField(
                size: size,
                controller: emailController,
                text: "auth.email_",
                errorMessage: "auth.email_required",
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextWithTap(
                  "auth.school_".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 20,
                  marginTop: size.width / 20,
                  marginBottom: size.width / 20,
                ),
              ),
              Row(
                children: List.generate(
                  schools.length,
                  (index) => ContainerCorner(
                    color: selectedSchool.contains(schools[index])
                        ? kPrimaryColor
                        : Colors.white,
                    marginRight: size.width / 30,
                    onTap: () => selectSchool(schools[index]),
                    child: TextWithTap(
                      MainHelper.getSchoolList(schools[index])
                          .tr()
                          .toUpperCase(),
                      marginLeft: 3,
                      marginTop: 3,
                      marginRight: 3,
                      marginBottom: 3,
                      color: selectedSchool.contains(schools[index])
                          ? Colors.white
                          : kPrimaryColor,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextWithTap(
                  "auth.kind_fav_film".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 20,
                  marginTop: size.width / 20,
                  marginBottom: size.width / 20,
                ),
              ),
              Row(
                children: List.generate(
                  films.length,
                  (index) => ContainerCorner(
                    color: selectedFavoriteFilm.contains(films[index])
                        ? kPrimaryColor
                        : Colors.white,
                    marginRight: size.width / 30,
                    onTap: () => selectFilm(films[index]),
                    child: TextWithTap(
                      MainHelper.getFilmList(films[index]).tr().toUpperCase(),
                      marginLeft: 3,
                      marginTop: 3,
                      marginRight: 3,
                      marginBottom: 3,
                      color: selectedFavoriteFilm.contains(films[index])
                          ? Colors.white
                          : kPrimaryColor,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextWithTap(
                  "auth.hobby_".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 20,
                  marginTop: size.width / 20,
                  marginBottom: size.width / 20,
                ),
              ),
              Row(
                children: List.generate(
                  hobby.length,
                  (index) => ContainerCorner(
                    color: selectedHobby.contains(hobby[index])
                        ? kPrimaryColor
                        : Colors.white,
                    marginRight: size.width / 30,
                    onTap: () => selectHobby(hobby[index]),
                    child: TextWithTap(
                      MainHelper.getHobbyList(hobby[index]).tr().toUpperCase(),
                      marginLeft: 3,
                      marginTop: 3,
                      marginRight: 3,
                      marginBottom: 3,
                      color: selectedHobby.contains(hobby[index])
                          ? Colors.white
                          : kPrimaryColor,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: size.width / 20,
              ),
              textField(
                size: size,
                controller: jobController,
                text: "auth.job_",
                errorMessage: "auth.job_required",
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextWithTap(
                  "auth.status_".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 20,
                  marginTop: size.width / 20,
                  marginBottom: size.width / 20,
                ),
              ),
              Row(
                children: List.generate(
                  status.length,
                  (index) => ContainerCorner(
                    color: selectedStatus.contains(status[index])
                        ? kPrimaryColor
                        : Colors.white,
                    marginRight: size.width / 30,
                    onTap: () => selectStatus(status[index]),
                    child: TextWithTap(
                      MainHelper.getStatusList(status[index]).tr().toUpperCase(),
                      marginLeft: 3,
                      marginTop: 3,
                      marginRight: 3,
                      marginBottom: 3,
                      color: selectedStatus.contains(status[index])
                          ? Colors.white
                          : kPrimaryColor,
                    ),
                  ),
                ),
              ),
              ContainerCorner(
                radiusBottomRight: 20,
                borderWidth: 2,
                imageDecoration: "assets/images/white_btn.png",
                radiusTopLeft: 20,
                marginTop: size.width / 15,
                height: size.width / 9,
                marginLeft: size.width / 10,
                marginRight: size.width / 10,
                width: size.width,
                onTap: () {
                  if (_formKey1.currentState!.validate()) {
                    _createAccount();
                  } else {
                    MainHelper.showAppNotificationAdvanced(
                      title: "auth.empty_fields_title".tr(),
                      context: context,
                      isError: true,
                      message: "auth.empty_fields_explain".tr(),
                    );
                  }
                },
                child: Center(
                  child: TextWithTap(
                    "auth.register_".tr().toUpperCase(),
                    color: kPrimaryColor,
                    fontWeight: FontWeight.w900,
                    fontSize: size.width / 20,
                  ),
                ),
              ),
              SizedBox(
                height: size.width / 10,
              ),
            ],
          ),
        ),
      ),
    );
  }

  _createAccount() {
    if (selectedCategories.isEmpty) {
      MainHelper.showAppNotificationAdvanced(
        title: "auth.fav_cat_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.fav_cat_error_explain".tr(),
      );
      return;
    }

    if (selectedGender.isEmpty) {
      MainHelper.showAppNotificationAdvanced(
        title: "auth.gender_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.gender_error_explain".tr(),
      );
      return;
    }

    if (selectedSchool.isEmpty) {
      MainHelper.showAppNotificationAdvanced(
        title: "auth.school_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.school_error_explain".tr(),
      );
      return;
    }

    if (selectedFavoriteFilm.isEmpty) {
      MainHelper.showAppNotificationAdvanced(
        title: "auth.film_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.film_error_explain".tr(),
      );
      return;
    }

    if (selectedHobby.isEmpty) {
      MainHelper.showAppNotificationAdvanced(
        title: "auth.hobby_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.hobby_error_explain".tr(),
      );
      return;
    }

    if (selectedStatus.isEmpty) {
      MainHelper.showAppNotificationAdvanced(
        title: "auth.status_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.status_error_explain".tr(),
      );
      return;
    }

    if(!MainHelper.isValidEmail(emailController.text)){
      MainHelper.showAppNotificationAdvanced(
        title: "auth.email_error_title".tr(),
        context: context,
        isError: true,
        message: "auth.email_error_explain".tr(),
      );
      return;
    }

    signUpUser();
  }

  Future<void> signUpUser() async {
    MainHelper.showLoadingDialog(context);

    var faker = Faker();

    String imageUrl =
    faker.image.image(width: 640, height: 640, keywords: ["nature"]);

    String password = passwordController.text;
    String email = emailController.text;
    String username = nameController.text;

    UserModel user = UserModel(username, password, email);

    user.setFullName = "${nameController.text} ${nickNameController.text} ${lastNameController.text}";
    user.setFirstName = nameController.text;
    user.setEmail = email;
    user.setEmailPublic = email;
    user.username = username.toLowerCase();
    user.setPhotoVerified = true;
    user.setNeedsChangeName = false;
    user.setIsViewer = isViewer;

    user.setSchool = selectedSchool[0];
    user.setGender = selectedGender[0];
    user.setRelationship = selectedStatus[0];
    user.setFavoriteFilm = selectedFavoriteFilm[0];
    user.setHobby = selectedHobby[0];
    user.gstCategories = selectedCategories;

    user.setPhoneNumber = phoneNumberController.text;

    user.setUid = MainHelper.generateUId();
    user.setNationality = nationalityController.text;
    user.setJobTitle = jobController.text;

    user.setUserRole = UserModel.roleUser;
    user.setPrefMinAge = Setup.minimumAgeToRegister;
    // user.setAge = int.parse(ageController.text);
    user.setPrefMaxAge = Setup.maximumAgeToRegister;
    user.setLocationTypeNearBy = true;
    user.addCredit = Setup.welcomeCredit;
    user.setBio = Setup.bio;
    user.setHasPassword = true;

    ParseResponse userResult = await user.signUp();

    if (userResult.success) {
      
      getPhotoFromUrl(context, user, imageUrl);
    } else if (userResult.error!.code == 100) {
      
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context, title: "error".tr(), message: "not_connected".tr());
    } else {
      
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "try_again_later".tr());
    }
  }

  void getPhotoFromUrl(
      BuildContext context, UserModel user, String url) async {
    File avatar = await MainHelper.downloadFile(url, "avatar.jpeg") as File;

    ParseFileBase parseFile;
    if (MainHelper.isWebPlatform()) {
      //Seems weird, but this lets you get the data from the selected file as an Uint8List very easily.
      ParseWebFile file =
      ParseWebFile(null, name: "avatar.jpeg", url: avatar.path);
      await file.download();
      parseFile = ParseWebFile(file.file, name: file.name);
    } else {
      parseFile = ParseFile(File(avatar.path));
    }

    user.setAvatar = parseFile;
    //user.setAvatar1 = parseFile;

    final ParseResponse response = await user.save();
    if (response.success) {
      
      MainHelper.hideLoadingDialog(context);

      Analytics analytics = Analytics();
      analytics.seTUserId(user);
      analytics.newSignupEvent('Email/password');

      // updates current installation's user
      prefs.then((SharedPreferences sharedPreferences) {
        MainHelper.initInstallation(user, SharedManager.getDeviceToken(sharedPreferences));
      });

      
      MainHelper.goToNavigatorScreen(
          context,
          GlobalLoadingPage(
            currentUser: user,
          ),
          back: false,
          finish: true);
    } else {
      
      MainHelper.hideLoadingDialog(context);

      
      MainHelper.goToNavigatorScreen(
          context,
          GlobalLoadingPage(
            currentUser: user,
          ),
          finish: true,
          back: false);
    }
  }

  selectCategories(String categoryCode) {
    setState(() {
      if (selectedCategories.contains(categoryCode)) {
        selectedCategories.removeAt(selectedCategories.indexOf(categoryCode));
      } else {
        if (selectedCategories.length < 5) {
          selectedCategories.add(categoryCode);
        }
      }
    });
  }

  Widget textField(
      {required var size,
      required TextEditingController controller,
      required String text,
      required String errorMessage,
      bool isPassword = false}) {
    return TextFormField(
      autocorrect: false,
      maxLines: 1,
      obscureText: isPassword,
      controller: controller,
      validator: (value) {
        if (value!.isEmpty) {
          return errorMessage.tr();
        } else {
          return null;
        }
      },
      style: const TextStyle(
        color: Colors.white,
      ),
      decoration: InputDecoration(
        hintText: text.tr().toUpperCase(),
        hintStyle: GoogleFonts.azeretMono(
            color: Colors.white, fontSize: size.width / 20),
      ),
    );
  }

  Widget chooseMode(var size) {
    return Padding(
      padding: EdgeInsets.only(top:size.height*0.25),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextWithTap(
              "auth.choose_".tr().toUpperCase(),
              color: Colors.white,
              fontSize: size.width / 15,
              fontWeight: FontWeight.w900,
              marginBottom: size.width / 30,
            ),
            ContainerCorner(
              radiusBottomRight: 20,
              borderWidth: 2,
              imageDecoration: "assets/images/btn_design.png",
              radiusTopLeft: 20,
              marginTop: size.width / 30,
              height: size.width / 7,
              marginLeft: size.width / 10,
              marginRight: size.width / 10,
              width: size.width,
              onTap: () {
                setState(() {
                  index = 1;
                  isViewer = false;
                  showTopButton = true;
                });
              },
              child: Center(
                child: TextWithTap("auth.challenger_".tr().toUpperCase(),color: Colors.white,),
              ),
            ),
            ContainerCorner(
              radiusBottomRight: 20,
              borderWidth: 2,
              imageDecoration: "assets/images/btn_design.png",
              radiusTopLeft: 20,
              marginTop: size.width / 30,
              height: size.width / 9,
              marginLeft: size.width / 10,
              marginRight: size.width / 10,
              width: size.width,
              onTap: () {
                setState(() {
                  index = 1;
                  showTopButton = true;
                });
              },
              child: Center(
                child: TextWithTap("auth.viewer_".tr().toUpperCase(), color: Colors.white,),
              ),
            ),
            TextWithTap(
              "auth.have_account".tr().toUpperCase(),
              color: Colors.white,
              fontWeight: FontWeight.bold,
              marginTop: size.width / 10,
              onTap: () =>
                  MainHelper.goToNavigatorScreen(context, const SignInPage()),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(40.0),
                child: Wrap(
                  alignment: WrapAlignment.center,
                  runSpacing: 0,
                  spacing: 0,
                  children: [
                    TextWithTap(
                      "agree_with_signup".tr(),
                      color: Colors.white,
                      fontSize: 12.5,
                    ),
                    TextWithTap(
                      "policy".tr(),
                      color: kPrimaryColor,
                      fontSize: 12.5,
                      onTap: () => MainHelper.goToWebPage(context,
                          pageType: MainHelper.pageTypePrivacy),
                    ),
                    TextWithTap(
                      "and".tr(),
                      color: Colors.white,
                      fontSize: 12.5,
                    ),
                    TextWithTap(
                        "terms".tr(),
                        color: kPrimaryColor,
                        fontSize: 12.5,
                        onTap: () => MainHelper.goToWebPage(context,
                            pageType: MainHelper.pageTypeTerms)
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}